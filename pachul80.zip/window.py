"""
Pachul — window.py
Main application window: sidebar, package list with an integrated search
entry, detail panel, filtering, and all action handlers.
"""

import os
import re
import shlex
import threading
import time

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, GLib, Gio, Pango

import distro
import pkgmanager
from backend import (
    get_packages, get_package_info, get_package_files,
    check_updates, search_packages_cmd, run_command, get_aur_info,
    invalidate_cache, invalidate_syncdb_cache, get_explicit_packages,
    get_ignored_packages, build_hold_cmd, build_hold_cmd_bulk, get_setting, save_settings,
    build_snapshot_cmd, flatpak_available, snap_available,
    is_pachul_installed, build_install_command, pachul_update_available,
    get_enabled_auto_update_commands, check_aur_ahead_of_repo,
    build_desktop_icon_map, fetch_flatpak_icon,
    aur_helper_upgrade_cmd, aur_helper_install_cmd, _find_aur_helper,
    pachuli_installed, local_pachuli_path, get_pachuli_install_cmd,
    makepkg_auth_needs_setup, get_makepkg_pkexec_cmd,
    pachuli_update_available, notify_tray_recheck,
    startup_health_checks, aur_meta_is_fresh, refresh_aur_meta, apply_aur_meta,
)
from models import (
    PackageItem, NavRow, REPO_BADGE_CLASS, pkg_icon, make_package_listview,
    make_icon, set_button_icon, ListSelectionState, set_installed_icon_map,
    resolve_real_icon_paintable, selection_key, version_text,
)
from icons import (themed_image, themed_paintable, get_icon_texture,
                    get_flatpak_icon_paintable)

# Directory this module (and app.py) live in — used to find install.sh
# next to a source checkout, and as the tray.py path for the autostart
# entry before Pachul has been installed system-wide.
APP_DIR = os.path.dirname(os.path.abspath(__file__))

# Fallback chains for icon names that are missing in some icon themes
# (notably KDE Breeze), which otherwise show up as a red/pink broken icon.
ICON_UPDATE_AVAILABLE = [
    "software-update-available-symbolic", "software-update-available",
    "system-software-update-symbolic", "view-refresh-symbolic",
]
ICON_RATE_MIRRORS = [
    "network-transmit-receive-symbolic", "network-wired-symbolic",
    "network-workgroup-symbolic", "preferences-system-network-symbolic",
    "view-refresh-symbolic",
]
ICON_CLEAN_CACHE = [
    "folder-download-symbolic", "edit-clear-all-symbolic",
    "user-trash-symbolic", "folder-symbolic",
]
from i18n import tr, get_language
import localpkg
from toolshub import show_tools_dialog, show_packages_dialog
from dialogs import (
    run_terminal_dialog,
    show_sync_db_dialog,
    show_repo_manager,
    show_repo_manager_native,
    show_apt_repair_dialog,
    show_dnf_repair_dialog,
    show_zypper_repair_dialog,
    show_pacman_repair_dialog,
    show_cert_checker_dialog,
    show_broken_symlinks_dialog,
    show_services_security_dialog,
    show_config_backup_dialog,
    show_mirror_rater,
    show_orphan_finder,
    show_clean_cache_dialog,
    show_import_pkgs_dialog,
    show_import_pkgs_intro,
    show_install_local_dialog,
    show_export_pkgs_intro,
    show_hold_dialog,
    show_mark_asdeps_dialog,
    show_file_search_dialog,
    show_sysinfo_dialog,
    show_history_dialog,
    show_downgrade_dialog,
    show_pkgbuild_dialog,
    show_pacdiff_dialog,
    show_tool_updates_dialog,
    show_ignored_packages_dialog,
    show_preferences,
    show_help_dialog,
    show_startup_healthcheck_dialog,
)


class DetailPanel:
    """Right-hand package detail view: hero header + Info tab + Files tab.

    One instance is built for the main list page and one for the search page.
    pachulWindow drives both through the same _show_detail / _populate_detail
    methods, so the two views can never drift apart.

    Widget references live on the instance (icon, name, status, info_rows, …);
    `dep_callback` is set by the window to route dependency-chip clicks. The
    Files tab is a virtualized ListView whose FilterListModel does the
    filtering, so the search box never rebuilds rows.
    """

    INFO_KEYS = [
        "URL", "Licenses", "Groups", "Depends On", "Optional Deps", "Required By",
        "Conflicts With", "Provides", "Replaces",
        "Installed Size", "Packager", "Build Date", "Install Date", "Install Reason",
    ]
    # Fields rendered as expandable clickable-chip flows rather than plain rows
    DEP_KEYS = ("Depends On", "Optional Deps", "Required By")

    def __init__(self, action_btn, on_install, on_remove, on_reinstall, on_downgrade, on_hold=None):
        self.dep_callback = None   # set by the window: takes a dependency name
        self.info_rows = {}        # key -> ActionRow / ExpanderRow
        self.dep_rows = {}         # key -> (ExpanderRow, FlowBox)
        self._files_query = ""     # current Files-tab filter text (lowercased)
        self._files_loading = False
        self._current_pkg_name = None   # guards async icon fetch races
        self.on_visibility = None  # set by the window: called with True when the panel gets shown
        self._build(action_btn, on_install, on_remove, on_reinstall, on_downgrade, on_hold)

    def _build(self, action_btn, on_install, on_remove, on_reinstall, on_downgrade, on_hold=None):
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self.stack.set_transition_duration(120)

        empty = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        empty.set_valign(Gtk.Align.CENTER); empty.set_halign(Gtk.Align.CENTER)
        empty.set_vexpand(True); empty.set_hexpand(True)
        empty_icon = themed_image("package-x-generic-symbolic", 36)
        empty_icon.add_css_class("dim-label")
        empty_icon.set_halign(Gtk.Align.CENTER)
        empty.append(empty_icon)
        empty_title = Gtk.Label(label=tr("Select a Package"))
        empty_title.add_css_class("title-4")
        empty_title.set_halign(Gtk.Align.CENTER)
        empty_title.set_justify(Gtk.Justification.CENTER)
        empty.append(empty_title)
        empty_desc = Gtk.Label(
            label=tr("Choose a package to view its details, files, and dependencies."))
        empty_desc.add_css_class("dim-label")
        empty_desc.set_halign(Gtk.Align.CENTER)
        empty_desc.set_justify(Gtk.Justification.CENTER)
        empty_desc.set_wrap(True)
        empty_desc.set_max_width_chars(40)
        empty.append(empty_desc)
        self.stack.add_named(empty, "empty")

        # Batch selection overview
        batch_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        batch_page.set_margin_top(16); batch_page.set_margin_bottom(24)
        batch_page.set_margin_start(20); batch_page.set_margin_end(20)

        batch_header = Gtk.Label(label=tr("Selected Packages"))
        batch_header.add_css_class("title-2")
        batch_header.set_halign(Gtk.Align.START)
        batch_page.append(batch_header)

        self.batch_listbox = Gtk.ListBox()
        self.batch_listbox.set_selection_mode(Gtk.SelectionMode.NONE)
        self.batch_listbox.add_css_class("boxed-list")
        batch_scroll = Gtk.ScrolledWindow()
        batch_scroll.set_vexpand(True)
        batch_scroll.set_child(self.batch_listbox)
        batch_page.append(batch_scroll)

        self.stack.add_named(batch_page, "batch")
        self.stack.set_visible_child_name("empty")

        # ---- Detail view (unchanged) ----
        detail_scroll = Gtk.ScrolledWindow()
        detail_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        detail_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        detail_box.set_margin_top(16);   detail_box.set_margin_bottom(24)
        detail_box.set_margin_start(20); detail_box.set_margin_end(20)

        # Banner shown when this (repo-tracked) package also exists on the
        # true AUR at a newer version than what's installed — the
        # "arch-update" case: a repo mirror (e.g. chaotic-aur) can lag
        # behind the AUR's own rebuild cadence, which pacman/checkupdates
        # alone have no way to notice. Hidden until check_aur_ahead_of_repo
        # actually finds something.
        self.aur_ahead_banner = Adw.Banner()
        self.aur_ahead_banner.set_revealed(False)
        detail_box.append(self.aur_ahead_banner)

        # Hero
        hero = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        hero.add_css_class("pkg-hero")
        top_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        self.icon = Gtk.Image()
        self.icon.set_pixel_size(58); self.icon.set_valign(Gtk.Align.CENTER)
        _tex = get_icon_texture("package-x-generic-symbolic", 58)
        if _tex is not None:
            self.icon.set_from_paintable(_tex)
        else:
            self.icon.set_from_icon_name("package-x-generic-symbolic")
        top_row.append(self.icon)
        title_col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        title_col.set_hexpand(True); title_col.set_valign(Gtk.Align.CENTER)
        self.name = Gtk.Label(label=tr("Package"))
        self.name.set_halign(Gtk.Align.START); self.name.add_css_class("title-2")
        self.name.add_css_class("pkg-title")
        title_col.append(self.name)
        self.desc = Gtk.Label(label=tr("Description"))
        self.desc.set_halign(Gtk.Align.START); self.desc.add_css_class("body")
        self.desc.add_css_class("dim-label"); self.desc.set_wrap(True)
        self.desc.set_wrap_mode(Pango.WrapMode.WORD)
        title_col.append(self.desc)
        top_row.append(title_col)
        self.status = Gtk.Label(label=tr("INSTALLED"))
        self.status.add_css_class("status-pill"); self.status.add_css_class("status-installed")
        self.status.set_valign(Gtk.Align.START)
        top_row.append(self.status)
        hero.append(top_row)

        meta_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.ver_badge = Gtk.Label(label="1.0.0")
        self.ver_badge.add_css_class("badge"); self.ver_badge.add_css_class("badge-local")
        meta_row.append(self.ver_badge)
        self.repo_badge = Gtk.Label(label="CORE")
        self.repo_badge.add_css_class("badge"); self.repo_badge.add_css_class("badge-core")
        meta_row.append(self.repo_badge)
        self.arch_badge = Gtk.Label(label="x86_64")
        self.arch_badge.add_css_class("badge"); self.arch_badge.add_css_class("badge-local")
        meta_row.append(self.arch_badge)
        hero.append(meta_row)

        # FlowBox instead of a fixed horizontal Box: with 5 buttons and no
        # icons, a plain Box could force horizontal scrolling in a narrow
        # window. FlowBox wraps the overflow onto a new line automatically,
        # at whatever width the window actually has, instead of us having
        # to guess a fixed breakpoint.
        hero_actions = Gtk.FlowBox()
        hero_actions.set_selection_mode(Gtk.SelectionMode.NONE)
        hero_actions.set_max_children_per_line(5)
        hero_actions.set_min_children_per_line(1)
        hero_actions.set_row_spacing(6)
        hero_actions.set_column_spacing(6)
        hero_actions.set_homogeneous(False)
        hero_actions.set_halign(Gtk.Align.START)
        self.btn_install = action_btn(
            None, tr("Install"),
            "suggested-action", "install-btn", callback=on_install)
        self.btn_install.set_sensitive(False)
        self.btn_remove = action_btn(
            None, tr("Uninstall"),
            "destructive-action", "remove-btn", callback=on_remove)
        self.btn_remove.set_sensitive(False)
        self.btn_reinstall = action_btn(
            None, tr("Reinstall"), callback=on_reinstall)
        self.btn_reinstall.set_sensitive(False)
        self.btn_reinstall.add_css_class("flat")
        self.btn_downgrade = action_btn(
            None, tr("Downgrade"), callback=on_downgrade)
        self.btn_downgrade.set_sensitive(False)
        self.btn_downgrade.add_css_class("flat")
        self.btn_hold = action_btn(
            None, tr("Ignore Updates"),
            callback=on_hold)
        self.btn_hold.set_sensitive(False)
        self.btn_hold.add_css_class("flat"); self.btn_hold.add_css_class("hold-btn")
        for btn in (self.btn_install, self.btn_remove, self.btn_reinstall,
                    self.btn_downgrade, self.btn_hold):
            flow_child = Gtk.FlowBoxChild()
            flow_child.set_focusable(False)
            flow_child.add_css_class("hero-action-cell")
            flow_child.set_child(btn)
            hero_actions.append(flow_child)
        hero.append(hero_actions)
        detail_box.append(hero)

        # Tabs
        self.view_stack = Adw.ViewStack()
        switcher = Adw.ViewSwitcher()
        switcher.set_stack(self.view_stack)
        switcher.set_policy(Adw.ViewSwitcherPolicy.WIDE)
        detail_box.append(switcher)

        # Info tab
        info_scroll = Gtk.ScrolledWindow()
        info_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        info_scroll.set_min_content_height(200)
        info_inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        info_inner.set_margin_start(4); info_inner.set_margin_end(4)
        info_group = Adw.PreferencesGroup()
        info_group.set_title(tr("Package Information"))
        info_inner.append(info_group)
        for key in self.INFO_KEYS:
            if key in self.DEP_KEYS:
                exp_row = Adw.ExpanderRow()
                exp_row.set_title(tr(key)); exp_row.set_subtitle("—")
                flow = Gtk.FlowBox()
                flow.set_selection_mode(Gtk.SelectionMode.NONE)
                flow.set_column_spacing(6); flow.set_row_spacing(6)
                flow.set_margin_start(12); flow.set_margin_end(12)
                flow.set_margin_top(8); flow.set_margin_bottom(10)
                flow_row = Gtk.ListBoxRow()
                flow_row.set_activatable(False)
                flow_row.set_child(flow)
                exp_row.add_row(flow_row)
                info_group.add(exp_row)
                self.dep_rows[key] = (exp_row, flow)
                self.info_rows[key] = exp_row
            else:
                row = Adw.ActionRow()
                row.set_title(tr(key)); row.set_subtitle("—")
                row.set_subtitle_selectable(True)
                info_group.add(row)
                self.info_rows[key] = row

        raw_group = Adw.PreferencesGroup()
        raw_group.set_title(tr("Raw Output"))
        info_inner.append(raw_group)
        raw_exp = Adw.ExpanderRow()
        raw_exp.set_title(tr("pacman -Qi output") if distro.is_arch() else tr("Raw package info"))
        raw_exp.set_subtitle(tr("Full package information"))
        raw_group.add(raw_exp)
        raw_scroll = Gtk.ScrolledWindow()
        raw_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        raw_scroll.set_min_content_height(120); raw_scroll.set_max_content_height(240)
        self.raw_text = Gtk.Label(label="")
        self.raw_text.set_selectable(True); self.raw_text.set_wrap(True)
        self.raw_text.set_wrap_mode(Pango.WrapMode.CHAR)
        self.raw_text.add_css_class("monospace"); self.raw_text.add_css_class("caption")
        self.raw_text.set_xalign(0)
        self.raw_text.set_margin_start(12); self.raw_text.set_margin_end(12)
        self.raw_text.set_margin_top(8); self.raw_text.set_margin_bottom(8)
        raw_scroll.set_child(self.raw_text)
        raw_exp.add_row(raw_scroll)
        info_scroll.set_child(info_inner)
        self.view_stack.add_titled_with_icon(
            info_scroll, "info", tr("Info"), "dialog-information-symbolic")

        # Files tab — virtualized ListView with a FilterListModel doing the
        # filtering, so typing in the search box never rebuilds the rows.
        files_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        files_hdr = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        files_hdr.set_margin_start(6); files_hdr.set_margin_end(6)
        files_hdr.set_margin_top(6); files_hdr.set_margin_bottom(4)
        self.files_search = Gtk.SearchEntry()
        self.files_search.set_placeholder_text(tr("Filter…"))
        self.files_search.set_hexpand(True)
        self.files_search.connect("search-changed", self._on_files_filter_changed)
        files_hdr.append(self.files_search)
        self.files_count_lbl = Gtk.Label(label="")
        self.files_count_lbl.add_css_class("caption"); self.files_count_lbl.add_css_class("dim-label")
        self.files_count_lbl.set_halign(Gtk.Align.END)
        files_hdr.append(self.files_count_lbl)
        files_box.append(files_hdr)

        self.files_model = Gtk.StringList()
        self.files_filter = Gtk.CustomFilter.new(self._files_match)
        self.files_filter_model = Gtk.FilterListModel(model=self.files_model,
                                                      filter=self.files_filter)
        self.files_filter_model.connect("items-changed", self._update_files_count)

        files_factory = Gtk.SignalListItemFactory()
        files_factory.connect("setup", self._files_setup)
        files_factory.connect("bind",
                              lambda f, li: li.get_child().set_label(li.get_item().get_string()))
        files_scroll = Gtk.ScrolledWindow()
        files_scroll.set_vexpand(True)
        self.files_listview = Gtk.ListView(
            model=Gtk.NoSelection(model=self.files_filter_model), factory=files_factory)
        self.files_listview.add_css_class("navigation-sidebar")
        files_scroll.set_child(self.files_listview)
        files_box.append(files_scroll)
        self.view_stack.add_titled_with_icon(
            files_box, "files", tr("Files"), "folder-symbolic")

        detail_box.append(self.view_stack)
        detail_scroll.set_child(detail_box)
        self.stack.add_named(detail_scroll, "detail")
        self.stack.set_visible_child_name("empty")

    # ── Files tab helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _files_setup(factory, list_item):
        lbl = Gtk.Label()
        lbl.set_halign(Gtk.Align.START); lbl.set_selectable(True)
        lbl.add_css_class("monospace"); lbl.add_css_class("caption")
        lbl.set_margin_start(12); lbl.set_margin_top(4); lbl.set_margin_bottom(4)
        list_item.set_child(lbl)

    def _files_match(self, item):
        return (not self._files_query) or (self._files_query in item.get_string().lower())

    def _on_files_filter_changed(self, entry):
        self._files_query = entry.get_text().strip().lower()
        self.files_filter.changed(Gtk.FilterChange.DIFFERENT)

    def _update_files_count(self, *args):
        if self._files_loading:
            return
        total = self.files_model.get_n_items()
        shown = self.files_filter_model.get_n_items()
        self.files_count_lbl.set_label(
            tr("{shown} of {total} files").format(shown=shown, total=total)
            if self._files_query
            else tr("{total} files").format(total=total))

    def set_files_loading(self):
        """Clear the Files tab and show a loading placeholder."""
        self._files_loading = True
        self.files_model.splice(0, self.files_model.get_n_items(), [])
        self.files_count_lbl.set_label(tr("Loading…"))

    def set_files(self, files):
        """Populate the Files tab from raw `pacman -Ql` lines ("pkg /path")."""
        paths = []
        for line in files:
            parts = line.split(None, 1)
            paths.append(parts[1] if len(parts) == 2 else line)
        self._files_loading = False
        self.files_model.splice(0, self.files_model.get_n_items(), paths)
        self._update_files_count()

    def reveal(self):
        """Show the panel and tell the window, so the Details button follows."""
        self.stack.set_visible(True)
        if self.on_visibility:
            self.on_visibility(True)

    # ── Batch selection display ──────────────────────────────────────────────

    def show_batch(self, pkg_names):
        """Display a list of selected package names in the detail panel."""
        # Clear the listbox
        while self.batch_listbox.get_first_child():
            self.batch_listbox.remove(self.batch_listbox.get_first_child())

        if not pkg_names:
            self.stack.set_visible_child_name("empty")
            return

        for name in sorted(pkg_names):
            row = Adw.ActionRow()
            row.set_title(name)
            icon = themed_image("package-x-generic-symbolic", 18)
            icon.add_css_class("dim-label")
            row.add_prefix(icon)
            self.batch_listbox.append(row)

        self.reveal()
        self.stack.set_visible_child_name("batch")


class pachulWindow(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app)
        self.set_title("Pachul")
        self.set_default_size(1240, 780)
        self.set_size_request(900, 560)
        self._all_packages     = []
        self._selected_pkg     = None
        self._current_filter   = "not_installed"  # matches the "New" section's "Packages" row, _build_sidebar()
                                          # selects by default (nav_listbox.select_row() below
                                          # doesn't fire row-activated, so this has to be set here too)
        self._search_query     = ""      # current text in the always-visible search entry
        self._updates          = None
        self._search_timer     = None   # GLib source id for debounced search
        self._alive            = True   # set False on close to stop background workers
        self._startup_health_checked = False  # runs backend.startup_health_checks() once per session
        self._healthcheck_render = None       # set while the Startup Check dialog is open (see _on_done)
        self._current_lang     = get_language()
        # Sort order of the package list (persisted in settings.json) and
        # whether the detail panel is currently shown (not persisted — it
        # starts hidden and opens on the first package click).
        _sk = get_setting("pkg_sort_key")
        self._sort_key         = _sk if _sk in self.SORT_KEYS else "name"
        self._sort_desc        = bool(get_setting("pkg_sort_desc"))
        self._detail_enabled   = False
        # Whether "Hold/Unhold" (pacman IgnorePkg / apt-mark hold / zypper
        # lock) and "Mark as Explicit/Dependency" (pacman -D --asexplicit/
        # --asdeps / apt-mark manual|auto / dnf mark) have a real backend
        # on this distro at all — dnf has no reliable built-in hold
        # mechanism, and zypper has no simple explicit/dependency marking.
        # Computed once here so every menu/button built below can just
        # check these flags instead of re-deriving them.
        self._hold_supported = distro.is_arch() or distro.get_family() in ("debian", "suse")
        self._mark_reason_supported = distro.is_arch() or distro.get_family() in ("debian", "fedora")
        self.connect("close-request", self._on_close_request)
        self._setup_view_actions(app)
        self._build_ui()
        self._load_packages()
        GLib.idle_add(self._maybe_offer_install)

        # Add "select all" action with Ctrl+A shortcut
        select_all_action = Gio.SimpleAction.new("select_all", None)
        select_all_action.connect("activate", self._on_select_all)
        self.add_action(select_all_action)
        app.set_accels_for_action("win.select_all", ["<Ctrl>a"])

        # Add "deselect all" action with Ctrl+Shift+A shortcut
        deselect_all_action = Gio.SimpleAction.new("deselect_all", None)
        deselect_all_action.connect("activate", self._on_deselect_all)
        self.add_action(deselect_all_action)
        app.set_accels_for_action("win.deselect_all", ["<Ctrl><Shift>a"])

    # ── Sorting + detail-panel switch ────────────────────────────────────────

    SORT_KEYS = ("name", "description", "version", "repo", "status", "selected")

    def _setup_view_actions(self, app):
        """Stateful window actions: win.sort_by (radio), win.sort_desc and
        win.toggle_details (Ctrl+D). They live on the window, so they survive
        _rebuild_ui_preserving_state(); the widgets bound to them are simply
        rebuilt and pick up the current state."""
        sort_by = Gio.SimpleAction.new_stateful(
            "sort_by", GLib.VariantType.new("s"),
            GLib.Variant.new_string(self._sort_key))
        sort_by.connect("change-state", self._on_sort_by_changed)
        self.add_action(sort_by)

        sort_desc = Gio.SimpleAction.new_stateful(
            "sort_desc", None, GLib.Variant.new_boolean(self._sort_desc))
        sort_desc.connect("change-state", self._on_sort_desc_changed)
        self.add_action(sort_desc)

        toggle = Gio.SimpleAction.new_stateful(
            "toggle_details", None, GLib.Variant.new_boolean(self._detail_enabled))
        toggle.connect("change-state", self._on_toggle_details)
        self.add_action(toggle)
        app.set_accels_for_action("win.toggle_details", ["<Ctrl>d"])

    def _sort_state(self):
        return (self._sort_key, self._sort_desc)

    @staticmethod
    def _version_sort_key(version):
        """Natural ordering for version strings (1.9 < 1.10, 2:1.0 > 1:9.9).
        An approximation of the package managers' own comparison — good
        enough for sorting a list. Numbers rank above letters (1.0rc1 < 1.0)."""
        parts = re.findall(r"\d+|[A-Za-z]+", version or "")
        return [(1, int(t)) if t.isdigit() else (0, t.lower()) for t in parts]

    @staticmethod
    def _sort_packages(pkgs, key, desc, selected=frozenset()):
        """Return `pkgs` sorted by name / description / version / repository /
        status / checked-first. `selected` is a snapshot of the checkbox
        selection (selection_key values) for the "selected" order.
        Status order: pending updates first, then installed, then the rest."""
        def by_name(p):
            return p["name"].lower()
        if key == "description":
            def keyfunc(p):
                d = (p.get("description") or "").strip().lower()
                return (d == "", d, by_name(p))     # empty descriptions last
        elif key == "version":
            keyfunc = lambda p: (pachulWindow._version_sort_key(p.get("version")), by_name(p))
        elif key == "repo":
            keyfunc = lambda p: ((p.get("repo") or "").lower(), by_name(p))
        elif key == "status":
            order = {"update": 0, "installed": 1}
            keyfunc = lambda p: (order.get(p.get("status"), 2), by_name(p))
        elif key == "selected":
            def keyfunc(p):
                if p.get("repo") in ("flatpak", "snap"):
                    k = f"{p['repo']}:{p.get('source_id') or p['name']}"
                else:
                    k = p["name"]
                return (0 if k in selected else 1, by_name(p))
        else:
            keyfunc = by_name
        return sorted(pkgs, key=keyfunc, reverse=desc)

    def _on_sort_by_changed(self, action, value):
        key = value.get_string()
        if key not in self.SORT_KEYS:
            return
        action.set_state(value)
        if key == self._sort_key:
            return
        self._sort_key = key
        save_settings({"pkg_sort_key": key})
        self._apply_filter()

    def _on_sort_desc_changed(self, action, value):
        action.set_state(value)
        self._sort_desc = value.get_boolean()
        save_settings({"pkg_sort_desc": self._sort_desc})
        self._apply_filter()

    def _sync_details_state(self, shown):
        """Keep the Details button (win.toggle_details) in step with whether
        the detail panel is actually visible."""
        self._detail_enabled = shown
        act = self.lookup_action("toggle_details")
        if act is not None and act.get_state().get_boolean() != shown:
            act.set_state(GLib.Variant.new_boolean(shown))

    def _hide_detail_panel(self):
        """Hide the detail panel (back to the plain list view)."""
        self.detail_panel.stack.set_visible(False)
        self._sync_details_state(False)

    def _on_toggle_details(self, action, value):
        """Details button: off = hide the panel and return to the list view;
        on = show it again. Clicking a package always opens it as well."""
        shown = value.get_boolean()
        action.set_state(value)
        self._detail_enabled = shown
        if not shown:
            self.detail_panel.stack.set_visible(False)
            return
        # Switched on: show the current selection, or the placeholder.
        if self.pkg_sel_state.selected:
            self._update_batch_action_bar()
            return
        item = self.pkg_selection.get_selected_item()
        if item is not None:
            self._on_pkg_activated(item)
        else:
            self.detail_panel.stack.set_visible_child_name("empty")
            self.detail_panel.stack.set_visible(True)

    def _on_close_request(self, *_):
        self._alive = False
        self._cancel_search_timer()
        return False   # allow window to close

    def _maybe_offer_install(self):
        """Offer to run install.sh if Pachul is running from a source
        checkout that either:
        - was never installed system-wide, or
        - IS already installed, but this checkout carries a newer
          APP_VERSION than the installed copy (e.g. after pulling recent
          changes into a dev checkout while an older install lingers).
        A no-op once installed at the same-or-newer version, or when
        there's no install.sh next to this copy (e.g. an installed copy
        itself, which doesn't ship one)."""
        installed = is_pachul_installed()
        if installed and not pachul_update_available(APP_DIR):
            return False
        cmd = build_install_command(APP_DIR)
        if not cmd:
            return False

        d = Adw.AlertDialog()
        if installed:
            d.set_heading(tr("Update Pachul?"))
            d.set_body(tr(
                "A newer version of Pachul was found in this checkout "
                "than the one currently installed system-wide. Updating "
                "replaces the installed files with this version — this "
                "needs your password."))
            action_label = tr("Update")
            success_toast = tr("Pachul updated.")
        else:
            d.set_heading(tr("Install Pachul?"))
            d.set_body(tr(
                "Pachul isn't installed system-wide yet. Installing adds an "
                "app-menu entry and the pachul / pachul-tray commands, and "
                "installs any missing dependencies — this needs your password."))
            action_label = tr("Install")
            success_toast = tr("Pachul installed — available from the app menu from now on.")
        d.add_response("skip", tr("Not Now"))
        d.add_response("install", action_label)
        d.set_response_appearance("install", Adw.ResponseAppearance.SUGGESTED)
        d.set_default_response("install")
        d.set_close_response("skip")

        def _on_response(_dlg, resp):
            if resp == "install":
                run_terminal_dialog(
                    self, cmd, action_label,
                    on_success=lambda: self._toast(success_toast))
        d.connect("response", _on_response)
        d.present(self)
        return False   # GLib.idle_add: run once

    # ── Build UI ──────────────────────────────────────────────────────────────

    def _build_ui(self):
        self.nav_split = Adw.NavigationSplitView()
        self.nav_split.set_max_sidebar_width(230)
        self.nav_split.set_min_sidebar_width(190)
        self.nav_split.set_sidebar_width_fraction(0.20)

        # Sidebar
        sidebar_page = Adw.NavigationPage()
        sidebar_page.set_title("Pachul")
        sidebar_tv  = Adw.ToolbarView()
        sidebar_hdr = Adw.HeaderBar()
        sidebar_hdr.set_show_end_title_buttons(False)
        title_lbl = Gtk.Label(label="Pachul")
        title_lbl.add_css_class("heading")
        sidebar_hdr.set_title_widget(title_lbl)
        sidebar_tv.add_top_bar(sidebar_hdr)
        sidebar_tv.set_content(self._build_sidebar())
        sidebar_page.set_child(sidebar_tv)
        self.nav_split.set_sidebar(sidebar_page)

        # Content
        content_page = Adw.NavigationPage()
        content_page.set_title("Pachul")
        self.content_tv  = Adw.ToolbarView()
        self.content_hdr = Adw.HeaderBar()
        self.content_hdr.set_show_back_button(False)
        self.content_hdr.set_show_title(False)

        # Header bar: five text entries instead of the former tools icon
        # and hamburger menu — Packages (package actions), Tools (opens the
        # searchable tools hub, Ctrl+T), Settings (opens preferences),
        # Help and About. Every tool is reachable via toolshub.py.
        right_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)

        # ── Packages ─────────────────────────────────────────────────────
        # Opens the packages overview (same style as the tools hub).
        pkg_btn = Gtk.Button(label=tr("Packages"))
        pkg_btn.add_css_class("flat")
        pkg_btn.add_css_class("header-menu-btn")
        pkg_btn.connect("clicked", self._on_show_packages)
        right_box.append(pkg_btn)

        # ── Tools ────────────────────────────────────────────────────────
        tools_btn = Gtk.Button(label=tr("Tools"))
        tools_btn.add_css_class("flat")
        tools_btn.add_css_class("header-menu-btn")
        tools_btn.connect("clicked", self._on_show_tools)
        right_box.append(tools_btn)

        # ── Settings ─────────────────────────────────────────────────────
        # Opens the full preferences dialog directly (no dropdown).
        settings_btn = Gtk.Button(label=tr("Preferences"))
        settings_btn.add_css_class("flat")
        settings_btn.add_css_class("header-menu-btn")
        settings_btn.set_action_name("app.preferences")
        right_box.append(settings_btn)

        # ── Help ─────────────────────────────────────────────────────────
        help_btn = Gtk.Button(label=tr("Help"))
        help_btn.add_css_class("flat")
        help_btn.add_css_class("header-menu-btn")
        help_btn.set_action_name("app.shortcuts")
        right_box.append(help_btn)

        # ── About ────────────────────────────────────────────────────────
        about_btn = Gtk.Button(label=tr("About Pachul"))
        about_btn.add_css_class("flat")
        about_btn.add_css_class("header-menu-btn")
        about_btn.set_action_name("app.about")
        right_box.append(about_btn)
        self.content_hdr.pack_end(right_box)
        self.content_tv.add_top_bar(self.content_hdr)

        # Shared selection-mode state: one flag + one selected-name set,
        # kept as its own object since the package list panel is rebuilt
        # (e.g. on language change) while this state should persist.
        self.pkg_sel_state = ListSelectionState()

        self.content_tv.set_content(self._build_list_detail_paned())
        content_page.set_child(self.content_tv)
        self.nav_split.set_content(content_page)

        self._toast_overlay = Adw.ToastOverlay()
        self._toast_overlay.set_child(self.nav_split)
        self.set_content(self._toast_overlay)

    # ── List + Detail ────────────────────────────────────────────────────────

    def _build_list_detail_paned(self):
        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        paned.set_start_child(self._build_package_list_panel())
        paned.set_resize_start_child(True)
        paned.set_shrink_start_child(False)
        paned.set_end_child(self._build_detail_panel())
        paned.set_resize_end_child(True)
        paned.set_shrink_end_child(False)
        paned.set_position(460)
        return paned

    # ── Sidebar ───────────────────────────────────────────────────────────────

    def _build_sidebar(self):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_vexpand(True)

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        outer.set_margin_top(8); outer.set_margin_bottom(16)

        # Stat strip
        stats_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        stats_box.set_margin_start(10); stats_box.set_margin_end(10)
        stats_box.set_margin_top(4); stats_box.set_margin_bottom(12)
        self.stat_total   = self._stat_card("—", tr("TOTAL"),   "stat-card")
        self.stat_aur     = self._stat_card("—", tr("AUR"),     "stat-card-aur")
        self.stat_updates = self._stat_card("—", tr("UPDATES"), "stat-card-updates")
        for card in (self.stat_total, self.stat_aur, self.stat_updates):
            stats_box.append(card)
        outer.append(stats_box)

        # Top level: "All Packages" and "Updates" first, per explicit
        # request — everything else lives in the sections below.
        self.nav_listbox = Gtk.ListBox()
        self.nav_listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.nav_listbox.add_css_class("navigation-sidebar")
        self.nav_listbox.set_margin_start(5); self.nav_listbox.set_margin_end(5)
        self.nav_listbox.connect("row-activated", self._on_nav_selected)

        self._nav_rows = {}
        top_items = [
            ("all",     "view-list-symbolic",   tr("All Packages"), None, None),
            ("updates", ICON_UPDATE_AVAILABLE,  tr("Updates"),       0,    "count-update"),
        ]
        for key, icon, label, cnt, badge_cls in top_items:
            row = NavRow(icon, label, cnt, badge_cls)
            self.nav_listbox.append(row)
            self._nav_rows[key] = row
        outer.append(self.nav_listbox)

        # "New" section: everything not yet installed, browsable by source
        # — grouped under one header so individual labels don't each need
        # to repeat "New" themselves. Per-repo rows here mirror the
        # "Installed Packages" section below one-for-one (same repo, same
        # icon, same label) — built together from the same pre-seed list
        # so the two sections can't drift apart, and kept in sync
        # afterwards by the same dynamic-discovery loop in
        # _update_sidebar_counts().
        outer.append(self._separator())
        outer.append(self._sidebar_header(tr("NEW")))
        self.new_listbox = Gtk.ListBox()
        self.new_listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.new_listbox.add_css_class("navigation-sidebar")
        self.new_listbox.set_margin_start(5); self.new_listbox.set_margin_end(5)
        self.new_listbox.connect("row-activated", self._on_new_nav_selected)

        self._new_nav_rows = {}
        self._repo_icon_map = {
            "core":      "drive-harddisk-symbolic",
            "extra":     "folder-symbolic",
            "multilib":  "folder-symbolic",
            "aur":       "application-x-executable-symbolic",
            "community": "folder-open-symbolic",
            "testing":   "folder-visiting-symbolic",
            "flatpak":   "package-x-generic-symbolic",
            "snap":      "package-x-generic-symbolic",
            "chaotic-aur": "folder-remote-symbolic",
        }
        # Repos pre-seeded in both sections regardless of whether any
        # package from them has loaded yet — core/extra/multilib/aur are
        # Arch's own repo layout specifically; Flatpak is opt-in
        # (flatpak_enabled setting) and only meaningful once the flatpak
        # binary is actually present. Everything else (chaotic-aur, snap,
        # any other repo/category) appears organically in both sections
        # together, once packages load, via the same dynamic
        # _repo_nav_rows/_new_nav_rows mechanism in _update_sidebar_counts().
        preseed_repos = []
        if distro.is_arch():
            preseed_repos += ["core", "extra", "multilib", "aur"]
        if get_setting("flatpak_enabled") and flatpak_available():
            preseed_repos.append("flatpak")

        row = NavRow("list-add-symbolic", tr("All New Packages"), 0, "count-new")
        self.new_listbox.append(row)
        self._new_nav_rows["not_installed"] = row
        for key in preseed_repos:
            row = NavRow(self._repo_icon_map[key], key, 0, "count-new")
            self.new_listbox.append(row)
            self._new_nav_rows[f"new:{key}"] = row
        self.new_listbox.select_row(self._new_nav_rows["not_installed"])
        outer.append(self.new_listbox)

        # Installed Packages (was "Repositories" — renamed since every row
        # here, "All Installed Packages" included, is about what's already
        # on the system, browsable by where it came from).
        outer.append(self._separator())
        outer.append(self._sidebar_header(tr("INSTALLED PACKAGES")))
        self.repo_listbox = Gtk.ListBox()
        self.repo_listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.repo_listbox.add_css_class("navigation-sidebar")
        self.repo_listbox.set_margin_start(5); self.repo_listbox.set_margin_end(5)
        self.repo_listbox.connect("row-activated", self._on_repo_nav_selected)

        self._repo_nav_rows = {}
        # "All Installed Packages" always comes first in this section,
        # regardless of distro — it's the "installed" browse filter
        # (status installed/update), just relocated here from the top
        # section and relabelled to match its new context.
        installed_row = NavRow("emblem-ok-symbolic", tr("All Installed Packages"), 0, None)
        self.repo_listbox.append(installed_row)
        self._repo_nav_rows["installed"] = installed_row
        for key in preseed_repos:
            row = NavRow(self._repo_icon_map[key], key, 0, "count-badge")
            self.repo_listbox.append(row)
            self._repo_nav_rows[key] = row
        outer.append(self.repo_listbox)

        # Tools
        scroll.set_child(outer)
        return scroll

    def _sidebar_header(self, text):
        lbl = Gtk.Label(label=text)
        lbl.add_css_class("sidebar-section")
        lbl.set_halign(Gtk.Align.CENTER); lbl.set_hexpand(True)
        return lbl

    def _separator(self):
        sep = Gtk.Separator()
        sep.set_margin_top(8); sep.set_margin_start(14); sep.set_margin_end(14)
        return sep

    def _stat_card(self, number, label, css_class="stat-card"):
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        card.add_css_class(css_class); card.set_hexpand(True)
        num = Gtk.Label(label=number)
        num.add_css_class("stat-number"); num.add_css_class("numeric"); num.set_halign(Gtk.Align.CENTER)
        lbl = Gtk.Label(label=label)
        lbl.add_css_class("stat-label"); lbl.set_halign(Gtk.Align.CENTER)
        card.append(num); card.append(lbl)
        card._num = num
        return card

    # ── Package list panel ────────────────────────────────────────────────────

    def _build_package_list_panel(self):
        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        search_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        search_box.set_margin_top(8); search_box.set_margin_bottom(8)
        search_box.set_margin_start(10); search_box.set_margin_end(10)
        self.search_entry = Gtk.Entry()
        self.search_entry.set_placeholder_text(tr("Search packages, e.g. firefox, vlc, git…"))
        self.search_entry.set_hexpand(True)
        self.search_entry.set_icon_from_icon_name(
            Gtk.EntryIconPosition.PRIMARY, "system-search-symbolic")
        self.search_entry.set_icon_from_icon_name(
            Gtk.EntryIconPosition.SECONDARY, "edit-clear-symbolic")
        self.search_entry.set_icon_sensitive(Gtk.EntryIconPosition.SECONDARY, False)
        self.search_entry.connect("changed", self._on_search_changed)
        self.search_entry.connect("activate", self._on_search_activate)
        self.search_entry.connect("icon-press", self._on_search_icon_press)
        search_box.append(self.search_entry)

        # Sort menu: radio items for name/repository/status + a checkbox
        # for descending order (win.sort_by / win.sort_desc actions).
        sort_menu = Gio.Menu()
        sort_by_section = Gio.Menu()
        sort_by_section.append(tr("Name"),           "win.sort_by::name")
        sort_by_section.append(tr("Description"),    "win.sort_by::description")
        sort_by_section.append(tr("Version"),        "win.sort_by::version")
        sort_by_section.append(tr("Repository"),     "win.sort_by::repo")
        sort_by_section.append(tr("Status"),         "win.sort_by::status")
        sort_by_section.append(tr("Selected first"), "win.sort_by::selected")
        sort_menu.append_section(tr("Sort by"), sort_by_section)
        order_section = Gio.Menu()
        order_section.append(tr("Descending order"), "win.sort_desc")
        sort_menu.append_section(None, order_section)
        self.sort_btn = Gtk.MenuButton()
        self.sort_btn.set_menu_model(sort_menu)
        self.sort_btn.set_child(themed_image("pachul-sort-symbolic", 18))
        self.sort_btn.add_css_class("flat")
        self.sort_btn.set_margin_start(6)
        self.sort_btn.set_tooltip_text(tr("Sort packages"))
        search_box.append(self.sort_btn)

        # Details switch: icon-only toggle button (Ctrl+D) that shows/hides
        # the package detail panel. Bound to the stateful
        # win.toggle_details action, so it stays in sync with it.
        self.details_btn = Gtk.ToggleButton()
        self.details_btn.set_child(themed_image("pachul-details-symbolic", 18))
        self.details_btn.add_css_class("flat")
        self.details_btn.set_margin_start(2)
        self.details_btn.set_action_name("win.toggle_details")
        self.details_btn.set_tooltip_text(tr("Show or hide the package details (Ctrl+D)"))
        search_box.append(self.details_btn)
        panel.append(search_box)
        panel.append(Gtk.Separator())

        self.pkg_scroll = Gtk.ScrolledWindow()
        pkg_scroll = self.pkg_scroll
        pkg_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        pkg_scroll.set_vexpand(True)
        self.pkg_listview, self.pkg_store, self.pkg_selection, self.pkg_sel_state = \
            make_package_listview(self._on_pkg_activated, self._update_batch_action_bar,
                                   sel_state=self.pkg_sel_state)
        pkg_scroll.set_child(self.pkg_listview)

        spinner_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        spinner_box.set_halign(Gtk.Align.CENTER); spinner_box.set_valign(Gtk.Align.CENTER)
        self.spinner = Gtk.Spinner()
        self.spinner.set_size_request(32, 32)
        sp_lbl = Gtk.Label(label=tr("Loading packages…"))
        sp_lbl.add_css_class("dim-label")
        spinner_box.append(self.spinner); spinner_box.append(sp_lbl)

        # Built to match the DetailPanel's empty-state sizing exactly (36px
        # icon, title-4) rather than Adw.StatusPage's much larger defaults,
        # so the two side-by-side empty states look consistent.
        self.empty_updates_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.empty_updates_page.set_valign(Gtk.Align.CENTER)
        self.empty_updates_page.set_halign(Gtk.Align.CENTER)
        self.empty_updates_page.set_vexpand(True)
        self.empty_updates_page.set_hexpand(True)
        _eu_icon = themed_image("emblem-ok-symbolic", 36)
        _eu_icon.add_css_class("dim-label")
        _eu_icon.set_halign(Gtk.Align.CENTER)
        self.empty_updates_page.append(_eu_icon)
        self._empty_updates_title = Gtk.Label(label=tr("System is up to date"))
        self._empty_updates_title.add_css_class("title-4")
        self._empty_updates_title.set_halign(Gtk.Align.CENTER)
        self._empty_updates_title.set_justify(Gtk.Justification.CENTER)
        self.empty_updates_page.append(self._empty_updates_title)
        self._empty_updates_desc = Gtk.Label(label=tr("No pending updates found."))
        self._empty_updates_desc.add_css_class("dim-label")
        self._empty_updates_desc.set_halign(Gtk.Align.CENTER)
        self._empty_updates_desc.set_justify(Gtk.Justification.CENTER)
        self._empty_updates_desc.set_wrap(True)
        self._empty_updates_desc.set_max_width_chars(40)
        self.empty_updates_page.append(self._empty_updates_desc)

        self.empty_generic_page = Adw.StatusPage()
        self.empty_generic_page.set_paintable(themed_paintable("system-search-symbolic", 72))
        self.empty_generic_page.set_title(tr("No Packages Found"))
        self.empty_generic_page.set_description(tr("Try a different filter or search term."))

        self.list_stack = Gtk.Stack()
        self.list_stack.set_vexpand(True)
        self.list_stack.set_transition_type(Gtk.StackTransitionType.NONE)
        self.list_stack.add_named(spinner_box,             "loading")
        self.list_stack.add_named(pkg_scroll,              "list")
        self.list_stack.add_named(self.empty_updates_page, "empty_updates")
        self.list_stack.add_named(self.empty_generic_page, "empty_generic")
        self.list_stack.set_visible_child_name("loading")
        panel.append(self.list_stack)

        # A plain Box instead of Gtk.ActionBar, deliberately: ActionBar (like
        # GtkCenterBox) centers its middle widget by reserving symmetric
        # space matching whichever side — start or end — is wider. The
        # Install/Uninstall pair and the Upgrade-All/Check-for-Updates pair
        # are mutually exclusive here and have quite different label
        # lengths (especially once translated), so that symmetric
        # reservation kept swinging the bar's minimum width up and down as
        # the sidebar filter changed — forcing the package-list column to
        # either widen past where the divider was set, or clip its
        # content, depending on how the paned's shrink setting was
        # configured. A plain Box with only the count label set to expand
        # sidesteps that: the label gets whatever space is left over and
        # centers within it, without dictating extra minimum width.
        action_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        action_bar.add_css_class("toolbar")   # same style class GtkActionBar applies itself
        action_bar.set_margin_start(6); action_bar.set_margin_end(6)
        start_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        end_box   = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)

        # Select all button
        self.btn_select_all = Gtk.Button()
        set_button_icon(self.btn_select_all, "edit-select-all-symbolic")
        self.btn_select_all.set_tooltip_text(tr("Select all visible packages"))
        self.btn_select_all.connect("clicked", self._on_select_all)
        self.btn_select_all.add_css_class("flat")
        self.btn_select_all.set_visible(True)
        start_box.append(self.btn_select_all)

        # Deselect all button
        self.btn_deselect_all = Gtk.Button()
        set_button_icon(self.btn_deselect_all, "edit-clear-all-symbolic")
        self.btn_deselect_all.set_tooltip_text(tr("Deselect all packages"))
        self.btn_deselect_all.connect("clicked", self._on_deselect_all)
        self.btn_deselect_all.add_css_class("flat")
        self.btn_deselect_all.set_visible(False)
        start_box.append(self.btn_deselect_all)

        self.btn_install = self._action_btn(
            None, tr("Install"),
            "suggested-action", "install-btn", callback=self._on_install)
        self.btn_install.set_sensitive(False)
        start_box.append(self.btn_install)

        self.pkg_count_label = Gtk.Label(label="")
        self.pkg_count_label.add_css_class("caption"); self.pkg_count_label.add_css_class("dim-label")
        self.pkg_count_label.set_hexpand(True)
        self.pkg_count_label.set_halign(Gtk.Align.CENTER)
        self.pkg_count_label.set_ellipsize(Pango.EllipsizeMode.END)

        self.btn_remove = self._action_btn(
            None, tr("Uninstall"),
            "destructive-action", "remove-btn", callback=self._on_remove)
        self.btn_remove.set_sensitive(False)
        end_box.append(self.btn_remove)

        self.btn_hold = self._action_btn(
            None, tr("Ignore Updates"), callback=self._on_batch_hold)
        self.btn_hold.set_sensitive(False)
        self.btn_hold.add_css_class("flat"); self.btn_hold.add_css_class("hold-btn")
        end_box.append(self.btn_hold)

        self.btn_upgrade_all = self._action_btn(
            None, tr("Upgrade All"),
            "suggested-action", callback=self._on_upgrade)
        self.btn_upgrade_all.set_sensitive(False); self.btn_upgrade_all.set_visible(False)
        start_box.append(self.btn_upgrade_all)

        self.btn_check_updates = self._action_btn(
            None, tr("Check for Updates"), callback=self._on_check_updates)
        self.btn_check_updates.set_visible(False)
        end_box.append(self.btn_check_updates)

        action_bar.append(start_box)
        action_bar.append(self.pkg_count_label)
        action_bar.append(end_box)

        panel.append(action_bar)
        return panel

    @staticmethod
    def _set_btn_label(btn, text):
        # Buttons built by _action_btn wrap an icon + label in a Box; find the
        # Gtk.Label child and update its text.
        child = btn.get_child().get_first_child()
        while child:
            if isinstance(child, Gtk.Label):
                child.set_label(text)
                return
            child = child.get_next_sibling()

    def _action_btn(self, icon, label, *css_classes, callback=None):
        btn = Gtk.Button()
        btn.add_css_class("pill-btn")
        for cls in css_classes:
            btn.add_css_class(cls)
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        inner.set_margin_start(4); inner.set_margin_end(4)
        if icon:
            ic = themed_image(icon, 18)
            inner.append(ic)
        inner.append(Gtk.Label(label=label))
        btn.set_child(inner)
        if callback:
            btn.connect("clicked", callback)
        return btn

    # ── Detail panel ──────────────────────────────────────────────────────────

    def _build_detail_panel(self):
        self.detail_panel = DetailPanel(
            self._action_btn, self._on_install, self._on_remove,
            self._on_reinstall,
            lambda *_: self._on_downgrade(from_panel=True),
            on_hold=lambda *_: self._on_toggle_hold(from_panel=True))
        self.detail_panel.dep_callback = self._lookup_dep_in_list
        self.detail_panel.aur_ahead_banner.connect(
            "button-clicked", self._on_aur_ahead_install_clicked)
        self._aur_ahead_pkg_name = None
        self._aur_ahead_token = 0
        # Hold/Ignore-Updates only has a real backend on some distros (see
        # _hold_supported above) — rather than leave a button that always
        # just fails, hide it outright where it can never do anything.
        # Downgrade always has *some* backend now (repo history and/or a
        # local package cache, however sparse), so it stays visible
        # everywhere and just shows "no older version found" when empty.
        self.detail_panel.btn_hold.set_visible(self._hold_supported)
        # Right-hand detail panel starts hidden — at launch nothing is
        # selected yet, so showing an empty "Select a Package" pane just
        # wastes half the window. It's revealed the moment a package (or
        # a batch selection) is actually shown, in _show_detail() and
        # DetailPanel.show_batch(); until then the Paned gives the
        # package list the full width.
        self.detail_panel.on_visibility = self._sync_details_state
        self.detail_panel.stack.set_visible(False)
        self._sync_details_state(False)
        return self.detail_panel.stack

    # ── Data loading ──────────────────────────────────────────────────────────

    def _load_packages(self):
        self.list_stack.set_visible_child_name("loading")
        self.spinner.start()
        threading.Thread(target=self._load_worker, daemon=True).start()

    def _load_worker(self):
        pkgs = get_packages()
        if self._alive:
            GLib.idle_add(self._on_packages_loaded, pkgs)

    def _on_packages_loaded(self, packages):
        self._all_packages = packages
        self.spinner.stop()
        # Carry over the known update markers so a reload doesn't wipe them.
        self._reapply_update_markers()
        self._update_sidebar_counts()
        self._apply_filter()
        # Real per-program icons (installed repo/AUR + Flatpak) are resolved
        # from local .desktop files — no network involved, but scanning them
        # and looking up owning packages still takes a moment, so it's done
        # in the background rather than blocking this load. The list is
        # re-filtered/re-rendered once the map is ready so icons pop in
        # without needing a manual refresh.
        threading.Thread(target=self._bg_build_icon_map, daemon=True).start()
        # Versions of not-yet-installed AUR packages: the list above already
        # shows whatever the local cache has; on every program start the
        # current AUR data is fetched once in the background (~10 MB, never
        # blocks the UI) and the rows are filled in place — so new packages
        # and new versions show up without waiting for the cache to expire.
        if (distro.is_arch() and not getattr(self, "_aur_meta_attempted", False)
                and any(p.get("repo") == "aur" and p.get("status") == "available"
                        for p in packages)):
            self._aur_meta_attempted = True
            threading.Thread(target=self._bg_refresh_aur_meta, daemon=True).start()
        # Re-verify updates: on first load when the setting allows it, and on
        # every reload once we've checked before (e.g. after a package op, so
        # an updated package leaves the Updates list).
        if self._updates is not None or get_setting("check_updates_on_start"):
            threading.Thread(target=self._bg_check_updates, daemon=True).start()
        # Startup problem scan — once per session, and only if the user
        # hasn't turned it off in Preferences. Runs well after the package
        # list itself, so it never delays the window becoming usable.
        if not self._startup_health_checked and get_setting("startup_healthcheck_enabled"):
            self._startup_health_checked = True
            threading.Thread(target=self._bg_startup_health_check, daemon=True).start()
        return False

    def _bg_refresh_aur_meta(self):
        meta = refresh_aur_meta()
        if not meta and self._alive:
            # Offline or AUR briefly unreachable right at start: try once more.
            time.sleep(30)
            if self._alive:
                meta = refresh_aur_meta()
        if meta and self._alive:
            GLib.idle_add(self._on_aur_meta_ready, meta)

    def _on_aur_meta_ready(self, meta):
        """Fresh AUR versions arrived: update the package data (for future
        filters/searches) and the rows already on screen, in place — a
        rebind instead of a re-filter, so scroll position and selection
        stay exactly as they are."""
        apply_aur_meta(self._all_packages, meta)
        changed = False
        for item in self._iter_known_packages():
            if item.pkg_repo == "aur" and item.pkg_status == "available":
                m = meta.get(item.pkg_name)
                if m:
                    item.pkg_version = m[0]
                    if not item.pkg_description:
                        item.pkg_description = m[1]
                    changed = True
        if changed:
            self._rebind_all_rows()
            sel = self._selected_pkg
            if (sel is not None and sel.pkg_repo == "aur"
                    and sel.pkg_status == "available"
                    and getattr(self.detail_panel, "_current_pkg_name", None) == sel.pkg_name):
                self.detail_panel.ver_badge.set_label(sel.pkg_version)
        return False

    def _bg_startup_health_check(self):
        findings = startup_health_checks()
        if self._alive:
            GLib.idle_add(self._on_startup_health_result, findings)

    def _on_startup_health_result(self, findings):
        if self._alive and not findings:
            # A dialog just to say "all fine" would be noisy at every
            # single startup — a self-dismissing toast fits a plain
            # all-clear better and doesn't demand a click.
            self._toast(tr("Startup check: no problems found"))
        elif self._alive:
            dlg, render = show_startup_healthcheck_dialog(
                self, findings, self._activate_healthcheck_action,
                rescan_fn=self._rescan_health_async)
            # Kept so a repair run elsewhere (see _on_done below) or the
            # dialog's own "Check again" button can update this same list
            # in place; cleared once the dialog closes so a stray repair
            # afterwards doesn't try to redraw a disposed dialog.
            self._healthcheck_render = render

            def _on_closed(*_):
                self._healthcheck_render = None
                return False
            dlg.connect("close-request", _on_closed)
        return False

    def _activate_healthcheck_action(self, action_name):
        """Dispatches a finding's "action" (a _on_show_* method name) from
        the startup health-check summary dialog — the same handlers the
        sidebar menu and app.py's GActions already call."""
        handler = getattr(self, action_name, None)
        if handler:
            handler()

    def _rescan_health_async(self, on_done):
        """Re-runs backend.startup_health_checks() in the background and
        hands the fresh list to `on_done` (called on the GTK main thread)
        — used both by the health-check dialog's own "Check again" button
        and, automatically, after any terminal command finishes while
        that dialog is still open (see _on_done)."""
        def worker():
            findings = startup_health_checks()
            if self._alive:
                GLib.idle_add(on_done, findings)
        threading.Thread(target=worker, daemon=True).start()

    def _bg_build_icon_map(self):
        mapping = build_desktop_icon_map()
        if self._alive:
            GLib.idle_add(self._on_icon_map_built, mapping)

    def _on_icon_map_built(self, mapping):
        set_installed_icon_map(mapping)
        self._apply_filter()
        return False

    def _bg_check_updates(self):
        updates = check_updates()
        if self._alive:
            GLib.idle_add(self._on_updates_loaded, updates)

    def _notify_updates(self, n):
        app = self.get_application()
        if app is None:
            return
        notif = Gio.Notification.new(tr("Updates Available"))
        notif.set_body(
            tr("{n} package update can be installed.").format(n=n) if n == 1
            else tr("{n} package updates can be installed.").format(n=n))
        notif.set_priority(Gio.NotificationPriority.NORMAL)
        # An absolute file path, not a bare icon name — the notification
        # daemon (a separate KDE/Qt process under Plasma) resolves a name
        # against the active icon theme itself, which can silently fail
        # the same way GTK's own lookup did (see icons.py's docstring).
        icon_path = os.path.join(APP_DIR, "io.github.wergosam.pachul.svg")
        if not os.path.isfile(icon_path):
            icon_path = "/usr/share/icons/hicolor/scalable/apps/io.github.wergosam.pachul.svg"
        if os.path.isfile(icon_path):
            notif.set_icon(Gio.FileIcon.new(Gio.File.new_for_path(icon_path)))
        app.send_notification("pachul-updates", notif)

    def _on_updates_loaded(self, updates):
        prev_n = len(self._updates) if self._updates else 0
        self._updates = updates
        n = len(updates)
        self.stat_updates._num.set_label(str(n))
        self._nav_rows["updates"].set_count(n)
        # Desktop notification when the update count first rises.
        if n > 0 and n != prev_n and get_setting("notify_updates"):
            self._notify_updates(n)
        self._empty_updates_desc.set_label(
            tr("No pending updates found.") if n == 0
            else tr("{n} update(s) available.").format(n=n))
        self._update_action_bar_mode()
        self._reapply_update_markers()
        self._apply_filter()
        return False

    def _reapply_update_markers(self):
        """Sync the 'update' status on _all_packages with the current
        self._updates set. Marks pending updates and clears stale ones, so a
        fresh package reload (e.g. after installing/updating) reflects reality.

        Matching uses source_id when a package has one — Flatpak/Snap
        entries carry their app-id/package name there (what the actual
        update commands and check_updates() both key off), which can
        differ from the friendly display name in `name`. Plain pacman/AUR
        packages never set source_id, so they fall back to `name` as before.
        """
        update_map = {u["name"]: u["new"] for u in (self._updates or [])}
        for pkg in self._all_packages:
            key = pkg.get("source_id") or pkg["name"]
            if key in update_map:
                pkg["status"] = "update"
                pkg["new_version"] = update_map[key]
            elif pkg.get("status") == "update":
                pkg["status"] = "installed"
                pkg.pop("new_version", None)

    def _update_sidebar_counts(self):
        total         = len(self._all_packages)
        foreign       = sum(1 for p in self._all_packages if p.get("foreign", False))
        installed     = sum(1 for p in self._all_packages if p["status"] in ("installed", "update"))
        not_installed = total - installed
        self.stat_total._num.set_label(str(total))
        self.stat_aur._num.set_label(str(foreign))
        self._repo_nav_rows["installed"].set_count(installed)
        self._new_nav_rows["not_installed"].set_count(not_installed)

        # Discover repos dynamically, exactly as before — except a newly-
        # seen repo now gets a row in *both* sections at once (Installed
        # Packages: installed/updated only; New: not-yet-installed only),
        # so the two stay in lockstep with no separate wiring per repo.
        seen_repos = set(
            p.get("repo", "").lower() for p in self._all_packages
            if p.get("repo", "") not in ("local", "")
        )
        for repo_key in sorted(seen_repos):
            if repo_key not in self._repo_nav_rows:
                icon = self._repo_icon_map.get(repo_key, "folder-symbolic")
                row = NavRow(icon, repo_key, 0, "count-badge")
                self.repo_listbox.append(row)
                self._repo_nav_rows[repo_key] = row
            new_key = f"new:{repo_key}"
            if new_key not in self._new_nav_rows:
                icon = self._repo_icon_map.get(repo_key, "folder-symbolic")
                row = NavRow(icon, repo_key, 0, "count-new")
                self.new_listbox.append(row)
                self._new_nav_rows[new_key] = row

        always_visible = ("core", "extra", "multilib", "aur", "flatpak")
        for repo_key, nav_row in self._repo_nav_rows.items():
            if repo_key == "installed":
                continue  # handled above — "installed" is a status filter,
                          # not an actual repo name, and lives in this same
                          # dict only for its Installed Packages section spot
            installed_count = sum(
                1 for p in self._all_packages
                if p.get("repo", "").lower() == repo_key and p["status"] in ("installed", "update")
            )
            nav_row.set_count(installed_count)
            nav_row.set_visible(installed_count > 0 or repo_key in always_visible)

            new_row = self._new_nav_rows.get(f"new:{repo_key}")
            if new_row is not None:
                new_count = sum(
                    1 for p in self._all_packages
                    if p.get("repo", "").lower() == repo_key
                    and p["status"] not in ("installed", "update")
                )
                new_row.set_count(new_count)
                new_row.set_visible(new_count > 0 or repo_key in always_visible)

    # ── Filtering ─────────────────────────────────────────────────────────────

    @staticmethod
    def _pkg_matches_filter(pkg, filt):
        """True if pkg should be shown under sidebar filter `filt`.

        `filt` is one of the special keys (installed/not_installed/updates/
        all), a literal repo name (the "Installed Packages" section —
        installed/updated packages from that repo only), or "new:<repo>"
        (the "New" section's per-repo rows — not-yet-installed packages
        from that repo only). Repo names are matched generically — not
        against a hardcoded shortlist — so any repo discovered at runtime
        (chaotic-aur, testing, community, flatpak, snap, …) is filterable
        in both sections as soon as it gets a sidebar row, with no extra
        wiring needed here per repo. "aur" is one such repo name, not a
        special key of its own — every foreign package's repo is always
        set to "aur" (see backend.py's merge logic), so the generic
        repo-name match below already covers it correctly.
        """
        if filt == "installed":
            return pkg["status"] in ("installed", "update")
        if filt == "not_installed":
            return pkg["status"] not in ("installed", "update")
        if filt == "updates":
            return pkg.get("status") == "update"
        if filt in (None, "all"):
            return True
        if filt.startswith("new:"):
            return (pkg.get("repo", "").lower() == filt[4:]
                    and pkg["status"] not in ("installed", "update"))
        return (pkg.get("repo", "").lower() == filt
                and pkg["status"] in ("installed", "update"))

    @staticmethod
    def _pkg_matches_search(pkg, query):
        """True if pkg matches the free-text search query (empty query always matches)."""
        if not query:
            return True
        q = query.lower()
        return q in pkg["name"].lower() or q in pkg.get("description", "").lower()

    def _apply_filter(self):
        """Filter (sidebar category + search text) in a background thread,
        render in batches to avoid UI freeze."""
        filt  = self._current_filter
        query = self._search_query
        sort  = self._sort_state()
        selected = frozenset(self.pkg_sel_state.selected)
        pkgs_snapshot = list(self._all_packages)

        def do_filter():
            filtered = [p for p in pkgs_snapshot
                        if self._pkg_matches_filter(p, filt)
                        and self._pkg_matches_search(p, query)]
            filtered = self._sort_packages(filtered, *sort, selected=selected)
            if self._alive:
                GLib.idle_add(self._render_filter_results, filtered, filt, query, sort)

        threading.Thread(target=do_filter, daemon=True).start()

    @staticmethod
    def _make_item(p):
        return PackageItem(
            p["name"], p["version"], p.get("repo", "local"), p["status"],
            p.get("description", ""), p.get("foreign", False), p.get("source_id"),
            p.get("new_version", ""))

    def _fill_pkg_store(self, filtered):
        # One splice replaces the whole list; the ListView renders only the
        # visible rows, so there's no need to chunk widget creation any more.
        items = [self._make_item(p) for p in filtered]
        self.pkg_store.splice(0, self.pkg_store.get_n_items(), items)

    def _render_filter_results(self, filtered, filt, query, sort=None):
        if not self._alive or self._current_filter != filt or self._search_query != query:
            return False
        if sort is not None and sort != self._sort_state():
            return False   # sort order changed meanwhile — a newer render is on its way
        self._fill_pkg_store(filtered)
        total = len(self._all_packages)
        shown = len(filtered)
        self._list_count_label_text = (
            f"{shown} of {total} packages" if shown != total else f"{total} packages")
        # A checkbox selection persists across filter/search changes, so
        # its "N selected" text takes priority over the plain list count —
        # _update_batch_action_bar() is what owns the label in that case.
        if not self.pkg_sel_state.selected:
            self.pkg_count_label.set_label(self._list_count_label_text)
        if shown == 0:
            self.list_stack.set_visible_child_name(
                "empty_updates" if filt == "updates" and not query and self._updates is not None
                else "empty_generic")
            # Nothing to select any more (e.g. right after an upgrade the
            # updates list goes to zero) — hide the right-hand detail
            # column too, the same way _on_nav_selected() already does when
            # navigating away from a selected package. Otherwise it keeps
            # showing its "Select a Package" placeholder, leaving a
            # pointless 3-column layout (menu / "up to date" / placeholder)
            # instead of just menu + "up to date".
            self._hide_detail_panel()
        else:
            self.list_stack.set_visible_child_name("list")
        return False

    # ── Search ────────────────────────────────────────────────────────────────

    SEARCH_DEBOUNCE_MS = 280

    def _cancel_search_timer(self):
        if self._search_timer is not None:
            GLib.source_remove(self._search_timer)
            self._search_timer = None

    def _on_search_changed(self, entry):
        q = entry.get_text().strip()
        self.search_entry.set_icon_sensitive(Gtk.EntryIconPosition.SECONDARY, bool(q))
        self._cancel_search_timer()
        self._search_query = q
        # Instant local re-filter on every keystroke — cheap, in-memory only.
        self._apply_filter()
        if not q:
            return
        # Defer the expensive, subprocess-spawning remote lookup (repos +
        # AUR) until typing pauses, so new/not-yet-known packages can still
        # surface without a query on every keystroke.
        self._search_timer = GLib.timeout_add(
            self.SEARCH_DEBOUNCE_MS, self._run_remote_search, q)

    def _on_search_activate(self, *_):
        q = self.search_entry.get_text().strip()
        self._cancel_search_timer()
        self._search_query = q
        self._apply_filter()
        if q:
            self._run_remote_search(q)

    def _on_search_icon_press(self, entry, icon_pos):
        if icon_pos == Gtk.EntryIconPosition.SECONDARY:
            entry.set_text("")   # fires _on_search_changed, which clears the filter

    def _run_remote_search(self, q):
        self._search_timer = None

        def worker():
            remote = search_packages_cmd(q)
            if self._alive:
                GLib.idle_add(self._merge_remote_search, remote, q)

        threading.Thread(target=worker, daemon=True).start()
        return False   # one-shot: do not repeat the timeout

    def _merge_remote_search(self, remote_results, query):
        # Ignore stale results if the query changed while we were waiting.
        if self._search_query != query:
            return False
        existing = {p["name"] for p in self._all_packages}
        found_new = False
        for r in remote_results:
            if r["name"] not in existing:
                self._all_packages.append(r)
                existing.add(r["name"])
                found_new = True
        if found_new:
            self._update_sidebar_counts()
            self._apply_filter()
        return False

    # ── Nav ───────────────────────────────────────────────────────────────────

    def _grab_search_focus(self):
        # Run-once idle callback: grab_focus() returns True, so passing it
        # straight to GLib.idle_add would re-run it on every idle cycle —
        # repeatedly re-selecting the entry's text so each typed character
        # replaces the previous one. Returning False removes the idle source.
        self.search_entry.grab_focus()
        self.search_entry.set_position(-1)   # cursor to end, clears the selection
        return False

    def _on_nav_selected(self, listbox, row):
        self.new_listbox.unselect_all()
        self.repo_listbox.unselect_all()
        # Clicking any sidebar entry (Updates, Installed, orphans, …) is a
        # fresh navigation away from whatever package/batch was shown
        # before — hide the detail panel again so it doesn't keep showing
        # stale info until something new gets clicked in the list.
        self._hide_detail_panel()
        keys = list(self._nav_rows.keys())
        idx  = row.get_index()
        if idx >= len(keys):
            return
        key = keys[idx]
        if key == "orphans":
            self._on_show_orphans()
            return
        self._current_filter = key
        self._update_action_bar_mode()
        self._apply_filter()

    def _on_new_nav_selected(self, listbox, row):
        self.nav_listbox.unselect_all()
        self.repo_listbox.unselect_all()
        self._hide_detail_panel()
        keys = list(self._new_nav_rows.keys())
        idx  = row.get_index()
        if idx < len(keys):
            self._current_filter = keys[idx]
        self._update_action_bar_mode()
        self._apply_filter()

    def _on_repo_nav_selected(self, listbox, row):
        self.nav_listbox.unselect_all()
        self.new_listbox.unselect_all()
        self._hide_detail_panel()
        keys = list(self._repo_nav_rows.keys())
        idx  = row.get_index()
        if idx < len(keys):
            self._current_filter = keys[idx]
        self._update_action_bar_mode()
        self._apply_filter()

    def _update_action_bar_mode(self):
        is_updates = (self._current_filter == "updates")
        # There's no separate selection "mode" any more — checkboxes are
        # always available. The moment something is checked, the action bar
        # switches to the batch Install/Remove buttons no matter which
        # sidebar filter is active; with nothing checked it falls back to
        # the Updates-specific buttons (or the single-package ones, handled
        # in _update_batch_action_bar).
        has_selection = len(self.pkg_sel_state.selected) > 0
        show_batch_buttons = has_selection or not is_updates
        self.btn_install.set_visible(show_batch_buttons)
        self.btn_remove.set_visible(show_batch_buttons)
        self.btn_hold.set_visible(has_selection and self._hold_supported)
        self.btn_upgrade_all.set_visible(is_updates and not has_selection)
        self.btn_check_updates.set_visible(is_updates and not has_selection)
        if is_updates and not has_selection:
            n = len(self._updates) if self._updates else 0
            self.btn_upgrade_all.set_sensitive(n > 0)

        self.btn_deselect_all.set_visible(has_selection)

    # ── Package detail ────────────────────────────────────────────────────────

    def _on_pkg_activated(self, pkg):
        if pkg is None:
            return
        self._selected_pkg = pkg
        installed = pkg.pkg_status in ("installed", "update")
        # An "update" package is installed but upgradable — Install stays
        # active and runs `pacman -S`, which upgrades that single package.
        can_install = pkg.pkg_status != "installed"
        install_label = tr("Update") if pkg.pkg_status == "update" else tr("Install")
        self._set_btn_label(self.detail_panel.btn_install, install_label)
        self.detail_panel.btn_install.set_sensitive(can_install)
        self.detail_panel.btn_remove.set_sensitive(installed)
        self.detail_panel.btn_reinstall.set_sensitive(installed)
        self.detail_panel.btn_downgrade.set_sensitive(installed)
        # Hold/ignore (IgnorePkg) only makes sense for pacman/AUR packages —
        # Flatpak/Snap have their own update mechanisms outside pacman.conf.
        if pkg.pkg_repo in ("flatpak", "snap"):
            self.detail_panel.btn_hold.set_sensitive(False)
            self._set_btn_label(self.detail_panel.btn_hold, tr("Ignore Updates"))
        else:
            held = pkg.pkg_name in get_ignored_packages()
            self._set_btn_label(
                self.detail_panel.btn_hold,
                tr("Unignore") if held else tr("Ignore Updates"))
            self.detail_panel.btn_hold.set_sensitive(True)
        # A row click always opens that package's detail view — even with
        # a checkbox selection active elsewhere, so a person can still peek
        # at a package before deciding whether to check it too. But the
        # bottom action bar (Install/Remove) must keep reflecting the
        # actual checked set in that case, not silently switch to acting
        # on whatever was last peeked at.
        if not self.pkg_sel_state.selected:
            self._set_btn_label(self.btn_install, install_label)
            self.btn_install.set_sensitive(can_install)
            self.btn_remove.set_sensitive(installed)
        self._show_detail(self.detail_panel, pkg)
        self._check_aur_ahead(pkg)
        self._ensure_aur_version(pkg)

    def _ensure_aur_version(self, pkg):
        """An AUR package with no known version (it is newer than the daily
        AUR dump in the local cache, or that download hasn't finished / failed):
        ask the AUR RPC for just this one package and fill the version in."""
        if not (distro.is_arch() and pkg.pkg_repo == "aur"
                and pkg.pkg_status == "available" and not pkg.pkg_version):
            return
        name = pkg.pkg_name

        def worker():
            info = get_aur_info(name)
            if info and info.get("Version") and self._alive:
                GLib.idle_add(self._on_aur_version_fetched, name, info)

        threading.Thread(target=worker, daemon=True).start()

    def _on_aur_version_fetched(self, name, info):
        ver  = info.get("Version") or ""
        desc = info.get("Description") or ""
        if not ver:
            return False
        for p in self._all_packages:
            if p["name"] == name and p.get("repo") == "aur" and p.get("status") == "available":
                p["version"] = ver
                if not p.get("description"):
                    p["description"] = desc
        for item in self._iter_known_packages():
            if (item.pkg_name == name and item.pkg_repo == "aur"
                    and item.pkg_status == "available"):
                item.pkg_version = ver
                if not item.pkg_description:
                    item.pkg_description = desc
        self._rebind_all_rows()
        sel = self._selected_pkg
        if (sel is not None and sel.pkg_name == name
                and getattr(self.detail_panel, "_current_pkg_name", None) == name):
            self.detail_panel.ver_badge.set_label(version_text(sel))
            if desc and sel.pkg_description == desc:
                self.detail_panel.desc.set_label(desc)
        return False

    def _check_aur_ahead(self, pkg):
        """Kick off a background check of whether this (plain-repo)
        package also exists on the true AUR at a newer version — the
        "arch-update" case. Only meaningful for pacman-tracked packages
        that are actually installed; foreign/AUR-only packages already go
        through the AUR helper directly, and Flatpak/Snap aren't relevant
        here at all."""
        self.detail_panel.aur_ahead_banner.set_revealed(False)
        self._aur_ahead_token += 1
        token = self._aur_ahead_token
        if (pkg.pkg_repo in ("flatpak", "snap") or pkg.pkg_foreign
                or pkg.pkg_status not in ("installed", "update") or not pkg.pkg_version):
            return
        name, version = pkg.pkg_name, pkg.pkg_version

        def worker():
            newer = check_aur_ahead_of_repo(name, version)
            GLib.idle_add(self._on_aur_ahead_result, name, newer, token)

        threading.Thread(target=worker, daemon=True).start()

    def _on_aur_ahead_result(self, name, newer_version, token):
        # Stale result from a package the person has since clicked away
        # from (or a newer check for the same package already superseded
        # this one) — drop it silently.
        if token != self._aur_ahead_token or not self._selected_pkg \
                or self._selected_pkg.pkg_name != name:
            return False
        if newer_version:
            self._aur_ahead_pkg_name = name
            banner = self.detail_panel.aur_ahead_banner
            banner.set_title(tr("Newer version {v} available on the AUR")
                             .format(v=newer_version))
            banner.set_button_label(tr("Install from AUR"))
            banner.set_revealed(True)
        return False

    def _on_aur_ahead_install_clicked(self, *_):
        name = self._aur_ahead_pkg_name
        if not name:
            return
        helper = self._get_aur_helper()
        if not helper:
            self._toast(tr("No AUR helper found"))
            return
        self.detail_panel.aur_ahead_banner.set_revealed(False)
        # No --noconfirm: see _install_cmd_for — the repo-vs-AUR prompt
        # this deliberately triggers (the person is explicitly choosing
        # the AUR build over the repo's own version) needs real input.
        # pachuli instead uses -a/--aur-only (force_aur=True) to force the
        # AUR build outright, deterministically skipping its own repo-
        # preferring classification, so no prompt is needed there either.
        cmd = aur_helper_install_cmd(helper, shlex.quote(name), noconfirm=False, force_aur=True)
        self._run_terminal(cmd, tr("Install {n} from AUR").format(n=name),
                           on_success=self._refresh_selected_pkg)

    def _set_status_pill(self, panel, status, foreign):
        for cls in ("status-installed", "status-available", "status-update", "status-foreign"):
            panel.status.remove_css_class(cls)
        if status == "update":
            panel.status.set_label(tr("UPDATE AVAILABLE"))
            panel.status.add_css_class("status-update")
        elif status == "installed":
            if foreign:
                panel.status.set_label(tr("INSTALLED (AUR)"))
                panel.status.add_css_class("status-foreign")
            else:
                panel.status.set_label(tr("INSTALLED"))
                panel.status.add_css_class("status-installed")
        else:
            panel.status.set_label(tr("AVAILABLE"))
            panel.status.add_css_class("status-available")

    def _show_detail(self, panel, pkg):
        """Fill `panel`'s hero with `pkg`, then load its info/files in a thread."""
        panel._current_pkg_name = pkg.pkg_name
        panel.name.set_label(pkg.pkg_name)
        panel.desc.set_label(pkg.pkg_description or tr("No description available."))
        real_tex = resolve_real_icon_paintable(pkg, 58)
        if real_tex is not None:
            panel.icon.set_from_paintable(real_tex)
        else:
            _tex = get_icon_texture(pkg_icon(pkg.pkg_name), 58)
            if _tex is not None:
                panel.icon.set_from_paintable(_tex)
            else:
                panel.icon.set_from_icon_name(pkg_icon(pkg.pkg_name))
            # Not-yet-installed Flatpak packages have no local .desktop file
            # to resolve an icon from — Flathub still publishes one though
            # (see backend.fetch_flatpak_icon()), so fetch it once in the
            # background and swap the symbolic icon out if it arrives while
            # this panel is still showing the same package.
            if pkg.pkg_repo == "flatpak" and pkg.pkg_source_id:
                threading.Thread(target=self._bg_fetch_detail_flatpak_icon,
                                  args=(panel, pkg), daemon=True).start()

        repo_str = "aur" if pkg.pkg_foreign else (pkg.pkg_repo or "local").lower()
        panel.repo_badge.set_label(repo_str.upper())
        for cls in REPO_BADGE_CLASS.values():
            panel.repo_badge.remove_css_class(cls)
        panel.repo_badge.add_css_class(REPO_BADGE_CLASS.get(repo_str, "badge-local"))
        panel.ver_badge.set_label(version_text(pkg))
        self._set_status_pill(panel, pkg.pkg_status, pkg.pkg_foreign)

        panel.reveal()
        panel.stack.set_visible_child_name("detail")
        for row in panel.info_rows.values():
            if isinstance(row, Adw.ActionRow):
                row.set_subtitle("…")
        for exp_row, _ in panel.dep_rows.values():
            exp_row.set_subtitle("…")
        panel.raw_text.set_label(tr("Loading…"))
        panel.set_files_loading()

        def worker():
            if pkg.pkg_repo in ("flatpak", "snap"):
                source_label = tr("Flatpak") if pkg.pkg_repo == "flatpak" \
                    else tr("Snap package")
                info = (
                    f"Name           : {pkg.pkg_name}\n"
                    f"Version        : {pkg.pkg_version}\n"
                    f"Description    : {pkg.pkg_description or '—'}\n"
                    f"Install Reason : {source_label}\n"
                )
                if pkg.pkg_repo == "flatpak" and pkg.pkg_source_id:
                    info += f"URL            : https://flathub.org/apps/{pkg.pkg_source_id}\n"
                files = []
            else:
                info  = get_package_info(pkg.pkg_name)
                files = get_package_files(pkg.pkg_name)
            if self._alive:
                GLib.idle_add(self._populate_detail, panel, info, files)
        threading.Thread(target=worker, daemon=True).start()

    def _bg_fetch_detail_flatpak_icon(self, panel, pkg):
        ok = fetch_flatpak_icon(pkg.pkg_source_id)
        if ok and self._alive:
            GLib.idle_add(self._on_detail_flatpak_icon_fetched, panel, pkg)

    def _on_detail_flatpak_icon_fetched(self, panel, pkg):
        # Only swap the icon in if this panel is still showing the same
        # package — the user may have clicked something else in the
        # meantime while the download was in flight.
        if panel._current_pkg_name != pkg.pkg_name:
            return False
        tex = get_flatpak_icon_paintable(pkg.pkg_source_id, 58)
        if tex is not None:
            panel.icon.set_from_paintable(tex)
        return False

    def _populate_detail(self, panel, raw, files):
        panel.raw_text.set_label(raw)
        parsed = self._parse_pkginfo(raw)
        for key in DetailPanel.INFO_KEYS:
            val = parsed.get(key, "—") or "—"
            if val in ("None", ""):
                val = "—"
            if key in panel.dep_rows:
                exp_row, flow = panel.dep_rows[key]
                self._populate_dep_flow(panel, flow, exp_row, val)
            elif key in panel.info_rows:
                self._set_info_subtitle(panel.info_rows[key], key, val)
        panel.arch_badge.set_label(parsed.get("Architecture", "x86_64"))
        panel.set_files(files)
        return False


    def _set_info_subtitle(self, row, key, val):
        """Set an ActionRow subtitle, rendering URL fields as a clickable link."""
        esc = GLib.markup_escape_text(val)
        if key == "URL" and val.startswith(("http://", "https://")):
            row.set_subtitle(f'<a href="{esc}">{esc}</a>')
        else:
            row.set_subtitle(esc)

    def _parse_pkginfo(self, raw):
        """Parse pacman -Qi / -Si output handling multi-line values correctly."""
        parsed = {}
        current_key = None
        for line in raw.splitlines():
            if line and not line[0].isspace() and ":" in line:
                k, _, v = line.partition(":")
                current_key = k.strip()
                val = v.strip()
                parsed[current_key] = val
            elif current_key and line.startswith(" ") and line.strip():
                # continuation — append to current key
                parsed[current_key] = parsed[current_key] + " " + line.strip()
        return parsed

    def _populate_dep_flow(self, panel, flow, exp_row, val):
        while flow.get_first_child():
            flow.remove(flow.get_first_child())
        if val == "—":
            exp_row.set_subtitle("—")
            exp_row.set_expanded(False)
            return
        import re
        # Each dep token may look like: "libfoo>=1.0" or "libfoo: for something"
        # Split on whitespace first, then strip version constraints and inline descriptions
        raw_tokens = val.split()
        dep_names = []
        for token in raw_tokens:
            # Skip pure description words (tokens after a "name:" token)
            # A dep token starts with a letter/number and contains the package name
            if not token or token[0] in (":", "(", ")"):
                continue
            # Strip inline description separator "name:" — take only up to the colon
            name_part = token.split(":")[0]
            # Strip version constraints
            clean = re.split(r"[><=!]", name_part)[0].strip()
            if clean and re.match(r"^[a-zA-Z0-9_@.+-]+$", clean):
                dep_names.append(clean)
        # Deduplicate while preserving order
        seen = set()
        dep_names = [d for d in dep_names if not (d in seen or seen.add(d))]
        exp_row.set_subtitle(
            tr("{n} package").format(n=len(dep_names)) if len(dep_names) == 1
            else tr("{n} packages").format(n=len(dep_names)))
        # Cap the chip count — fields like "Required By" can list thousands of
        # packages, and one Gtk.Button each would be slow to build.
        CHIP_CAP = 80
        for dep in dep_names[:CHIP_CAP]:
            btn = Gtk.Button(label=dep)
            btn.add_css_class("dep-chip")
            btn.set_tooltip_text(tr("Look up {dep}").format(dep=dep))
            btn.connect("clicked", lambda b, name=dep: panel.dep_callback(name))
            flow.append(btn)
        if len(dep_names) > CHIP_CAP:
            more = Gtk.Label(label=tr("+{n} more").format(n=len(dep_names) - CHIP_CAP))
            more.add_css_class("dim-label"); more.add_css_class("caption")
            flow.append(more)

    def _highlight_in_store(self, store, selection, listview, pkg_name):
        """Select (but do not activate) the row for pkg_name; scroll it into view."""
        for i in range(store.get_n_items()):
            if store.get_item(i).pkg_name == pkg_name:
                selection.set_selected(i)
                listview.scroll_to(i, Gtk.ListScrollFlags.FOCUS, None)
                return True
        return False

    def _lookup_dep_in_list(self, pkg_name):
        """Highlight a dependency package in the package list, broadening the
        view (and fetching it remotely if needed) so it's visible even if
        it isn't installed or doesn't match the current filter/search."""
        # Try the current view first
        if self._highlight_in_store(self.pkg_store, self.pkg_selection,
                                    self.pkg_listview, pkg_name):
            return

        # Not visible under the current filter/search — broaden to "All
        # Packages" with no search text, then try again.
        self._current_filter = "all"
        self._search_query = ""
        self.search_entry.set_text("")
        self.nav_listbox.select_row(self._nav_rows["all"])

        def after_filter():
            if self._highlight_in_store(self.pkg_store, self.pkg_selection,
                                        self.pkg_listview, pkg_name):
                return False
            # Still not found — not installed and not yet in our repo/AUR
            # cache. Look it up remotely and prepend it once found.
            for pkg in self._all_packages:
                if pkg["name"] == pkg_name:
                    self.pkg_store.insert(0, self._make_item(pkg))
                    self.pkg_selection.set_selected(0)
                    self.pkg_listview.scroll_to(0, Gtk.ListScrollFlags.FOCUS, None)
                    return False

            def worker():
                results = search_packages_cmd(pkg_name)
                if self._alive:
                    GLib.idle_add(self._prepend_dep_result, pkg_name, results)

            threading.Thread(target=worker, daemon=True).start()
            return False

        self._apply_filter_then(after_filter)

    def _apply_filter_then(self, callback):
        """Apply the current filter + search text; run callback once rendered."""
        filt  = self._current_filter
        query = self._search_query
        sort  = self._sort_state()
        selected = frozenset(self.pkg_sel_state.selected)
        pkgs_snapshot = list(self._all_packages)

        def do_filter():
            filtered = [p for p in pkgs_snapshot
                        if self._pkg_matches_filter(p, filt)
                        and self._pkg_matches_search(p, query)]
            filtered = self._sort_packages(filtered, *sort, selected=selected)
            if self._alive:
                GLib.idle_add(self._render_filter_results_then, filtered, filt, query, callback, sort)

        threading.Thread(target=do_filter, daemon=True).start()

    def _render_filter_results_then(self, filtered, filt, query, callback, sort=None):
        """Same as _render_filter_results but fires `callback` once rendered."""
        if not self._alive or self._current_filter != filt or self._search_query != query:
            return False
        if sort is not None and sort != self._sort_state():
            return False
        self._fill_pkg_store(filtered)
        total = len(self._all_packages)
        shown = len(filtered)
        self._list_count_label_text = (
            f"{shown} of {total} packages" if shown != total else f"{total} packages")
        if not self.pkg_sel_state.selected:
            self.pkg_count_label.set_label(self._list_count_label_text)
        if shown == 0:
            self.list_stack.set_visible_child_name(
                "empty_updates" if filt == "updates" and not query and self._updates is not None
                else "empty_generic")
        else:
            self.list_stack.set_visible_child_name("list")
        if callback:
            GLib.idle_add(callback)
        return False

    def _prepend_dep_result(self, pkg_name, results):
        for r in results:
            if r["name"] == pkg_name:
                if r["name"] not in {p["name"] for p in self._all_packages}:
                    self._all_packages.append(r)
                self.pkg_store.insert(0, self._make_item(r))
                self.pkg_selection.set_selected(0)
                self.pkg_listview.scroll_to(0, Gtk.ListScrollFlags.FOCUS, None)
                return
        return False

    # ── Actions ───────────────────────────────────────────────────────────────

    def _toast(self, text, timeout=4):
        toast = Adw.Toast()
        toast.set_title(text)
        toast.set_timeout(timeout)
        try:
            self._toast_overlay.add_toast(toast)
        except AttributeError:
            pass

    def _run_terminal(self, cmd, title, on_success=None, parent=None, target_window=None,
                       on_success_with_window=None):
        # parent defaults to the main window, but callers that are
        # themselves opening this from an already-open modal dialog (e.g.
        # Preferences) should pass that dialog instead — otherwise the
        # terminal window ends up transient to the main window while a
        # different modal dialog is still on top of it, which briefly
        # confuses the compositor's stacking and can trigger a harmless
        # "Trying to snapshot GtkGizmo ... without a current allocation"
        # GTK warning right as the terminal window first appears.
        def _on_done(code):
            if code == 0:
                invalidate_cache()
                # If the Startup Check dialog is still open, a just-applied
                # fix (repair command, service enabled, etc.) should be
                # able to disappear from its list without waiting for the
                # next app launch — re-run the checks and refresh it in
                # place. Cheap to skip: this is a plain attribute, not a
                # dialog method call, when that dialog isn't open.
                if self._healthcheck_render is not None:
                    self._rescan_health_async(self._healthcheck_render)
            # Adw.Toast.set_title() parses its text as Pango markup (it
            # supports "<a href>" action links), so an unescaped "&" in
            # *title* — e.g. "Firewall installieren & aktivieren" —
            # throws a markup-parse GTK-WARNING instead of showing the
            # toast. Escape it the same way _row() does for row titles.
            safe_title = GLib.markup_escape_text(title)
            self._toast(f"✓ {safe_title} completed" if code == 0
                        else f"✗ {safe_title} failed (exit {code})")
            self._load_packages()
        run_terminal_dialog(parent or self, cmd, title, on_success=on_success,
                             on_done_extra=_on_done, target_window=target_window,
                             on_success_with_window=on_success_with_window)

    def _on_refresh(self, *_):
        self._all_packages = []
        self._updates = None
        self._search_query = ""
        self.search_entry.set_text("")
        self.detail_panel.stack.set_visible_child_name("empty")
        self._selected_pkg = None
        self.pkg_sel_state.selected.clear()
        self._update_action_bar_mode()
        self.btn_install.set_sensitive(False)
        self.btn_remove.set_sensitive(False)
        self._load_packages()

    def _on_sync_db(self, *_):
        def _do_sync():
            invalidate_syncdb_cache()
            cmd = "pkexec /usr/bin/pacman -Sy --noconfirm" if distro.is_arch() else pkgmanager.sync_db_cmd()
            self._run_terminal(cmd, tr("Sync Databases"))
        show_sync_db_dialog(self, _do_sync)

    def _on_upgrade(self, *_):
        self._do_upgrade()

    def _do_upgrade(self):
        # Set below, before _after() actually runs, if this upgrade run
        # also had to install pachuli first — read inside the closure at
        # call time, so the later assignment is still visible here.
        install_pachuli_cmd = None

        def _after():
            if install_pachuli_cmd:
                # pachuli is on the system now — drop backend's cached
                # helper lookup (see _get_aur_helper() above) so the very
                # next AUR action picks it up instead of still reporting
                # whatever helper was resolved before this run.
                save_settings({})
            self._updates = []
            self.stat_updates._num.set_label("0")
            self._nav_rows["updates"].set_count(0)
            # Nur das interne Update-Tracking zu leeren reicht nicht — die
            # mittlere Paketliste (list_stack) rendert dadurch nicht neu und
            # bleibt auf dem alten Stand stehen. _load_packages() lädt die
            # Pakete neu, wendet den aktuellen Filter erneut an und zeigt so
            # wieder die reguläre Ansicht (inkl. "Keine Updates"-Platzhalter,
            # falls auf der Updates-Seite), statt dass die Mitte leer bleibt.
            self._load_packages()
            # Nudge any running tray icon to re-check right now instead of
            # leaving it on whatever stale count it last saw until its own
            # periodic timer fires — see notify_tray_recheck()'s docstring.
            notify_tray_recheck()

        def _strip(c):
            return c[len("pkexec "):] if c and c.startswith("pkexec ") else c

        def _best_effort(parts):
            """Join steps so every one runs regardless of whether an
            earlier one failed, and none of their exit codes can escape
            this fragment (each is wrapped in its own `{ ...; } || true`)."""
            return "; ".join(f"{{ {p}; }} || true" for p in parts if p)

        # Use the AUR helper if present so repo *and* AUR packages are upgraded.
        # Note: pacman's -Syu already covers every repo listed in
        # /etc/pacman.conf uniformly (core, extra, multilib, chaotic-aur,
        # ...) — there's no per-repo command needed for those.
        helper = self._get_aur_helper()

        # pachuli is preferred under "auto" (see _find_aur_helper()), and
        # can also be pinned explicitly. Until now this only handled
        # pachuli being completely missing from PATH (silently falling
        # back to something else under "auto", or to no AUR helper at
        # all when pinned) — it now also picks up a newer local
        # pachuli.py sitting next to Pachul's own files than whatever is
        # currently installed, and reinstalls it as the first step of
        # this very upgrade run, instead of requiring a separate manual
        # trip to Preferences first either way.
        pref = get_setting("aur_helper")
        if distro.is_arch() and pref in ("auto", "pachuli"):
            local_pachuli = local_pachuli_path(APP_DIR)
            if local_pachuli and pachuli_update_available(local_pachuli):
                install_pachuli_cmd = get_pachuli_install_cmd(local_pachuli)
                if not pachuli_installed():
                    helper = "pachuli"

        if helper:
            main_cmd = aur_helper_upgrade_cmd(helper)
        elif distro.is_arch():
            # --ask 4 = ALPM_QUESTION_CONFLICT_PKG: beantwortet die Frage
            # "X und Y stehen in Konflikt. Y entfernen?" mit Ja. Unter
            # --noconfirm gilt sonst der Standard "N", das Upgrade bricht
            # dann an Konflikten ab (z. B. plasma-x11-session bei Plasma
            # 6.8). Abhängigkeiten werden von pacman weiterhin geprüft.
            main_cmd = "pkexec /usr/bin/pacman -Syu --noconfirm --ask 4"
        else:
            main_cmd = pkgmanager.upgrade_all_cmd()

        snap_cmd = build_snapshot_cmd() if get_setting("snapshot_before_upgrade") else None
        snap_refresh_cmd = ("pkexec /usr/bin/snap refresh"
                             if get_setting("snap_enabled") and snap_available() else None)

        # Auxiliary steps below (Snap refresh, Flatpak updates, every
        # opted-into "More Update Sources" tool) must NEVER be able to
        # mask a successful package upgrade by returning their own
        # non-zero exit code — e.g. ClamAV's freshclam is documented to
        # exit non-zero just for "no update needed", not an actual
        # failure (same class of quirk on_done() already special-cases
        # for fwupdmgr above). Since on_success — and with it, clearing
        # the Updates list — is driven entirely by this command's exit
        # code, letting any of these leak their own status through would
        # make a perfectly successful upgrade look failed and silently
        # skip clearing the list, even though nothing about the upgrade
        # itself was wrong.
        aux_root_steps, aux_plain_steps = [], []
        has_pkexec_extra = False
        if snap_refresh_cmd:
            aux_root_steps.append(_strip(snap_refresh_cmd))
        for name, extra_cmd in get_enabled_auto_update_commands():
            header = f'echo; echo "=== {name} ==="; echo; '
            if extra_cmd.startswith("pkexec "):
                aux_root_steps.append(header + _strip(extra_cmd))
                has_pkexec_extra = True
            else:
                aux_plain_steps.append(header + extra_cmd)
        if get_setting("flatpak_enabled") and flatpak_available():
            aux_plain_steps.append("flatpak update -y")

        # Bundle every pkexec-prefixed step we control into ONE `pkexec
        # bash -c '...'` call, so only one native Polkit dialog appears
        # for all of them together — chaining them as separate
        # `pkexec X && pkexec Y` calls each need their own authentication,
        # and a second, unannounced dialog popping up mid-upgrade is easy
        # to miss (it doesn't visually stand out from the terminal window
        # it appears next to), which looks exactly like the upgrade
        # silently hanging. Only *our own* pkexec calls can be merged this
        # way — an AUR helper's own internal `sudo` is a separate
        # mechanism we don't control and can't fold in (bundling it into
        # our pkexec's bash -c would also incorrectly run the helper
        # itself as root, which yay/paru both refuse to do).
        if main_cmd.startswith("pkexec "):
            # Native pacman/dnf/apt/zypper path — snapshot gates the main
            # upgrade (a failed snapshot deliberately stops it, since
            # that's the whole point of taking one first), then the
            # gate's own exit code is captured and restored at the very
            # end regardless of what the best-effort steps do.
            if snap_cmd or aux_root_steps:
                gate = _strip(main_cmd)
                if snap_cmd:
                    gate = f"{_strip(snap_cmd)} && {gate}"
                if aux_root_steps:
                    inner = f"{gate}; _RC=$?; {_best_effort(aux_root_steps)}; exit $_RC"
                else:
                    inner = gate
                cmd = "pkexec /usr/bin/bash -c " + shlex.quote(inner)
            else:
                # Nothing to combine — keep this a direct, unwrapped
                # pkexec call. Confirmed via testing: wrapping even a
                # single command in `pkexec bash -c '...'` can make some
                # Polkit setups silently fall back to a plain-text
                # terminal password prompt instead of the native dialog,
                # even though `pkexec pacman ...` alone shows it correctly
                # on that very same system.
                cmd = main_cmd
        else:
            # AUR-helper path: main_cmd has its own internal sudo we can't
            # fold in. Snapshot still gates the upgrade (a failed snapshot
            # deliberately blocks it — that's the whole point of taking
            # one first); snap-refresh/pkexec-needing tool updates are
            # merged into the same authentication purely to share it, not
            # to affect that gate, so their own exit code is captured and
            # discarded the same way as in the native branch above.
            snap_stripped = _strip(snap_cmd) if snap_cmd else None
            if snap_stripped and aux_root_steps:
                inner = f"{snap_stripped}; _RC=$?; {_best_effort(aux_root_steps)}; exit $_RC"
                pre = "pkexec /usr/bin/bash -c " + shlex.quote(inner)
                cmd = f"{pre} && {main_cmd}"
            elif snap_stripped:
                # Only the snapshot, nothing else to combine it with —
                # keep it a direct, unwrapped pkexec call (see the
                # native-path comment above for why this matters).
                cmd = f"{snap_cmd} && {main_cmd}"
            elif len(aux_root_steps) == 1 and snap_refresh_cmd and not has_pkexec_extra:
                # The only aux step is a bare `snap refresh`, no snapshot
                # and no extra-tool update involved — likewise keep it a
                # direct pkexec call, just wrapped in `{ ...; } || true`
                # at the outer shell level (not inside pkexec's own
                # target) so its failure can't block the helper's upgrade.
                cmd = f"{{ {snap_refresh_cmd}; }} || true && {main_cmd}"
            elif aux_root_steps:
                # Multiple items, or an extra-tool step that already needs
                # a shell for its own echo header regardless — bundling
                # here is unavoidable.
                pre = "pkexec /usr/bin/bash -c " + shlex.quote(_best_effort(aux_root_steps))
                cmd = f"{{ {pre}; }} || true && {main_cmd}"
            else:
                cmd = main_cmd

        if aux_plain_steps:
            cmd = f"{{ {cmd}; }}; _RC=$?; {_best_effort(aux_plain_steps)}; exit $_RC"

        if install_pachuli_cmd:
            # Its own separate `pkexec install ...` call, run first and
            # gating everything after it — same reasoning as the
            # snapshot gate above: if pachuli can't be installed, don't
            # proceed as if it were, since main_cmd already assumes it's
            # there (aur_helper_upgrade_cmd("pachuli")).
            cmd = f"{install_pachuli_cmd} && {cmd}"

        # While building an AUR package, makepkg installs missing build
        # dependencies itself and by default asks for the password through
        # plain sudo in the terminal. If makepkg.conf has no PACMAN_AUTH yet,
        # point it at pkexec first, so that step gets the same graphical
        # prompt as everything else. One extra authentication, only until it
        # is set (at most 3 attempts, in case the dialog gets dismissed); a
        # failed or cancelled attempt never stops the upgrade itself, and an
        # existing custom PACMAN_AUTH is left alone.
        if helper and distro.is_arch() and makepkg_auth_needs_setup():
            tries = int(get_setting("makepkg_pkexec_attempts") or 0)
            if tries < 3:
                save_settings({"makepkg_pkexec_attempts": tries + 1})
                note = shlex.quote(":: " + tr("Setting up makepkg to use pkexec for build dependencies (one-time)…"))
                cmd = f"{{ echo {note}; {get_makepkg_pkexec_cmd()}; }}; {cmd}"

        self._run_terminal(cmd, tr("System Upgrade"), on_success=_after)

    def _on_clean_cache(self, *_):
        show_clean_cache_dialog(self, self._run_terminal)

    def _on_check_updates(self, *_):
        helper = self._get_aur_helper()
        aur_section = (
            "echo; echo '== AUR =='; "
            f"_aur_out=$({helper} -Qua 2>/dev/null); "
            "if [ -n \"$_aur_out\" ]; then echo \"$_aur_out\"; "
            "else echo '(No AUR updates found.)'; fi; "
        ) if helper else ""
        flatpak_section = (
            "echo; echo '== Flatpak =='; "
            "flatpak update --appstream 2>/dev/null; "
            "_fp_out=$(flatpak remote-ls --updates --all "
            "--columns=application,version 2>/dev/null); "
            "if [ -n \"$_fp_out\" ]; then echo \"$_fp_out\"; "
            "else echo '(No Flatpak updates found.)'; fi; "
        ) if (get_setting("flatpak_enabled") and flatpak_available()) else ""
        snap_section = (
            "echo; echo '== Snap =='; "
            "_snap_out=$(snap refresh --list 2>/dev/null | tail -n +2); "
            "if [ -n \"$_snap_out\" ]; then echo \"$_snap_out\"; "
            "else echo '(No Snap updates found.)'; fi; "
        ) if (get_setting("snap_enabled") and snap_available()) else ""
        if distro.is_arch():
            repo_section = (
                "echo '== Official Repositories =='; "
                "if command -v checkupdates >/dev/null 2>&1; then "
                "_repo_out=$(checkupdates 2>/dev/null); "
                "else "
                "_repo_out=$(pacman -Qu 2>/dev/null); "
                "echo '(Note: pacman-contrib/checkupdates not found -- checked against the "
                "last-synced local database instead of a live one. Install pacman-contrib, "
                "or run Sync Databases first, for a fully up-to-date check.)'; "
                "fi; "
                "if [ -n \"$_repo_out\" ]; then echo \"$_repo_out\"; "
                "else echo '(No repo updates found.)'; fi; "
            )
        else:
            preview_cmd = pkgmanager.check_updates_preview_cmd() or "true"
            repo_section = (
                "echo '== Repositories =='; "
                f"_repo_out=$({preview_cmd}); "
                "if [ -n \"$_repo_out\" ]; then echo \"$_repo_out\"; "
                "else echo '(No repo updates found.)'; fi; "
            )
        self._run_terminal(
            repo_section +
            f"{aur_section}"
            f"{flatpak_section}"
            f"{snap_section}"
            "echo; echo 'Done.'",
            tr("Check for Updates"))

    def _on_manage_repos(self, *_):
        if distro.is_arch():
            show_repo_manager(self, self._run_terminal)
        else:
            show_repo_manager_native(self, self._run_terminal)

    def _on_show_apt_repair(self, *_):
        show_apt_repair_dialog(self, self._run_terminal)

    def _on_show_dnf_repair(self, *_):
        show_dnf_repair_dialog(self, self._run_terminal)

    def _on_show_zypper_repair(self, *_):
        show_zypper_repair_dialog(self, self._run_terminal)

    def _on_show_pacman_repair(self, *_):
        show_pacman_repair_dialog(self, self._run_terminal, self._get_aur_helper())

    def _on_show_cert_checker(self, *_):
        show_cert_checker_dialog(self, self._run_terminal)

    def _on_show_broken_symlinks(self, *_):
        show_broken_symlinks_dialog(self, self._run_terminal)

    def _on_show_services_security(self, *_):
        show_services_security_dialog(self, self._run_terminal)

    def _on_show_config_backup(self, *_):
        show_config_backup_dialog(self, self._run_terminal)

    def _on_rate_mirrors(self, *_):
        show_mirror_rater(self, self._run_terminal)

    def _on_show_orphans(self, *_):
        show_orphan_finder(self, self._run_terminal)

    def _on_show_file_search(self, *_):
        show_file_search_dialog(self, self._run_terminal)

    def _on_show_sysinfo(self, *_):
        show_sysinfo_dialog(self)

    def _on_show_history(self, *_):
        show_history_dialog(self)

    def _on_show_pacdiff(self, *_):
        show_pacdiff_dialog(self, self._run_terminal)

    def _on_show_tool_updates(self, *_):
        show_tool_updates_dialog(self, self._run_terminal)

    def _on_show_ignored(self, *_):
        show_ignored_packages_dialog(self, self._run_terminal)

    def _need_pkg(self, from_panel=False):
        """The package a Packages-menu action (Hold, PKGBUILD, Downgrade,
        Mark as …) should act on, or None after showing a toast.

        "Selected" in this app means two different things: a clicked row
        (opens the detail view and sets _selected_pkg) and a ticked
        checkbox (which deliberately does NOT open the detail view). The
        menu actions only ever looked at the first, so a package selected
        via its checkbox was reported as "select a package first". The
        ticked checkbox now takes precedence — the same rule the bottom
        action bar already follows — then the clicked row, then the
        highlighted row."""
        if from_panel:
            # The detail panel's own buttons always act on the package the
            # panel is showing, whatever is ticked elsewhere.
            if self._selected_pkg is None:
                self._toast(tr("Select a package first"))
            return self._selected_pkg
        sel = self.pkg_sel_state.selected
        if len(sel) > 1:
            self._toast(tr("Select only one package for this action"))
            return None
        if len(sel) == 1:
            key = next(iter(sel))
            for p in self._all_packages:
                repo = p.get("repo", "local")
                pk = (f"{repo}:{p.get('source_id') or p['name']}"
                      if repo in ("flatpak", "snap") else p["name"])
                if pk == key:
                    # Reuse the item already in the list when there is one,
                    # so its state (e.g. status) is the live one.
                    for item in self._iter_known_packages():
                        if selection_key(item) == key:
                            return item
                    return self._make_item(p)
        pkg = self._selected_pkg
        if pkg is None:
            pkg = self.pkg_selection.get_selected_item()
        if pkg is None:
            self._toast(tr("Select a package first"))
        return pkg

    def _on_view_pkgbuild(self, *_):
        pkg = self._need_pkg()
        if not pkg:
            return
        if not pkg.pkg_foreign:
            self._toast(tr("PKGBUILD is only available for AUR packages"))
            return
        show_pkgbuild_dialog(self, pkg.pkg_name, self._on_install)

    def _on_toggle_hold(self, *_, from_panel=False):
        # Several packages ticked: this menu entry is "Hold / Unhold
        # Selected", so hand over to the same batch path as the action bar.
        if not from_panel and len(self.pkg_sel_state.selected) > 1:
            self._on_batch_hold()
            return
        pkg = self._need_pkg(from_panel)
        if not pkg:
            return
        if pkg.pkg_repo in ("flatpak", "snap"):
            self._toast(tr("Hold isn't available for Flatpak/Snap packages"))
            return
        currently = pkg.pkg_name in get_ignored_packages()

        def _do_toggle():
            cmd = build_hold_cmd(pkg.pkg_name, not currently)
            if cmd is None:
                self._toast(tr("Could not update hold status for this package"))
                return
            verb = tr("Unhold") if currently else tr("Hold")
            self._run_terminal(cmd, f"{verb} {pkg.pkg_name}")

        show_hold_dialog(self, pkg.pkg_name, currently, _do_toggle,
                         on_show_ignored=self._on_show_ignored)

    def _on_preferences(self, *_):
        show_preferences(self, self._on_settings_changed, app_dir=APP_DIR,
                          run_terminal_fn=self._run_terminal_reset_aur_helper)

    def _run_terminal_reset_aur_helper(self, cmd, title, parent=None, on_success=None):
        # After installing an AUR helper (e.g. paru) from Preferences, drop
        # backend's cached lookup — now the only one, see _get_aur_helper()
        # — so the very next AUR action picks it up instead of still
        # reporting "no helper" for the rest of this session.
        def _after():
            save_settings({})   # side effect: resets backend's _aur_helper_cache
            if on_success:
                on_success()
        self._run_terminal(cmd, title, on_success=_after, parent=parent)

    def _on_settings_changed(self):
        new_lang = get_language()
        if new_lang != self._current_lang:
            self._current_lang = new_lang
        # Any setting (AUR helper, include-AUR, Flatpak/Snap toggles,
        # language, ...) can affect what shows up in the package list
        # and/or the update set — and, since the Flatpak toggle, can also
        # add/remove sidebar rows ("New Flatpak Packages", the flatpak
        # repo row) that _build_sidebar() only otherwise evaluates once
        # at construction time. A full chrome rebuild covers both cases
        # uniformly instead of tracking exactly which setting changed.
        self._rebuild_ui_preserving_state()

    def _rebuild_ui_preserving_state(self):
        """Rebuild the whole window so already-built chrome (sidebar, menu,
        headerbar, tooltips, empty-state pages, ...) picks up whatever
        changed — a new language (tr() is only re-evaluated when widgets
        are (re)built), or a sidebar row that a settings toggle just
        added or removed (e.g. Flatpak's "New Flatpak Packages" row and
        its Repositories entry, which _build_sidebar() otherwise only
        evaluates once at construction time). Dialogs and the package-
        row/detail content already handle this on their own next open/
        refresh, since they call tr() fresh every time they're built —
        it's specifically the long-lived widgets built once in
        _build_ui() that otherwise wouldn't update without restarting
        the app.

        Best-effort: restores which sidebar view (all/installed/updates/
        repo/...) was active, and the search text if any was entered.
        The exact selected package and open detail view are not restored
        (the list reloads asynchronously and re-matching a selection into
        that isn't worth the added complexity) — a minor, deliberate
        tradeoff for not needing a full restart.
        """
        filt  = self._current_filter
        query = self._search_query

        self._build_ui()
        self._load_packages()

        row = self._nav_rows.get(filt)
        if row is not None:
            self.new_listbox.unselect_all()
            self.repo_listbox.unselect_all()
            self.nav_listbox.select_row(row)
        else:
            row = self._new_nav_rows.get(filt)
            if row is not None:
                self.nav_listbox.unselect_all()
                self.repo_listbox.unselect_all()
                self.new_listbox.select_row(row)
            else:
                row = self._repo_nav_rows.get(filt)
                if row is not None:
                    self.nav_listbox.unselect_all()
                    self.new_listbox.unselect_all()
                    self.repo_listbox.select_row(row)
                else:
                    # The filter that was active no longer has a matching row
                    # (e.g. "new:flatpak" after Flatpak got turned back off)
                    # — fall back to the default view instead of silently
                    # keeping a now-orphaned filter active.
                    filt = "not_installed"
                    self.new_listbox.select_row(self._new_nav_rows[filt])
        self._current_filter = filt
        self._update_action_bar_mode()
        if query:
            self.search_entry.set_text(query)  # fires _on_search_changed
        # No explicit _apply_filter() call here: _load_packages() (just
        # above) finishes asynchronously and its own completion handler
        # (_on_packages_loaded) already calls _apply_filter() once loading
        # is done.

    def _on_show_tools(self, *_):
        show_tools_dialog(self)

    def _on_show_packages(self, *_):
        show_packages_dialog(self)

    def _on_show_shortcuts(self, *_):
        show_help_dialog(self)

    def _on_focus_search(self, *_):
        GLib.idle_add(self._grab_search_focus)

    def _on_downgrade(self, *_, from_panel=False):
        pkg = self._need_pkg(from_panel)
        if not pkg:
            return
        show_downgrade_dialog(self, pkg.pkg_name, self._run_terminal)

    def _on_mark_explicit(self, *_):
        pkg = self._need_pkg()
        if not pkg:
            return
        if pkg.pkg_repo in ("flatpak", "snap"):
            self._toast(tr("Not applicable to Flatpak/Snap packages"))
            return
        cmd = ("pkexec /usr/bin/pacman -D --asexplicit " + shlex.quote(pkg.pkg_name)
               if distro.is_arch() else pkgmanager.mark_explicit_cmd(pkg.pkg_name))
        if cmd is None:
            self._toast(tr("Not supported on this system"))
            return
        self._run_terminal(
            cmd, tr("Mark {name} as explicit").format(name=pkg.pkg_name),
            on_success=self._refresh_selected_pkg)

    def _on_mark_asdeps(self, *_):
        pkg = self._need_pkg()
        if not pkg:
            return
        if pkg.pkg_repo in ("flatpak", "snap"):
            self._toast(tr("Not applicable to Flatpak/Snap packages"))
            return

        def _do_mark():
            cmd = ("pkexec /usr/bin/pacman -D --asdeps " + shlex.quote(pkg.pkg_name)
                   if distro.is_arch() else pkgmanager.mark_asdeps_cmd(pkg.pkg_name))
            if cmd is None:
                self._toast(tr("Not supported on this system"))
                return
            self._run_terminal(
                cmd, tr("Mark {name} as dependency").format(name=pkg.pkg_name),
                on_success=self._refresh_selected_pkg)

        show_mark_asdeps_dialog(self, pkg.pkg_name, _do_mark)

    def _on_export_pkgs(self, *_):
        show_export_pkgs_intro(self, self._open_export_file_picker)

    def _open_export_file_picker(self):
        dialog = Gtk.FileDialog()
        dialog.set_title(tr("Export Package List"))
        dialog.set_initial_name(tr("pachul-packages.txt"))
        dialog.save(self, None, self._export_save_done)

    def _export_save_done(self, dialog, result):
        try:
            gfile = dialog.save_finish(result)
        except GLib.Error:
            return   # user cancelled
        path = gfile.get_path()
        pkgs = get_explicit_packages()
        try:
            with open(path, "w") as f:
                f.write("\n".join(pkgs) + "\n")
            self._toast(tr("Exported {n} packages").format(n=len(pkgs)))
        except OSError as e:
            self._toast(tr("Export failed: {err}").format(err=e))

    # ── Install a local package file (.tar.gz etc.) ─────────────────────────

    def _on_install_local(self, *_):
        dialog = Gtk.FileDialog()
        dialog.set_title(tr("Install Local Package"))

        pkg_filter = Gtk.FileFilter()
        pkg_filter.set_name(tr("Package files (.tar.gz, .pkg.tar.*, .deb, .rpm, .flatpak)"))
        for pattern in localpkg.FILE_PATTERNS:
            pkg_filter.add_pattern(pattern)
        all_filter = Gtk.FileFilter()
        all_filter.set_name(tr("All files"))
        all_filter.add_pattern("*")

        filters = Gio.ListStore.new(Gtk.FileFilter)
        filters.append(pkg_filter)
        filters.append(all_filter)
        dialog.set_filters(filters)
        dialog.set_default_filter(pkg_filter)
        dialog.open(self, None, self._install_local_chosen)

    def _install_local_chosen(self, dialog, result):
        try:
            gfile = dialog.open_finish(result)
        except GLib.Error:
            return   # user cancelled
        path = gfile.get_path()
        if not path:
            self._toast(tr("Could not read file: {err}").format(err=gfile.get_uri()))
            return
        self._toast(tr("Checking package file…"))

        def _worker():
            info = localpkg.analyze(path)
            GLib.idle_add(show_install_local_dialog, self, info, self._run_terminal)

        threading.Thread(target=_worker, daemon=True).start()

    def _on_import_pkgs(self, *_):
        helper = self._get_aur_helper()
        show_import_pkgs_intro(self, helper, self._open_import_file_picker)

    def _open_import_file_picker(self):
        dialog = Gtk.FileDialog()
        dialog.set_title(tr("Import Package List"))
        dialog.open(self, None, self._import_open_done)

    def _import_open_done(self, dialog, result):
        try:
            gfile = dialog.open_finish(result)
        except GLib.Error:
            return   # user cancelled
        try:
            with open(gfile.get_path()) as f:
                names = [ln.strip() for ln in f if ln.strip() and not ln.startswith("#")]
        except OSError as e:
            self._toast(tr("Could not read file: {err}").format(err=e))
            return
        if not names:
            self._toast(tr("No packages found in file"))
            return
        helper = self._get_aur_helper()
        show_import_pkgs_dialog(self, names, helper, self._run_terminal)

    # ── Multi-select / batch actions ─────────────────────────────────────────

    def _rebind_all_rows(self):
        """Detach/reattach the package ListView's model to force every
        visible row to rebind (e.g. after Select All / Deselect All changes
        many rows' checkboxes at once — a single row's own checkbox click
        updates itself directly and doesn't need this), preserving scroll
        position."""
        lv, scroll = self.pkg_listview, self.pkg_scroll
        model = lv.get_model()
        if model is None:
            return
        vadj = scroll.get_vadjustment()
        saved_pos = vadj.get_value() if vadj is not None else None
        lv.set_model(None)
        lv.set_model(model)
        if saved_pos:
            def _restore():
                vadj = scroll.get_vadjustment()
                if vadj is not None:
                    vadj.set_value(saved_pos)
                return False
            # Restore after GTK has finished laying out the reattached
            # model — doing it in the same frame gets overwritten.
            GLib.idle_add(_restore)

    def _iter_known_packages(self):
        """Yield every PackageItem currently loaded in the package list."""
        for i in range(self.pkg_store.get_n_items()):
            item = self.pkg_store.get_item(i)
            if item is not None:
                yield item

    def _update_batch_action_bar(self):
        """Recompute the action bar + detail panel for the current checkbox
        selection.

        Serves as the `on_selection_change` callback fired every time a
        checkbox is toggled (by a single row, or in bulk by Select/Deselect
        All) — there's no separate "selection mode" any more, so this also
        handles falling back to the normal single-package view the moment
        the selection becomes empty again.
        """
        state = self.pkg_sel_state
        n = len(state.selected)

        if n == 0:
            self.pkg_count_label.set_label(getattr(self, "_list_count_label_text", ""))
            # Reset the batch labels ("Remove (2740)" etc.) first. The
            # single-package path below (_on_pkg_activated) only restores
            # the Install label and the sensitivity of Remove, never the
            # Remove/Ignore *labels* — so after Deselect All the stale
            # "Remove (N)" text stayed on an active button.
            self._set_btn_label(self.btn_install, tr("Install"))
            self._set_btn_label(self.btn_remove, tr("Uninstall"))
            self._set_btn_label(self.btn_hold, tr("Ignore Updates"))
            if self._selected_pkg is not None:
                self._on_pkg_activated(self._selected_pkg)
            else:
                self._set_btn_label(self.btn_install, tr("Install"))
                self._set_btn_label(self.btn_remove, tr("Uninstall"))
                self._set_btn_label(self.btn_hold, tr("Ignore Updates"))
                self.btn_install.set_sensitive(False)
                self.btn_remove.set_sensitive(False)
                self.btn_hold.set_sensitive(False)
                self.detail_panel.stack.set_visible_child_name("empty")
            self._update_action_bar_mode()
            return

        seen = set()
        to_install, to_remove, to_hold = [], [], []
        selected_names = []
        for item in self._iter_known_packages():
            key = selection_key(item)
            if key in state.selected and key not in seen:
                seen.add(key)
                selected_names.append(item.pkg_name)
                # An "update" package is both installed (can be removed) and
                # upgradable (can be installed/updated) — it used to only
                # land in to_remove, which meant selecting update-available
                # packages showed no way to actually install/update them,
                # only "Remove". Mirrors the single-package logic in
                # _on_pkg_activated: can_install = status != "installed",
                # installed = status in ("installed", "update").
                if item.pkg_status != "installed":
                    to_install.append(item)
                if item.pkg_status in ("installed", "update"):
                    to_remove.append(item)
                    # Hold/ignore (IgnorePkg) only applies to pacman/AUR —
                    # Flatpak/Snap have their own update mechanisms.
                    if item.pkg_repo not in ("flatpak", "snap"):
                        to_hold.append(item)
        self._batch_install_items = to_install
        self._batch_remove_items = to_remove
        self._batch_hold_items = to_hold
        count_text = tr("{n} selected").format(n=n)
        install_label = tr("Install ({n})").format(n=len(to_install))
        remove_label = tr("Remove ({n})").format(n=len(to_remove))
        hold_label = tr("Ignore ({n})").format(n=len(to_hold))

        self.pkg_count_label.set_label(count_text)
        self._set_btn_label(self.btn_install, install_label)
        self._set_btn_label(self.btn_remove, remove_label)
        self._set_btn_label(self.btn_hold, hold_label)
        self.btn_install.set_sensitive(len(to_install) > 0)
        self.btn_remove.set_sensitive(len(to_remove) > 0)
        self.btn_hold.set_sensitive(len(to_hold) > 0)

        # Show selected packages in the detail panel
        self.detail_panel.show_batch(selected_names)
        self._update_action_bar_mode()

    def _pkg_is_foreign(self, name):
        for item in self._iter_known_packages():
            if item.pkg_name == name:
                return item.pkg_foreign
        return False

    def _exit_selection_mode(self):
        """Clear the current checkbox selection (e.g. after a batch
        install/remove completes) and fall back to the normal view."""
        if self.pkg_sel_state.selected:
            self.pkg_sel_state.selected.clear()
            self._rebind_all_rows()
        self._update_batch_action_bar()

    def _on_select_all(self, *_):
        """Select all packages currently visible in the package list."""
        all_names = {selection_key(item) for item in self._iter_known_packages()}
        if not all_names:
            return
        state = self.pkg_sel_state
        state.selected.clear()
        state.selected.update(all_names)
        self._update_batch_action_bar()
        # Force refresh of visible rows to update checkboxes — a bulk
        # change like this doesn't go through any single row's own click
        # handler, so nothing else would repaint them.
        self._rebind_all_rows()

    def _on_deselect_all(self, *_):
        """Deselect all packages."""
        self.pkg_sel_state.selected.clear()
        self._update_batch_action_bar()
        self._rebind_all_rows()

    def _flatpak_uninstall_cmd(self, app_id):
        q = shlex.quote(app_id)
        return (f"{{ flatpak uninstall -y {q} 2>/dev/null "
                f"|| pkexec /usr/bin/flatpak uninstall -y --system {q}; }}")

    def _flatpak_batch_uninstall_cmd(self, app_ids):
        """Same per-user-then-system-wide fallback as
        _flatpak_uninstall_cmd, but for several app ids removed together:
        every per-user attempt runs first (no privileges needed, and most
        Flatpaks on Arch/Manjaro are --user anyway — see the privilege
        note in backend.py), and only the ids that actually turn out to be
        system-wide installs get bundled into a SINGLE pkexec call at the
        end. Chaining `_flatpak_uninstall_cmd()` per app instead would
        mean one separate Polkit authentication for every system-wide
        Flatpak in the batch."""
        quoted = [shlex.quote(a) for a in app_ids]
        per_user = "; ".join(
            f'flatpak uninstall -y {q} 2>/dev/null || FAILED="$FAILED {q}"'
            for q in quoted)
        return (
            'FAILED=""; ' + per_user + '; '
            'if [ -n "$FAILED" ]; then pkexec /usr/bin/flatpak uninstall -y --system $FAILED; fi'
        )

    def _install_cmd_for(self, pkg):
        """Build the right install command for a single package, based on
        which source it came from."""
        if pkg.pkg_repo == "flatpak":
            app_id = pkg.pkg_source_id or pkg.pkg_name
            return f"flatpak install -y {shlex.quote(app_id)}"
        if pkg.pkg_repo == "snap":
            name = pkg.pkg_source_id or pkg.pkg_name
            return f"pkexec /usr/bin/snap install {shlex.quote(name)}"
        name = shlex.quote(pkg.pkg_name)
        # Only go through the AUR helper for packages that aren't known to
        # any configured repo at all (pkg_foreign) — e.g. a package also
        # mirrored as a binary in a repo like chaotic-aur installs via
        # plain pacman, even if a *newer* version might exist on the true
        # AUR; only genuinely AUR-only packages need the helper's build
        # step. (Trade-off: for a package straddling both — in a repo AND
        # ahead on the true AUR — this means the repo's own version is
        # what gets installed, not the newer AUR one; that ambiguity is
        # exactly what needed the helper, but --noconfirm made the helper
        # resolve it unreliably, so plain pacman for repo packages is the
        # safer default here.)
        if pkg.pkg_foreign:
            helper = self._get_aur_helper()
            if helper:
                # No --noconfirm here: yay/paru's repo-vs-AUR disambiguation
                # prompt (shown for a package known both to a repo and the
                # true AUR) doesn't resolve reliably under --noconfirm —
                # confirmed by testing both helpers. Pachul's terminal
                # dialog is already interactive via its generic PTY input
                # row, so the person answers the [Y/n] / numbered-choice
                # prompt directly there instead. (Unlike pacman itself, yay/
                # paru still call `sudo` internally for their own root
                # steps — that's the helper's own choice, outside Pachul's
                # pkexec migration — so that row also still doubles as
                # where its password prompt, if any, would be answered.)
                return aur_helper_install_cmd(helper, name, noconfirm=False)
        if not distro.is_arch():
            # Same reasoning as the pacman -Sy case below: refresh repo
            # metadata first so a pending update isn't missed just because
            # the locally cached repo data hasn't caught up yet. Combined
            # into ONE pkexec call (see pkgmanager.combine_pkexec) — two
            # separate `pkexec` calls chained with && could silently stall
            # on a second, unannounced Polkit dialog instead of actually
            # installing/updating the package.
            return pkgmanager.install_cmd_synced([pkg.pkg_name])
        # -Sy (not plain -S): checkupdates always syncs its own fresh copy
        # of the repo databases, so it can correctly flag a pending update
        # (e.g. from a repo like chaotic-aur) that the *local* sync db
        # hasn't caught up with yet — a plain "pacman -S" only consults
        # that local db and would just report "already up to date" without
        # ever seeing the new version, leaving the package stuck showing
        # as an update forever. Refreshing first (-y) here is standard
        # practice for updating a single package outside a full -Syu.
        return f"pkexec /usr/bin/pacman -Sy --noconfirm {name}"

    def _remove_cmd_for(self, pkg):
        """Build the right remove command for a single package, based on
        which source it came from."""
        if pkg.pkg_repo == "flatpak":
            app_id = pkg.pkg_source_id or pkg.pkg_name
            return self._flatpak_uninstall_cmd(app_id)
        if pkg.pkg_repo == "snap":
            name = pkg.pkg_source_id or pkg.pkg_name
            return f"pkexec /usr/bin/snap remove {shlex.quote(name)}"
        if not distro.is_arch():
            return pkgmanager.remove_cmd([pkg.pkg_name])
        return f"pkexec /usr/bin/pacman -R --noconfirm {shlex.quote(pkg.pkg_name)}"

    def _on_batch_install(self):
        items = list(getattr(self, "_batch_install_items", []))
        if not items:
            return
        pac_items = [i for i in items if i.pkg_repo not in ("flatpak", "snap")]
        fp_items  = [i for i in items if i.pkg_repo == "flatpak"]
        sn_items  = [i for i in items if i.pkg_repo == "snap"]

        helper_cmd = None
        # Steps that need root and are genuinely ours to combine into one
        # pkexec call — kept separate from helper_cmd (the AUR helper's
        # own internal `sudo`, a different mechanism we don't control and
        # can't fold in) and from the flatpak step (unprivileged --user
        # installs, which folding into our own root shell would wrongly
        # run as root instead).
        pkexec_steps = []
        if pac_items:
            helper = self._get_aur_helper()
            names = [i.pkg_name for i in pac_items]
            # Same split as _install_cmd_for: only genuinely AUR-only
            # packages go through the helper — anything known to a
            # configured repo (chaotic-aur included) installs via plain
            # pacman, even if a newer version might exist on the true AUR.
            foreign_names = [n for n in names if self._pkg_is_foreign(n)]
            repo_names = [n for n in names if n not in foreign_names]
            if foreign_names:
                if helper:
                    quoted = " ".join(shlex.quote(n) for n in foreign_names)
                    # No --noconfirm: see _install_cmd_for.
                    helper_cmd = aur_helper_install_cmd(helper, quoted, noconfirm=False)
                else:
                    self._toast(tr("No AUR helper found — skipped {n} AUR package(s).")
                               .format(n=len(foreign_names)))
            if repo_names:
                if distro.is_arch():
                    quoted = " ".join(shlex.quote(n) for n in repo_names)
                    # -Sy for the same reason as _install_cmd_for: a plain -S
                    # only consults the last-synced local db and can miss a
                    # pending update that checkupdates (always fresh) already
                    # sees, leaving the package stuck reporting as an update.
                    pkexec_steps.append(f"pkexec /usr/bin/pacman -Sy --noconfirm {quoted}")
                else:
                    pkexec_steps.append(pkgmanager.install_cmd_synced(repo_names))
        if sn_items:
            names = " ".join(shlex.quote(i.pkg_source_id or i.pkg_name) for i in sn_items)
            pkexec_steps.append(f"pkexec /usr/bin/snap install {names}")

        # Merge every pkexec step above into ONE Polkit authentication
        # (see pkgmanager.combine_pkexec) — then place the helper's own,
        # separately-authenticated step and the unprivileged flatpak step
        # around it. Order between these three doesn't matter functionally
        # (repo/AUR packages, Snap, and Flatpak are independent
        # ecosystems); only avoiding one extra prompt per step does.
        merged = pkgmanager.combine_pkexec(*pkexec_steps) if pkexec_steps else None
        cmds = [c for c in (helper_cmd, merged) if c]
        if fp_items:
            ids = " ".join(shlex.quote(i.pkg_source_id or i.pkg_name) for i in fp_items)
            cmds.append(f"flatpak update -y {ids}")

        if not cmds:
            return
        cmd = " && ".join(cmds)
        match_keys = {i.pkg_source_id or i.pkg_name for i in items}

        def _after():
            self._exit_selection_mode()
            self._prune_updates(match_keys)

        self._run_terminal(cmd, tr("Install {n} packages").format(n=len(items)),
                           on_success=_after)

    def _on_batch_hold(self):
        items = list(getattr(self, "_batch_hold_items", []))
        if not items:
            return
        names = [i.pkg_name for i in items]
        already_held = get_ignored_packages()
        to_add = [n for n in names if n not in already_held]
        if not to_add:
            self._toast(tr("All selected packages are already ignored"))
            return

        def do_hold():
            cmd = build_hold_cmd_bulk(to_add, True)
            if not cmd:
                self._toast(tr("Holding packages isn't supported on this system"))
                return
            self._run_terminal(
                cmd,
                tr("Ignore {n} packages").format(n=len(to_add)),
                on_success=self._exit_selection_mode)

        d = Adw.AlertDialog()
        d.set_heading(tr("Ignore {n} packages?").format(n=len(to_add)))
        d.set_body(tr(
            "Adds {n} package(s) to IgnorePkg in /etc/pacman.conf. They'll be "
            "skipped by system upgrades until you unignore them individually."
        ).format(n=len(to_add)))
        d.add_response("cancel", tr("Cancel"))
        d.add_response("ignore", tr("Ignore Updates"))
        d.set_response_appearance("ignore", Adw.ResponseAppearance.SUGGESTED)
        d.set_default_response("cancel")
        d.set_close_response("cancel")
        d.connect("response", lambda _d, r: do_hold() if r == "ignore" else None)
        d.present(self)

    def _on_batch_remove(self):
        items = list(getattr(self, "_batch_remove_items", []))
        if not items:
            return

        def do_remove():
            pac_items = [i for i in items if i.pkg_repo not in ("flatpak", "snap")]
            fp_items  = [i for i in items if i.pkg_repo == "flatpak"]
            sn_items  = [i for i in items if i.pkg_repo == "snap"]

            # Same reasoning as _on_batch_install: merge our own
            # pkexec-prefixed steps into one authentication instead of
            # chaining separate `pkexec` calls with &&.
            pkexec_steps = []
            if pac_items:
                names = [i.pkg_name for i in pac_items]
                if distro.is_arch():
                    quoted = " ".join(shlex.quote(n) for n in names)
                    pkexec_steps.append(f"pkexec /usr/bin/pacman -R --noconfirm {quoted}")
                else:
                    pkexec_steps.append(pkgmanager.remove_cmd(names))
            if sn_items:
                names = " ".join(shlex.quote(i.pkg_source_id or i.pkg_name) for i in sn_items)
                pkexec_steps.append(f"pkexec /usr/bin/snap remove {names}")
            merged = pkgmanager.combine_pkexec(*pkexec_steps) if pkexec_steps else None

            cmds = [c for c in [merged] if c]
            if fp_items:
                ids = [i.pkg_source_id or i.pkg_name for i in fp_items]
                cmds.append(self._flatpak_batch_uninstall_cmd(ids))
            if not cmds:
                return

            self._run_terminal(
                " && ".join(cmds),
                tr("Remove {n} packages").format(n=len(items)),
                on_success=self._exit_selection_mode)

        if not get_setting("confirm_remove"):
            do_remove()
            return

        d = Adw.AlertDialog()
        d.set_heading(tr("Remove {n} packages?").format(n=len(items)))
        d.set_body(tr("This will remove the {n} selected packages from your system.")
                   .format(n=len(items)))
        d.add_response("cancel", tr("Cancel")); d.add_response("remove", tr("Remove"))
        d.set_response_appearance("remove", Adw.ResponseAppearance.DESTRUCTIVE)
        d.set_default_response("cancel"); d.set_close_response("cancel")
        d.connect("response", lambda dlg, resp: resp == "remove" and do_remove())
        d.present(self)

    def _on_install(self, *_):
        if self.pkg_sel_state.selected:
            self._on_batch_install()
            return
        if not self._selected_pkg:
            return
        pkg = self._selected_pkg
        cmd = self._install_cmd_for(pkg)
        self._run_terminal(cmd, tr("Install {name}").format(name=pkg.pkg_name),
                           on_success=self._refresh_selected_pkg)

    def _on_remove(self, *_):
        if self.pkg_sel_state.selected:
            self._on_batch_remove()
            return
        if not self._selected_pkg:
            return
        pkg = self._selected_pkg

        def do_remove():
            self._run_terminal(
                self._remove_cmd_for(pkg),
                tr("Remove {name}").format(name=pkg.pkg_name),
                on_success=self._refresh_selected_pkg)

        if not get_setting("confirm_remove"):
            do_remove()
            return

        d = Adw.AlertDialog()
        d.set_heading(tr("Remove {name}?").format(name=pkg.pkg_name))
        d.set_body(tr("This will remove {name} ({version}) from your system.").format(
            name=pkg.pkg_name, version=pkg.pkg_version))
        d.add_response("cancel", tr("Cancel")); d.add_response("remove", tr("Remove"))
        d.set_response_appearance("remove", Adw.ResponseAppearance.DESTRUCTIVE)
        d.set_default_response("cancel"); d.set_close_response("cancel")
        d.connect("response", lambda dlg, resp: resp == "remove" and do_remove())
        d.present(self)

    def _on_reinstall(self, *_):
        if not self._selected_pkg:
            return
        pkg = self._selected_pkg
        cmd = self._install_cmd_for(pkg)
        self._run_terminal(cmd, tr("Reinstall {name}").format(name=pkg.pkg_name),
                           on_success=self._refresh_selected_pkg)

    def _prune_updates(self, match_keys):
        """Optimistically drop package(s) that were just installed/updated
        from the pending-updates list right away, instead of waiting for
        the slower authoritative background re-check (checkupdates/AUR
        -Qua can take up to a minute or more) — so the Updates list and
        its count reflect reality immediately rather than looking stale
        until that background check eventually completes. The background
        check still runs afterward and corrects anything this missed.
        `match_keys` are source_id (Flatpak/Snap) or plain package names,
        the same key check_updates() and _reapply_update_markers() use."""
        match_keys = set(match_keys)
        if not match_keys or not self._updates:
            return
        if not any(u["name"] in match_keys for u in self._updates):
            return
        self._updates = [u for u in self._updates if u["name"] not in match_keys]
        n = len(self._updates)
        self.stat_updates._num.set_label(str(n))
        self._nav_rows["updates"].set_count(n)
        for p in self._all_packages:
            if (p.get("source_id") or p["name"]) in match_keys:
                p["status"] = "installed"
                p.pop("new_version", None)
        self._apply_filter()
        if n == 0:
            # Every pending update just got cleared this way too (not only
            # via the "Update All" path in _do_upgrade()) — nudge any
            # running tray icon so it doesn't sit on a stale count; see
            # notify_tray_recheck()'s docstring.
            notify_tray_recheck()

    def _refresh_selected_pkg(self):
        if not self._selected_pkg:
            return
        pkg = self._selected_pkg
        if pkg.pkg_repo == "flatpak":
            app_id = pkg.pkg_source_id or pkg.pkg_name
            _, code = run_command(f"flatpak info {shlex.quote(app_id)} 2>/dev/null")
            pkg.pkg_status = "installed" if code == 0 else "available"
        elif pkg.pkg_repo == "snap":
            name = pkg.pkg_source_id or pkg.pkg_name
            _, code = run_command(f"snap list {shlex.quote(name)} 2>/dev/null")
            pkg.pkg_status = "installed" if code == 0 else "available"
        else:
            if distro.is_arch():
                out, code = run_command(f"pacman -Qi {shlex.quote(pkg.pkg_name)} 2>/dev/null")
                pkg.pkg_status = "installed" if (code == 0 and out) else "available"
            else:
                pkg.pkg_status = "installed" if pkgmanager.is_installed(pkg.pkg_name) else "available"
        installed = pkg.pkg_status == "installed"
        self.btn_install.set_sensitive(not installed)
        self.btn_remove.set_sensitive(installed)
        panel = self.detail_panel
        panel.btn_install.set_sensitive(not installed)
        self._set_btn_label(panel.btn_install, tr("Install"))
        panel.btn_remove.set_sensitive(installed)
        panel.btn_reinstall.set_sensitive(installed)
        panel.btn_downgrade.set_sensitive(installed)
        self._set_status_pill(panel, pkg.pkg_status, pkg.pkg_foreign)
        self._set_btn_label(self.btn_install, tr("Install"))
        # If the package was a pending update and is now installed, drop it
        # from the updates set so it leaves the Updates list right away.
        # Flatpak/Snap entries key off pkg_source_id (their app-id/package
        # name), which is what check_updates() actually reports for them —
        # pkg_name there is only the friendly display name.
        if installed:
            self._prune_updates({pkg.pkg_source_id or pkg.pkg_name})
        if installed:
            def worker():
                if pkg.pkg_repo in ("flatpak", "snap"):
                    # No pacman-style metadata exists for these — show what
                    # we actually have instead of running a meaningless
                    # pacman -Qi/-Fl query against a non-pacman name.
                    source_label = tr("Flatpak") if pkg.pkg_repo == "flatpak" \
                        else tr("Snap package")
                    info = (
                        f"Name           : {pkg.pkg_name}\n"
                        f"Version        : {pkg.pkg_version}\n"
                        f"Description    : {pkg.pkg_description or '—'}\n"
                        f"Install Reason : {source_label}\n"
                    )
                    if pkg.pkg_repo == "flatpak" and pkg.pkg_source_id:
                        info += f"URL            : https://flathub.org/apps/{pkg.pkg_source_id}\n"
                    files = []
                else:
                    info  = get_package_info(pkg.pkg_name)
                    files = get_package_files(pkg.pkg_name)
                if self._alive:
                    GLib.idle_add(self._populate_both_panels, info, files)
            threading.Thread(target=worker, daemon=True).start()

        if self.pkg_sel_state.selected:
            self._update_batch_action_bar()

    def _populate_both_panels(self, info, files):
        self._populate_detail(self.detail_panel, info, files)
        return False

    def _get_aur_helper(self):
        # Delegates to backend's own cached _find_aur_helper() instead of
        # keeping a second, independent lookup here — the two used to
        # disagree in one important way: this copy always auto-detected
        # and ignored the "AUR Helper" preference in Settings, so choosing
        # e.g. "paru" there while yay was also installed silently kept
        # using yay for anything routed through this method. One lookup,
        # one cache (reset together via save_settings(), see
        # _run_terminal_reset_aur_helper below), one preference honoured.
        return _find_aur_helper()
