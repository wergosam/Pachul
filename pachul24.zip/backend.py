"""
Pachul — backend.py
All pacman / system data functions: package queries, AUR search,
update checks, orphan detection, system info, and demo data.

Caching strategy
----------------
~/.cache/pachul/
  installed.json   — pacman -Q + -Qm output, invalidated when pacman -Q changes
  syncdb.json      — pacman -Sl output, TTL 6 h (changes only after pacman -Sy)
  packages.json    — merged full package list (served instantly on next launch)
"""

import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import threading
import time
import hashlib
import zipfile
import xml.etree.ElementTree as ET
import concurrent.futures
from pathlib import Path
from gi.repository import GLib


# ─── Cache paths ──────────────────────────────────────────────────────────────

CACHE_DIR      = Path.home() / ".cache" / "pachul"
PKG_CACHE      = CACHE_DIR / "packages.json"
SYNCDB_CACHE   = CACHE_DIR / "syncdb.json"
INSTALLED_CACHE= CACHE_DIR / "installed.json"
CACHE_VERSION  = 2   # bump when the cached package schema changes, to force a rebuild
SYNCDB_TTL     = 6 * 3600   # 6 hours

def _ensure_cache_dir():
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

def _read_json(path):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except Exception:
        return None

def _write_json(path, data):
    try:
        _ensure_cache_dir()
        tmp = path.with_suffix(".tmp")
        with open(tmp, "w") as f:
            json.dump(data, f, separators=(",", ":"))
        tmp.replace(path)
    except Exception:
        pass

# ─── User settings ────────────────────────────────────────────────────────────

CONFIG_DIR    = Path.home() / ".config" / "pachul"
SETTINGS_FILE = CONFIG_DIR / "settings.json"
_DEFAULT_SETTINGS = {
    "aur_helper":               "auto",   # auto | yay | paru | pikaur | none
    "include_aur_updates":      True,
    "confirm_remove":           True,
    "check_updates_on_start":   True,
    "show_news_before_upgrade": True,
    "snapshot_before_upgrade":  False,  # off by default — Timeshift rsync mode can be slow
    "notify_updates":           True,
    "bg_check_interval":        "daily",  # hourly | 6h | daily
    "language":                 "en",     # en | de
    "flatpak_enabled":          False,    # off by default — opt-in extra package source
    "snap_enabled":             False,    # off by default — opt-in extra package source
    "auto_update_tool_ids":     [],       # ids of "More Update Sources" tools to run with every normal upgrade
}
_settings_cache = None


def load_settings():
    global _settings_cache
    if _settings_cache is None:
        data = _read_json(SETTINGS_FILE) or {}
        _settings_cache = {**_DEFAULT_SETTINGS, **data}
    return _settings_cache


def get_setting(key):
    return load_settings().get(key, _DEFAULT_SETTINGS.get(key))


def save_settings(new_values):
    """Merge new_values into the stored settings and persist them."""
    global _settings_cache, _aur_helper_cache
    _settings_cache = {**_DEFAULT_SETTINGS, **load_settings(), **new_values}
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        tmp = SETTINGS_FILE.with_suffix(".tmp")
        with open(tmp, "w") as f:
            json.dump(_settings_cache, f, indent=2)
        tmp.replace(SETTINGS_FILE)
    except Exception:
        pass
    _aur_helper_cache = "__unset__"   # re-resolve helper in case the preference changed


def _file_age(path):
    """Return seconds since file was last modified, or infinity."""
    try:
        return time.time() - path.stat().st_mtime
    except Exception:
        return float("inf")


# ─── Helpers ──────────────────────────────────────────────────────────────────

# Force a stable C locale for all parsed queries, so pacman field names
# ("Depends On", "Required By", …) and values ("None") stay English regardless
# of the user's system language.
_C_ENV = {**os.environ, "LC_ALL": "C", "LANG": "C"}


def run_command(cmd, timeout=30):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                           timeout=timeout, env=_C_ENV)
        return r.stdout.strip(), r.returncode
    except subprocess.TimeoutExpired:
        return "", 1
    except Exception as e:
        return str(e), 1


def run_command_stream(cmd, on_line, on_done, timeout=180):
    """Run a non-interactive command, streaming output line by line."""
    def worker():
        try:
            proc = subprocess.Popen(
                cmd, shell=True,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                text=True, bufsize=1
            )
            for line in proc.stdout:
                GLib.idle_add(on_line, line.rstrip())
            proc.wait()
            GLib.idle_add(on_done, proc.returncode)
        except Exception as e:
            GLib.idle_add(on_line, f"Error: {e}")
            GLib.idle_add(on_done, 1)
    threading.Thread(target=worker, daemon=True).start()


def _is_demo():
    _, code = run_command("which pacman 2>/dev/null")
    return code != 0


_aur_helper_cache = "__unset__"

def _find_aur_helper():
    """Return the AUR helper to use, honouring the user's preference. Cached."""
    pref = get_setting("aur_helper")
    if pref == "none":
        return None
    global _aur_helper_cache
    if _aur_helper_cache == "__unset__":
        candidates = [pref] if (pref and pref != "auto") else ("yay", "paru", "pikaur", "trizen")
        _aur_helper_cache = None
        for h in candidates:
            _, c = run_command(f"which {h} 2>/dev/null")
            if c == 0:
                _aur_helper_cache = h
                break
    return _aur_helper_cache


def paru_installed():
    return shutil.which("paru") is not None


def get_paru_bootstrap_cmd():
    """Standard AUR-bootstrap sequence for paru itself. paru isn't in any
    official repo, so — like any other AUR package — it has to be built
    from its own AUR git repo the very first time (base-devel/git provide
    the build toolchain makepkg needs)."""
    build_dir = "/tmp/pachul-paru-build"
    return (
        f"rm -rf {build_dir} && "
        f"sudo -S pacman -S --needed --noconfirm base-devel git && "
        f"git clone https://aur.archlinux.org/paru.git {build_dir} && "
        f"cd {build_dir} && makepkg -si --noconfirm && "
        f"cd - && rm -rf {build_dir}"
    )


def get_aur_rpc_version(pkg_name):
    """Query the AUR RPC API for a package's current version there, if any.
    Best-effort only: returns None on any failure (offline, package not on
    the AUR, API hiccup, …) rather than raising — this is a supplementary
    check and must never disrupt anything else if it doesn't work."""
    import urllib.request
    import urllib.parse
    try:
        url = "https://aur.archlinux.org/rpc/v5/info?arg[]=" + urllib.parse.quote(pkg_name)
        with urllib.request.urlopen(url, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        results = data.get("results") or []
        if results:
            return results[0].get("Version")
    except Exception:
        pass
    return None


def check_aur_ahead_of_repo(pkg_name, installed_version):
    """For a package Pachul knows via a plain repo (not pkg_foreign) —
    e.g. a popular AUR package also mirrored as a prebuilt binary in a
    repo like chaotic-aur — check whether the *true* AUR has the same
    name at a strictly newer version than what's currently installed.
    This is exactly the "arch-update" situation: the repo mirror can lag
    behind the AUR's own rebuild cadence, and pacman/checkupdates alone
    have no way to notice since AUR isn't a sync-db source at all.
    Returns the AUR version string if it's ahead, else None (also None if
    the AUR RPC can't be reached — this never blocks or errors out)."""
    aur_version = get_aur_rpc_version(pkg_name)
    if not aur_version:
        return None
    out, code = run_command(
        f"vercmp {shlex.quote(aur_version)} {shlex.quote(installed_version)}", timeout=5)
    if code != 0:
        return None
    try:
        return aur_version if int(out.strip()) > 0 else None
    except (ValueError, TypeError):
        return None


# ─── Flatpak / Snap: optional extra package sources ───────────────────────────
# Both are entirely opt-in (see flatpak_enabled / snap_enabled settings) — if
# disabled, or if the binary simply isn't installed, every function below is
# a fast no-op that returns nothing, so people who don't use either just never
# pay for it (no extra subprocess calls at all).
#
# Privilege note: flatpak installs/removes are done with `--user` and need no
# sudo — Flatpak's per-user mode is the common, recommended setup on Arch/
# Manjaro (unlike distros that pre-configure a writable system-wide
# installation). Snap fundamentally requires snapd, which always needs root
# for install/remove/refresh, so those go through the same `sudo -S` terminal
# flow as pacman actions.

_flatpak_available_cache = None
_snap_available_cache = None


def flatpak_available():
    global _flatpak_available_cache
    if _flatpak_available_cache is None:
        _, code = run_command("which flatpak 2>/dev/null")
        _flatpak_available_cache = (code == 0)
    return _flatpak_available_cache


def snap_available():
    global _snap_available_cache
    if _snap_available_cache is None:
        _, code = run_command("which snap 2>/dev/null")
        _snap_available_cache = (code == 0)
    return _snap_available_cache


def get_flatpak_packages():
    """Installed Flatpak apps *and* runtimes, in the same dict shape
    get_packages() uses. Runtimes (e.g. "org.gnome.Platform") are included
    deliberately, not just apps — Pamac and other Flatpak-aware tools list
    them too, and they can have their own pending updates that would
    otherwise be invisible in the package list even though they're counted.
    `--all` is required for that: `flatpak list` hides locale and debug
    extensions (e.g. "org.gnome.Platform.Locale") by default, same as
    remote-ls — without it those never show up here even though
    get_flatpak_updates() (which also uses --all) counts them as pending.
    `source_id` carries the Flatpak ref ID (e.g. "org.gimp.GIMP"),
    which is what the actual install/uninstall commands need — pkg_name
    stays the friendly display name."""
    if not (get_setting("flatpak_enabled") and flatpak_available()):
        return []
    out, code = run_command(
        "flatpak list --all --columns=application,name,version 2>/dev/null", timeout=15)
    if not out or code != 0:
        return []
    items = []
    for line in out.splitlines():
        parts = line.split("\t")
        app_id = parts[0].strip() if parts else ""
        if not app_id:
            continue
        name = parts[1].strip() if len(parts) > 1 and parts[1].strip() else app_id
        version = parts[2].strip() if len(parts) > 2 else ""
        items.append({
            "name": name, "version": version, "repo": "flatpak",
            "status": "installed", "description": "", "foreign": False,
            "source_id": app_id,
        })
    return items


def get_snap_packages():
    """Installed Snap packages, in the same dict shape get_packages() uses."""
    if not (get_setting("snap_enabled") and snap_available()):
        return []
    out, code = run_command("snap list 2>/dev/null", timeout=15)
    if not out or code != 0:
        return []
    lines = out.splitlines()
    items = []
    for line in lines[1:]:  # first line is the "Name Version Rev ..." header
        parts = line.split()
        if len(parts) < 2:
            continue
        name, version = parts[0], parts[1]
        items.append({
            "name": name, "version": version, "repo": "snap",
            "status": "installed", "description": "", "foreign": False,
            "source_id": name,
        })
    return items


def search_flatpak(query):
    """Search flathub (or whatever remotes are configured) for `query`."""
    if not (get_setting("flatpak_enabled") and flatpak_available()):
        return []
    out, code = run_command(
        f"flatpak search {shlex.quote(query)} "
        "--columns=application,name,version,description 2>/dev/null", timeout=20)
    if not out or code != 0:
        return []
    items = []
    for line in out.splitlines():
        parts = line.split("\t")
        app_id = parts[0].strip() if parts else ""
        if not app_id or "no matches found" in line.lower():
            continue
        name = parts[1].strip() if len(parts) > 1 and parts[1].strip() else app_id
        version = parts[2].strip() if len(parts) > 2 else ""
        desc = parts[3].strip() if len(parts) > 3 else ""
        items.append({
            "name": name, "version": version, "repo": "flatpak",
            "description": desc, "status": "available", "foreign": False,
            "source_id": app_id,
        })
    return items


def search_snap(query):
    """Search the Snap Store for `query`."""
    if not (get_setting("snap_enabled") and snap_available()):
        return []
    out, code = run_command(f"snap find {shlex.quote(query)} 2>/dev/null", timeout=20)
    if not out or code != 0:
        return []
    lines = out.splitlines()
    items = []
    for line in lines[1:]:  # first line is the "Name Version Publisher ..." header
        parts = line.split(None, 4)
        if len(parts) < 2:
            continue
        name, version = parts[0], parts[1]
        desc = parts[4].strip() if len(parts) > 4 else ""
        items.append({
            "name": name, "version": version, "repo": "snap",
            "description": desc, "status": "available", "foreign": False,
            "source_id": name,
        })
    return items


# ─── Popular AUR packages to always show in the list ─────────────────────────
POPULAR_AUR_PACKAGES = [
    ("yay",                    "12.3.5-1",   "Yet another yogurt - AUR helper written in Go"),
    ("paru",                   "2.0.4-1",    "Feature packed AUR helper"),
    ("google-chrome",          "124.0-1",    "The popular web browser by Google"),
    ("visual-studio-code-bin", "1.89.0-1",   "Visual Studio Code editor from Microsoft"),
    ("discord",                "0.0.57-1",   "All-in-one voice and text chat for gamers"),
    ("spotify",                "1.2.25-1",   "A proprietary music streaming service"),
    ("1password",              "8.10.30-1",  "Password manager and secure digital wallet"),
    ("zoom",                   "6.0.2-1",    "Video conferencing, web conferencing, webinars"),
    ("slack-desktop",          "4.38.125-1", "Messaging app for teams"),
    ("telegram-desktop-bin",   "5.1.6-1",    "Official Telegram Desktop client"),
    ("obs-studio-browser",     "30.1.2-1",   "Free and open source streaming/recording software"),
    ("timeshift",              "24.01.1-1",  "System restore utility for Linux"),
    ("ventoy-bin",             "1.0.99-1",   "Tool to create bootable USB drives"),
    ("onlyoffice-bin",         "8.0.1-1",    "Free office suite compatible with MS Office"),
    ("bottles",                "51.14-1",    "Run Windows software on Linux using Wine"),
    ("protonup-qt",            "2.9.0-1",    "Install and manage Proton-GE and Luxtorpeda"),
    ("heroic-games-launcher",  "2.14.0-1",   "Open source Epic, GOG and Amazon Games launcher"),
    ("lutris",                 "0.5.17-1",   "Open gaming platform for Linux"),
    ("mangohud",               "0.7.1-1",    "Vulkan/OpenGL overlay for monitoring FPS and temps"),
    ("nerd-fonts-complete",    "3.2.1-1",    "Iconic font aggregator and collection"),
    ("ttf-ms-fonts",           "0.1-9",      "Core Microsoft fonts"),
    ("pamac-aur",              "11.6.0-1",   "A Package Manager with AUR support"),
    ("pikaur",                 "1.28-1",     "Lightweight AUR package manager"),
    ("sublime-text-4",         "4.0.4180-1", "Sophisticated text editor for code and prose"),
    ("jetbrains-toolbox",      "2.3.2-1",    "JetBrains IDE manager"),
    ("postman-bin",            "11.0.9-1",   "API development environment"),
    ("insomnia",               "9.2.0-1",    "Open-source API client"),
    ("dbeaver",                "24.0.5-1",   "Universal database tool and SQL client"),
    ("wine",                   "9.8-1",      "A compatibility layer for running Windows programs"),
    ("steam",                  "1.0.0.79-2", "Valve's digital software delivery system"),
]


# ─── Installed-package fingerprint ────────────────────────────────────────────

def _installed_fingerprint():
    """Fast fingerprint of installed packages using local DB mtime + count."""
    local_db = Path("/var/lib/pacman/local")
    out, code = run_command("pacman -Q 2>/dev/null")
    if code != 0:
        return None
    # Combine package count + local db mtime for a fast, reliable fingerprint
    try:
        mtime = str(int(local_db.stat().st_mtime))
    except Exception:
        mtime = "0"
    pkg_count = str(out.count("\n"))
    fingerprint = hashlib.md5(f"{mtime}:{pkg_count}".encode()).hexdigest()
    return fingerprint, out


# ─── Sync-DB cache (pacman -Sl) ───────────────────────────────────────────────

def _load_syncdb_cache():
    """Return cached pacman -Sl data if it's fresh enough."""
    if _file_age(SYNCDB_CACHE) < SYNCDB_TTL:
        data = _read_json(SYNCDB_CACHE)
        if data:
            return data
    return None

def _parse_db_file(db_path):
    """Parse one pacman .db tarball and return {pkgname: (repo, version, desc)}."""
    import tarfile
    repo = db_path.stem  # filename without .db = repo name
    result = {}
    try:
        with tarfile.open(db_path, "r:*") as tar:
            members = {m.name: m for m in tar.getmembers()}
            desc_members = [m for name, m in members.items() if name.endswith("/desc")]
            for member in desc_members:
                f = tar.extractfile(member)
                if not f:
                    continue
                content = f.read().decode("utf-8", errors="replace")
                name = version = desc = None
                lines = content.splitlines()
                i = 0
                while i < len(lines):
                    tag = lines[i]
                    if tag in ("%NAME%", "%VERSION%", "%DESC%") and i + 1 < len(lines):
                        val = lines[i + 1].strip()
                        if tag == "%NAME%":
                            name = val
                        elif tag == "%VERSION%":
                            version = val
                        elif tag == "%DESC%":
                            desc = val
                    i += 1
                if name:
                    result[name] = (repo, version or "", desc or "")
    except Exception:
        pass
    return result


def _build_syncdb(installed_set):
    """Build sync DB from local pacman .db files (fast, no subprocess needed)."""
    from concurrent.futures import ThreadPoolExecutor
    sync_dir = Path("/var/lib/pacman/sync")
    pkgs = {}

    if sync_dir.exists():
        db_files = list(sync_dir.glob("*.db"))
        with ThreadPoolExecutor(max_workers=min(4, len(db_files) or 1)) as ex:
            futures = [ex.submit(_parse_db_file, db) for db in db_files]
            for future in futures:
                for name, (repo, version, desc) in future.result().items():
                    pkgs[name] = {"repo": repo, "version": version, "description": desc}

    # Fallback: if no .db files found, use pacman -Sl (slower)
    if not pkgs:
        sl_out, sl_code = run_command("pacman -Sl 2>/dev/null", timeout=60)
        if sl_out and sl_code == 0:
            for line in sl_out.splitlines():
                parts = line.strip().split()
                if len(parts) >= 3:
                    repo, pkgname, version = parts[0], parts[1], parts[2]
                    pkgs[pkgname] = {"repo": repo, "version": version, "description": ""}

    _write_json(SYNCDB_CACHE, pkgs)
    return pkgs


# ─── Main package list ────────────────────────────────────────────────────────

def _merge_into_list(installed_pkgs, syncdb, aur_set):
    """Combine installed + syncdb + popular AUR into the final package list."""
    all_pkgs = dict(installed_pkgs)

    for pkgname, info in syncdb.items():
        desc = info.get("description", "")
        if pkgname in all_pkgs:
            if not all_pkgs[pkgname]["foreign"]:
                all_pkgs[pkgname]["repo"] = info["repo"]
            # Always fill description from syncdb if missing
            if not all_pkgs[pkgname].get("description"):
                all_pkgs[pkgname]["description"] = desc
        else:
            all_pkgs[pkgname] = {
                "name": pkgname,
                "version": info["version"],
                "repo": info["repo"],
                "status": "available",
                "description": desc,
                "foreign": False,
            }

    # Popular AUR packages are injected only for discoverability. Their real
    # version is unknown without querying the AUR, so leave it blank rather than
    # show the hardcoded (and quickly stale) value from POPULAR_AUR_PACKAGES.
    for name, _version, desc in POPULAR_AUR_PACKAGES:
        if name not in all_pkgs:
            all_pkgs[name] = {
                "name": name, "version": "", "repo": "aur",
                "status": "available", "description": desc, "foreign": True,
            }

    return list(all_pkgs.values())


def get_packages():
    """
    Return package list as fast as possible.

    Launch path:
      1. If packages.json cache exists AND installed fingerprint matches → return cache instantly.
      2. Otherwise build from scratch (pacman -Q + cached/fresh pacman -Sl) and save cache.
    """
    if _is_demo():
        demo = []
        for name, version, desc in POPULAR_AUR_PACKAGES:
            demo.append({"name": name, "version": version, "repo": "aur",
                          "status": "available", "description": desc, "foreign": True})
        return demo

    # ── Fast path: fingerprint check ─────────────────────────────────────────
    result = _installed_fingerprint()
    if result is None:
        return []
    fingerprint, raw_Q = result

    cached = _read_json(PKG_CACHE)
    if (cached and cached.get("version") == CACHE_VERSION
            and cached.get("fingerprint") == fingerprint):
        packages = cached["packages"]
    else:
        # ── Slow path: rebuild ────────────────────────────────────────────────
        # Step 1 — installed packages
        installed_pkgs = {}
        for line in raw_Q.splitlines():
            parts = line.strip().split(None, 1)
            if len(parts) == 2:
                installed_pkgs[parts[0]] = {
                    "name": parts[0], "version": parts[1],
                    "repo": "local", "status": "installed",
                    "description": "", "foreign": False,
                }

        # Step 2 — mark AUR/foreign
        foreign_out, _ = run_command("pacman -Qm 2>/dev/null")
        for line in (foreign_out or "").splitlines():
            parts = line.strip().split(None, 1)
            if parts and parts[0] in installed_pkgs:
                installed_pkgs[parts[0]]["foreign"] = True
                installed_pkgs[parts[0]]["repo"] = "aur"

        # Step 3 — sync DB (use cache if fresh, else rebuild)
        syncdb = _load_syncdb_cache()
        if syncdb is None:
            syncdb = _build_syncdb(set(installed_pkgs))

        # Step 4 — merge
        packages = _merge_into_list(installed_pkgs, syncdb, set())

        # Step 5 — save cache (pacman packages only — Flatpak/Snap are merged
        # in fresh below every time, so they're never stale in this cache)
        _write_json(PKG_CACHE, {"version": CACHE_VERSION, "fingerprint": fingerprint,
                                "packages": packages})

    # Flatpak/Snap are independent, opt-in sources — queried fresh each call
    # (cheap: usually a handful to a few dozen packages) rather than folded
    # into the pacman fingerprint cache above, and are no-ops entirely when
    # disabled or not installed.
    return packages + get_flatpak_packages() + get_snap_packages()


def invalidate_cache():
    """Call this after install/remove/upgrade so next load rebuilds."""
    try:
        PKG_CACHE.unlink(missing_ok=True)
    except Exception:
        pass


def invalidate_syncdb_cache():
    """Call this after pacman -Sy so the sync DB is re-fetched."""
    try:
        SYNCDB_CACHE.unlink(missing_ok=True)
    except Exception:
        pass


# ─── Package info / files ─────────────────────────────────────────────────────

def get_package_info(pkg_name):
    q = shlex.quote(pkg_name)
    out, code = run_command(f"pacman -Qi {q} 2>/dev/null")
    if out and code == 0:
        return out
    out2, code2 = run_command(f"pacman -Si --noconfirm {q} 2>/dev/null")
    if out2 and code2 == 0:
        return out2

    # Not installed and not in the sync DB — for AUR packages, ask a helper.
    helper = _find_aur_helper()
    if helper:
        out3, code3 = run_command(f"{helper} -Si {q} 2>/dev/null", timeout=30)
        if out3 and code3 == 0:
            return out3

    if _is_demo():
        return (f"Name           : {pkg_name}\nVersion        : 1.0.0-1\n"
                f"Description    : Demo package (not on Arch Linux)\n"
                f"Architecture   : x86_64\nURL            : https://example.com/{pkg_name}\n"
                f"Licenses       : GPL\nGroups         : None\nProvides       : None\n"
                f"Depends On     : glibc\nOptional Deps  : None\nConflicts With : None\n"
                f"Replaces       : None\nInstalled Size : 1.20 MiB\nPackager       : Arch Linux\n"
                f"Build Date     : Thu 01 Jan 2026\nInstall Date   : Thu 01 Jan 2026\n"
                f"Install Reason : Explicitly installed\nValidated By   : Signature\n")

    # Honest fallback on a real system: don't fabricate version/dates/deps.
    return (f"Name           : {pkg_name}\n"
            f"Description    : No detailed information available — this package "
            f"is not installed and was not found in the sync databases"
            f"{' or AUR' if helper else ''}.\n")


def get_package_files(pkg_name):
    out, code = run_command(f"pacman -Ql {shlex.quote(pkg_name)} 2>/dev/null")
    if out and code == 0:
        return out.splitlines()
    return [f"{pkg_name} /usr/bin/{pkg_name}", f"{pkg_name} /usr/share/man/man1/{pkg_name}.1"]


# ─── File → package search (pacman -F) ───────────────────────────────────────

def files_db_available():
    """Whether a synced pacman files database exists for `pacman -F` to use."""
    out, code = run_command("ls /var/lib/pacman/sync/*.files 2>/dev/null | head -1")
    return bool(out.strip()) and code == 0


def search_file_owner(query):
    """Which package(s) own file paths matching `query` (regex, via `pacman -Fx`).

    Returns [{"pkg": "repo/name", "version": "1.0-1", "files": [...]}].
    Requires the files DB to be synced first (`sudo pacman -Fy`) — callers
    should check `files_db_available()` and offer that sync if it's missing.
    """
    query = query.strip()
    if not query:
        return []
    out, code = run_command(f"pacman -Fx {shlex.quote(query)} 2>/dev/null", timeout=30)
    results = []
    if out and code == 0:
        current = None
        for line in out.splitlines():
            if line and not line[0].isspace():
                parts = line.split()
                if len(parts) >= 2:
                    current = {"pkg": parts[0], "version": parts[1], "files": []}
                    results.append(current)
            elif current is not None:
                current["files"].append(line.strip())
    if not results and _is_demo():
        needle = query.strip("/").lower()
        lib_name = needle if needle.startswith("lib") else (f"lib{needle}" if needle else "libssl.so.3")
        results = [
            {"pkg": "extra/openssl", "version": "3.3.1-1",
             "files": [f"usr/lib/{lib_name}"]},
            {"pkg": "core/systemd", "version": "256.4-1",
             "files": [f"usr/lib/systemd/{needle or 'systemd'}"]},
        ]
    return results


# ─── Updates / orphans / sysinfo ─────────────────────────────────────────────

def check_updates():
    """Repo updates (checkupdates) plus AUR updates from a helper, if
    present, plus Flatpak/Snap updates when those sources are enabled.
    The four checks are independent of each other, so they run in
    parallel threads rather than one after another — checkupdates and
    {helper} -Qua alone each allow up to a minute, so sequentially this
    could take several minutes in the worst case; in parallel the whole
    check takes about as long as the single slowest one."""
    def _repo_check():
        results = []
        out, code = run_command("checkupdates 2>/dev/null || pacman -Qu 2>/dev/null", timeout=60)
        if out and code == 0:
            for line in out.splitlines():
                parts = line.strip().split()
                if len(parts) >= 4:
                    results.append({"name": parts[0], "old": parts[1],
                                    "new": parts[3], "aur": False})
        return results

    def _aur_check():
        helper = _find_aur_helper()
        if not (helper and get_setting("include_aur_updates")):
            return []
        results = []
        aout, acode = run_command(f"{helper} -Qua 2>/dev/null", timeout=90)
        if aout and acode == 0:
            for line in aout.splitlines():
                parts = line.strip().split()
                if len(parts) >= 4:
                    results.append({"name": parts[0], "old": parts[1],
                                    "new": parts[3], "aur": True})
        return results

    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(fn) for fn in
                   (_repo_check, _aur_check, get_flatpak_updates, get_snap_updates)]
        groups = [f.result() for f in futures]

    # Merge preserving the original precedence (repo > AUR > Flatpak > Snap)
    # for de-duplication, same as when these ran sequentially one at a time.
    updates = []
    seen = set()
    for group in groups:
        for u in group:
            if u["name"] not in seen:
                updates.append(u)
                seen.add(u["name"])
    return updates


def get_flatpak_updates():
    """Pending Flatpak updates, in the same {name, old, new, aur} shape
    check_updates() uses for repo/AUR entries, so they merge into one list.
    `name` is set to the Flatpak app ID (not the friendly display name) —
    that's what `flatpak update` itself and the matching logic in the UI
    (which keys off each installed package's `source_id`) both expect.
    Empty list if Flatpak support isn't enabled/installed, or refreshing
    the local metadata fails (offline, etc.) — this is purely informational
    and should never block the rest of the update check."""
    if not (get_setting("flatpak_enabled") and flatpak_available()):
        return []
    # Refresh the local appstream/summary cache first — otherwise
    # `remote-ls --updates` can compare against a stale local copy and
    # under-report what's actually available.
    run_command("flatpak update --appstream 2>/dev/null", timeout=30)
    out, code = run_command(
        "flatpak remote-ls --updates --all --columns=application,version 2>/dev/null",
        timeout=20)
    if not out or code != 0:
        return []
    updates = []
    for line in out.splitlines():
        parts = line.split("\t")
        app_id = parts[0].strip() if parts else ""
        if not app_id:
            continue
        new_version = parts[1].strip() if len(parts) > 1 else ""
        updates.append({"name": app_id, "old": "", "new": new_version, "aur": False})
    return updates


def get_snap_updates():
    """Pending Snap updates, in the same {name, old, new, aur} shape
    check_updates() uses. `snap refresh --list` only queries snapd for
    what's pending — it does not install or change anything. Prints
    'All snaps up to date.' (no table) when nothing's pending, which the
    parsing below naturally yields zero rows for."""
    if not (get_setting("snap_enabled") and snap_available()):
        return []
    out, code = run_command("snap refresh --list 2>/dev/null", timeout=30)
    if not out or code != 0:
        return []
    lines = out.splitlines()
    if len(lines) < 2:   # just the "All snaps up to date." line, or empty
        return []
    updates = []
    for line in lines[1:]:   # first line is the "Name Version Rev ..." header
        parts = line.split()
        if len(parts) < 2:
            continue
        updates.append({"name": parts[0], "old": "", "new": parts[1], "aur": False})
    return updates


def get_orphans():
    out, _ = run_command("pacman -Qdt 2>/dev/null")
    orphans = []
    if out:
        for line in out.splitlines():
            parts = line.strip().split(None, 1)
            if len(parts) == 2:
                orphans.append({"name": parts[0], "version": parts[1]})
    if not orphans and _is_demo():
        orphans = [
            {"name": "lib32-libpng12", "version": "1.2.56-2"},
            {"name": "perl-encode-locale", "version": "1.05-7"},
            {"name": "python2", "version": "2.7.18-3"},
        ]
    return orphans


def _human_size(num_bytes):
    """Format a byte count base-1024, e.g. 1536 → '1.5 KiB'."""
    size = float(num_bytes)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if size < 1024:
            return f"{int(size)} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PiB"


def _dir_size(path):
    """Total size of all files under `path`, in bytes (resilient to errors)."""
    total = 0
    try:
        with os.scandir(path) as it:
            for entry in it:
                try:
                    if entry.is_file(follow_symlinks=False):
                        total += entry.stat(follow_symlinks=False).st_size
                    elif entry.is_dir(follow_symlinks=False):
                        total += _dir_size(entry.path)
                except OSError:
                    pass
    except OSError:
        pass
    return total


PKG_CACHE_DIR = "/var/cache/pacman/pkg"


def get_package_cache_size():
    """Human-readable current size of the pacman package cache."""
    return _human_size(_dir_size(PKG_CACHE_DIR)) if os.path.isdir(PKG_CACHE_DIR) else "N/A"


def _get_desktop_info():
    """Desktop environment name + version, where detectable. Best-effort:
    covers the common desktops shipped on Arch/Manjaro; falls back to just
    the XDG-reported name (no version) for anything else."""
    desktop = os.environ.get("XDG_CURRENT_DESKTOP") or os.environ.get("DESKTOP_SESSION") or ""
    desktop = desktop.split(":")[0].strip() if desktop else ""
    if not desktop:
        return "Unknown"

    dl = desktop.lower()
    version_cmd = None
    if "kde" in dl or "plasma" in dl:
        version_cmd = "plasmashell --version 2>/dev/null"
    elif "gnome" in dl:
        version_cmd = "gnome-shell --version 2>/dev/null"
    elif "xfce" in dl:
        version_cmd = "xfce4-session --version 2>/dev/null"
    elif "cinnamon" in dl:
        version_cmd = "cinnamon --version 2>/dev/null"
    elif "mate" in dl:
        version_cmd = "mate-session --version 2>/dev/null"
    elif "budgie" in dl:
        version_cmd = "budgie-desktop --version 2>/dev/null"
    elif "lxqt" in dl:
        version_cmd = "lxqt-session --version 2>/dev/null"

    version = ""
    if version_cmd:
        out, code = run_command(version_cmd)
        if out and code == 0:
            m = re.search(r"(\d+[\w.\-]*)", out)
            if m:
                version = m.group(1)

    return f"{desktop} {version}".strip() if version else desktop


def _get_cpu_info():
    """CPU model name (and thread count), read straight from /proc/cpuinfo —
    works the same on x86_64 and (with the Hardware/model fallback) on ARM.

    IMPORTANT: on x86, the bare "model" field (just a numeric model ID,
    e.g. "85") appears *before* the actual "model name" line in the file.
    A naive first-match-wins check over ("model name", "hardware", "model")
    would therefore latch onto that numeric ID and stop, since "model"
    matches before the real name is even reached. So: always scan for
    "model name" first; only fall back to "Hardware" (common on ARM boards)
    or the bare "model" field if no "model name" line exists at all.
    """
    model_name = ""
    hardware = ""
    bare_model = ""
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                low = line.lower()
                if low.startswith("model name") and not model_name:
                    model_name = line.split(":", 1)[1].strip()
                elif low.startswith("hardware") and not hardware:
                    hardware = line.split(":", 1)[1].strip()
                elif low.startswith("model") and not low.startswith("model name") and not bare_model:
                    bare_model = line.split(":", 1)[1].strip()
                if model_name:
                    break
    except Exception:
        pass
    model = model_name or hardware or bare_model
    if not model:
        return "Unknown"
    threads = os.cpu_count()
    return f"{model} ({threads} threads)" if threads else model


def _get_disk_type():
    """Storage type (NVMe SSD / SSD / HDD) for whatever the root filesystem
    actually lives on. Resolves through partitions, LUKS and LVM down to the
    underlying physical block device before checking rotational vs. NVMe."""
    try:
        out, code = run_command("findmnt -n -o SOURCE / 2>/dev/null")
        src = out.strip() if (out and code == 0) else ""
        if not src:
            return "Unknown"

        out2, code2 = run_command(f"lsblk -ndo pkname {shlex.quote(src)} 2>/dev/null")
        parent = out2.strip() if (out2 and code2 == 0) else ""
        if not parent:
            parent = os.path.basename(src)  # already a whole-disk device

        if parent.startswith("nvme"):
            return f"NVMe SSD ({parent})"

        rota_path = f"/sys/block/{parent}/queue/rotational"
        try:
            with open(rota_path) as f:
                rota = f.read().strip()
            kind = "HDD" if rota == "1" else "SSD"
        except Exception:
            kind = "Unknown"
        return f"{kind} ({parent})"
    except Exception:
        return "Unknown"


def _get_installed_aur_helpers():
    """Which AUR helper binaries are actually present on the system —
    independent of which one Pachul is currently configured to use, since
    that's a separate question from what's simply installed."""
    found = []
    for helper in ("yay", "paru", "pikaur", "trizen"):
        _, code = run_command(f"which {helper} 2>/dev/null")
        if code == 0:
            found.append(helper)
    return found


def get_system_info():
    """System overview, derived in-process where possible (no shell pipelines)."""
    info = {}
    uname = os.uname()
    info["Kernel"] = uname.release
    info["Architecture"] = uname.machine

    os_name = "Unknown"
    try:
        with open("/etc/os-release") as f:
            for line in f:
                if line.startswith("PRETTY_NAME="):
                    os_name = line.split("=", 1)[1].strip().strip('"')
                    break
    except Exception:
        pass
    info["OS"] = os_name
    info["Desktop"] = _get_desktop_info()

    out, code = run_command("pacman -V 2>/dev/null")
    m = re.search(r"Pacman v?([\w.\-]+)", out) if (out and code == 0) else None
    info["Pacman"] = m.group(1) if m else "Unknown"

    aur_helpers = _get_installed_aur_helpers()
    info["AUR Helper"] = ", ".join(aur_helpers) if aur_helpers else "None installed"

    info["Processor"] = _get_cpu_info()

    try:
        du = shutil.disk_usage("/")
        pct = round(du.used / du.total * 100) if du.total else 0
        info["Disk (/)"] = f"{_human_size(du.used)} / {_human_size(du.total)} ({pct}% used)"
    except Exception:
        info["Disk (/)"] = "N/A"
    info["Disk Type"] = _get_disk_type()

    try:
        meminfo = {}
        with open("/proc/meminfo") as f:
            for line in f:
                key, _, rest = line.partition(":")
                if key in ("MemTotal", "MemAvailable"):
                    meminfo[key] = int(rest.split()[0]) * 1024   # kB → bytes
        total = meminfo.get("MemTotal", 0)
        if total:
            used = total - meminfo.get("MemAvailable", 0)
            info["RAM"] = f"{_human_size(used)} / {_human_size(total)}"
        else:
            info["RAM"] = "N/A"
    except Exception:
        info["RAM"] = "N/A"

    # Installed count = subdirs of the local pacman DB (no subprocess needed)
    try:
        with os.scandir("/var/lib/pacman/local") as it:
            info["Installed Packages"] = str(sum(1 for e in it if e.is_dir()))
    except OSError:
        out, code = run_command("pacman -Q 2>/dev/null")
        info["Installed Packages"] = str(len(out.splitlines())) if (out and code == 0) else "N/A"

    out, code = run_command("pacman -Qm 2>/dev/null")
    foreign_count = len(out.splitlines()) if (out and code == 0) else 0
    info["Foreign (AUR) Packages"] = str(foreign_count)

    # Per-repository breakdown of installed packages. `pacman -Sl` lists
    # every package in every enabled sync repo and marks the ones that are
    # currently installed with "[installed" (pacman appends the installed
    # version too if it differs) — one pass gives an installed-count per
    # repo without needing a separate cross-reference query.
    repo_counts = {}
    out, code = run_command("pacman -Sl 2>/dev/null")
    if out and code == 0:
        for line in out.splitlines():
            parts = line.split(None, 2)
            if len(parts) < 3:
                continue
            repo, rest = parts[0], parts[2]
            if "[installed" in rest:
                repo_counts[repo] = repo_counts.get(repo, 0) + 1
    if foreign_count:
        repo_counts["aur / foreign"] = foreign_count
    info["Repo Counts"] = repo_counts

    cache_dir = "/var/cache/pacman/pkg"
    info["Package Cache Size"] = _human_size(_dir_size(cache_dir)) if os.path.isdir(cache_dir) else "N/A"

    return info


# ─── Pacman log / history ─────────────────────────────────────────────────────

PACMAN_LOG = Path("/var/log/pacman.log")
_LOG_RE = re.compile(
    r"^\[(.*?)\]\s+\[ALPM\]\s+"
    r"(installed|removed|upgraded|downgraded|reinstalled)\s+(\S+)\s+\((.*?)\)")


def get_pacman_history(limit=500):
    """Parse recent ALPM transactions from /var/log/pacman.log, newest first."""
    try:
        lines = PACMAN_LOG.read_text(errors="replace").splitlines()
    except Exception:
        return []
    entries = []
    for line in lines:
        m = _LOG_RE.match(line)
        if m:
            ts, action, name, ver = m.groups()
            entries.append({"time": ts, "action": action, "name": name, "version": ver})
    entries.reverse()
    return entries[:limit]


# ─── Arch news (pre-upgrade warning) ──────────────────────────────────────────

def _translate_text(text, target_lang, source_lang="en"):
    """Best-effort machine translation via Google's free, no-key translate
    endpoint (the same one tools like `trans`/`googletrans` use). Returns
    the original text unchanged on any failure (offline, endpoint
    unreachable, unexpected response, ...) — translation here is a nice-to-
    have, never something that should block showing the news at all.
    """
    import urllib.request
    import urllib.parse
    import json
    if not text or target_lang == source_lang:
        return text
    try:
        params = urllib.parse.urlencode({
            "client": "gtx", "sl": source_lang, "tl": target_lang,
            "dt": "t", "q": text,
        })
        req = urllib.request.Request(
            "https://translate.googleapis.com/translate_a/single?" + params,
            headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read().decode("utf-8"))
        # Response shape: [[[translated_chunk, original_chunk, ...], ...], ...] —
        # long input can come back split into several chunks to concatenate.
        return "".join(chunk[0] for chunk in data[0] if chunk[0])
    except Exception:
        return text


def get_arch_news(limit=6, lang="en"):
    """Fetch recent Arch Linux news headlines. Returns a list, or None on
    failure (so callers can tell 'no news' apart from 'couldn't reach the
    server').

    Arch Linux only publishes this feed in English — there's no official
    translated source — so when `lang` isn't English, each headline is
    additionally run through best-effort machine translation. Each item
    keeps the original English title too (as "title_en"), since machine
    translation of technical wording can occasionally be imprecise and a
    caller may want to show or link back to the original.
    """
    import urllib.request
    import xml.etree.ElementTree as ET
    try:
        req = urllib.request.Request("https://archlinux.org/feeds/news/",
                                     headers={"User-Agent": "Pachul"})
        with urllib.request.urlopen(req, timeout=12) as r:
            root = ET.fromstring(r.read())
    except Exception:
        return None
    items = []
    for item in root.iterfind(".//item"):
        title = (item.findtext("title") or "").strip()
        items.append({
            "title":    title,
            "title_en": title,
            "date":     (item.findtext("pubDate") or "").strip(),
            "link":     (item.findtext("link") or "").strip(),
        })
        if len(items) >= limit:
            break
    if lang != "en":
        for it in items:
            it["title"] = _translate_text(it["title_en"], lang)
    return items


# ─── AUR package metadata (votes / popularity / maintainer) ───────────────────

def get_aur_info(pkg_name):
    """Fetch AUR metadata for pkg_name via the official AUR RPC API
    (https://aur.archlinux.org/rpc/v5/info). Returns a dict with keys like
    NumVotes, Popularity, Maintainer, LastModified, OutOfDate — or None if
    the package isn't on AUR, or the request fails (e.g. offline).

    The RPC doesn't expose comments, so callers should instead link out to
    the package's AUR web page for those.
    """
    import urllib.request
    import urllib.parse
    url = ("https://aur.archlinux.org/rpc/v5/info?arg[]="
           + urllib.parse.quote(pkg_name, safe=""))
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Pachul"})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode("utf-8"))
    except Exception:
        return None
    results = data.get("results") or []
    return results[0] if results else None


# ─── Pre-upgrade snapshot (Timeshift / Snapper) ────────────────────────────────

def detect_snapshot_tool():
    """Detect an available system-snapshot tool for the pre-upgrade safety net.

    Returns (tool, extra):
      ("timeshift", None)       — Timeshift is installed
      ("snapper", "<config>")   — Snapper is installed; extra is the first
                                    configured snapshot config (e.g. "root")
      (None, None)              — neither is installed
    Timeshift is preferred when both are present since it snapshots the
    whole system by default, without needing a config name.
    """
    _, code = run_command("which timeshift 2>/dev/null")
    if code == 0:
        return "timeshift", None
    _, code = run_command("which snapper 2>/dev/null")
    if code == 0:
        cfg_out, _ = run_command(
            "snapper list-configs 2>/dev/null | awk 'NR>2{print $1}' | head -1")
        cfg = cfg_out.strip() or "root"
        return "snapper", cfg
    return None, None


def build_snapshot_cmd(comment="Pachul: before system upgrade"):
    """Shell command that creates a pre-upgrade snapshot, or None if no
    supported snapshot tool (Timeshift/Snapper) is installed."""
    tool, info = detect_snapshot_tool()
    if tool == "timeshift":
        return f"sudo -S timeshift --create --comments {shlex.quote(comment)} --scripted"
    if tool == "snapper":
        return f"sudo -S snapper -c {shlex.quote(info)} create --description {shlex.quote(comment)}"
    return None


# ─── Explicit-package export ──────────────────────────────────────────────────

def get_explicit_packages():
    """Names of explicitly-installed packages (pacman -Qqe), repo + AUR."""
    out, code = run_command("pacman -Qqe 2>/dev/null")
    return out.splitlines() if (out and code == 0) else []


# ─── Downgrade: cached package versions ───────────────────────────────────────

def get_pkgbuild(pkg_name):
    """Fetch the PKGBUILD text for an AUR package (helper first, then the AUR web)."""
    helper = _find_aur_helper()
    if helper:
        out, code = run_command(f"{helper} -Gp {shlex.quote(pkg_name)}", timeout=30)
        if out and code == 0:
            return out
    import urllib.request
    url = f"https://aur.archlinux.org/cgit/aur.git/plain/PKGBUILD?h={pkg_name}"
    try:
        with urllib.request.urlopen(url, timeout=15) as r:
            return r.read().decode("utf-8", errors="replace")
    except Exception as e:
        return f"# Could not fetch PKGBUILD for {pkg_name}\n# {e}\n"


# ─── .pacnew / .pacsave config files ──────────────────────────────────────────

def get_pacnew_files():
    """Find .pacnew/.pacsave files that need merging/reviewing."""
    out, _ = run_command(
        "find /etc /usr /boot /opt -xdev "
        "\\( -name '*.pacnew' -o -name '*.pacsave' \\) 2>/dev/null", timeout=30)
    files = []
    for line in out.splitlines():
        line = line.strip()
        if line.endswith(".pacnew") or line.endswith(".pacsave"):
            files.append({
                "new": line,
                "orig": line.rsplit(".", 1)[0],
                "kind": "pacnew" if line.endswith(".pacnew") else "pacsave",
            })
    return files


def get_file_diff(orig, new):
    out, _ = run_command(
        f"diff -u {shlex.quote(orig)} {shlex.quote(new)} 2>/dev/null", timeout=15)
    return out or "(files are identical or could not be read)"


# ─── External tool updaters ───────────────────────────────────────────────────
# Detection + update commands for developer/system tools that live outside
# pacman/Flatpak/Snap and therefore never show up in check_updates(). Every
# entry below only runs each tool's own --version/list/check subcommand for
# detection — nothing here changes the system until the user explicitly
# picks "Update" in the dialog.
#
# Each static spec dict:
#   id           unique id
#   name         display name (English; looked up through i18n.tr() in the UI)
#   binaries     list of candidate executable names, first match wins
#   version_cmd  optional "{bin} --version"-style command (first line kept)
#   check_cmd    optional command whose output is shown as detail/preview
#   update_cmd   command that performs the update; may use "{bin}"
#   note         optional explanatory caption shown under the row

TOOL_SPECS = [
    {
        "id": "firmware", "name": "Firmware (fwupdmgr)",
        "binaries": ["fwupdmgr"],
        "version_cmd": "fwupdmgr --version 2>/dev/null | head -1",
        "check_cmd": "fwupdmgr refresh --force >/dev/null 2>&1; fwupdmgr get-updates 2>&1",
        "update_cmd": "fwupdmgr update -y",
        "note": "Firmware updates for the mainboard, SSDs, and other devices via fwupd.",
    },
    {
        "id": "rustup", "name": "Rust Toolchains (rustup)",
        "binaries": ["rustup"],
        "version_cmd": "rustup --version 2>/dev/null | head -1",
        "check_cmd": "rustup check 2>&1",
        "update_cmd": "rustup update",
        "note": "",
    },
    {
        "id": "pip", "name": "pip (--user packages)",
        "binaries": ["pip", "pip3"],
        "version_cmd": None,
        "check_cmd": "{bin} list --outdated --user --format=freeze 2>/dev/null",
        "update_cmd": ("{bin} list --outdated --user --format=freeze 2>/dev/null "
                        "| grep -v '^-e' | cut -d= -f1 | xargs -r -n1 {bin} install --user -U"),
        "note": "Upgrades every outdated package installed with --user.",
    },
    {
        "id": "pipx", "name": "pipx",
        "binaries": ["pipx"],
        "version_cmd": None,
        "check_cmd": "pipx list --short 2>/dev/null",
        "update_cmd": "pipx upgrade-all",
        "note": "",
    },
    {
        "id": "npm", "name": "npm (global packages)",
        "binaries": ["npm"],
        "version_cmd": None,
        "check_cmd": "npm outdated -g 2>/dev/null",
        "update_cmd": "npm update -g",
        "note": "",
    },
    {
        "id": "claude_code", "name": "Claude Code",
        "binaries": ["claude"],
        "version_cmd": "claude --version 2>/dev/null | head -1",
        "check_cmd": None,
        "update_cmd": "claude update",
        "note": "",
    },
    {
        "id": "lensfun", "name": "Lensfun Camera/Lens Database",
        "binaries": ["lensfun-update-data"],
        "version_cmd": None,
        "check_cmd": None,
        "update_cmd": "lensfun-update-data",
        "note": "Fetches the latest camera/lens calibration data used by darktable, digiKam, and similar apps.",
    },
    {
        "id": "uv", "name": "uv (Python package/tool manager)",
        "binaries": ["uv"],
        "version_cmd": "uv --version 2>/dev/null",
        "check_cmd": None,
        "update_cmd": "uv self update",
        "note": "Only works for the standalone uv installer — a pacman/AUR install is updated there instead.",
    },
    {
        "id": "fnm", "name": "fnm (Fast Node Manager)",
        "binaries": ["fnm"],
        "version_cmd": "fnm --version 2>/dev/null",
        "check_cmd": None,
        "update_cmd": "fnm install --lts",
        "note": "Installs the latest Node.js LTS release via fnm.",
    },
]


def _cargo_update_check():
    """cargo-installed binaries, via the separate cargo-update subcommand
    (cargo install cargo-update). Detected dynamically because whether the
    subcommand itself is installed changes the update command we offer."""
    if not shutil.which("cargo"):
        return None
    out, _ = run_command("cargo install-update -l 2>&1", timeout=20)
    out = out or ""
    if "no such subcommand" in out.lower() or "no such command" in out.lower():
        return {
            "id": "cargo", "name": "Cargo (crates.io binaries)",
            "version": "", "detail": "",
            "update_cmd": "cargo install cargo-update && cargo install-update -a",
            "launch_cmd": None,
            "note": "Installs the 'cargo-update' helper crate first, then upgrades all cargo-installed binaries.",
        }
    return {
        "id": "cargo", "name": "Cargo (crates.io binaries)",
        "version": "", "detail": out.strip(),
        "update_cmd": "cargo install-update -a",
        "launch_cmd": None,
        "note": "",
    }


def _gh_extensions_check():
    """Only offered when gh is installed AND at least one extension is
    present — gh itself is often installed without any extensions."""
    if not shutil.which("gh"):
        return None
    out, code = run_command("gh extension list 2>/dev/null", timeout=15)
    if code != 0 or not (out or "").strip():
        return None
    return {
        "id": "gh_extensions", "name": "GitHub CLI Extensions",
        "version": "", "detail": out.strip(),
        "update_cmd": "gh extension upgrade --all",
        "launch_cmd": None,
        "note": "",
    }


def _ollama_check():
    """Skipped when Ollama is a pacman/AUR package — the regular update
    list (check_updates) already covers that case."""
    if not shutil.which("ollama"):
        return None
    _, code = run_command("pacman -Qq ollama 2>/dev/null", timeout=10)
    if code == 0:
        return None
    version, _ = run_command("ollama --version 2>/dev/null", timeout=10)
    return {
        "id": "ollama", "name": "Ollama",
        "version": (version or "").strip(), "detail": "",
        "update_cmd": "curl -fsSL https://ollama.com/install.sh | sh",
        "launch_cmd": None,
        "note": "Re-runs the official installer script to fetch the latest release.",
    }


def _find_pycharm_binary():
    """Locate a PyCharm CLI launcher script — plain install, Toolbox
    install, or a manual/AUR install under /opt."""
    for name in ("pycharm", "pycharm.sh"):
        found = shutil.which(name)
        if found:
            return found
    toolbox_apps = Path.home() / ".local" / "share" / "JetBrains" / "Toolbox" / "apps"
    try:
        for pattern in ("PyCharm-P/ch-*/*/bin/pycharm.sh", "PyCharm-C/ch-*/*/bin/pycharm.sh"):
            matches = sorted(toolbox_apps.glob(pattern), reverse=True)
            if matches:
                return str(matches[0])
    except Exception:
        pass
    for pattern in ("/opt/pycharm*/bin/pycharm.sh", "/usr/share/pycharm/bin/pycharm.sh"):
        matches = sorted(Path("/").glob(pattern.lstrip("/")), reverse=True)
        if matches:
            return str(matches[0])
    return None


def _pycharm_plugins_dir():
    """XDG data dir holding installed PyCharm plugins
    (~/.local/share/JetBrains/PyCharm<version>/) — picks the most
    recently used version directory if several are present."""
    base = Path.home() / ".local" / "share" / "JetBrains"
    try:
        dirs = [d for d in base.glob("PyCharm*") if d.is_dir()]
    except Exception:
        return None
    if not dirs:
        return None
    return max(dirs, key=lambda p: p.stat().st_mtime)


def _extract_plugin_id(plugin_dir):
    """Read the <id> out of a plugin's plugin.xml, packed inside one of
    its lib/*.jar files."""
    lib_dir = plugin_dir / "lib"
    if not lib_dir.is_dir():
        return None
    try:
        jars = list(lib_dir.glob("*.jar"))
    except Exception:
        return None
    for jar_path in jars:
        try:
            with zipfile.ZipFile(jar_path) as zf:
                if "META-INF/plugin.xml" not in zf.namelist():
                    continue
                with zf.open("META-INF/plugin.xml") as f:
                    root = ET.fromstring(f.read())
                    id_el = root.find("id")
                    if id_el is not None and id_el.text:
                        return id_el.text.strip()
        except Exception:
            continue
    return None


def _pycharm_installed_plugin_ids():
    plugins_dir = _pycharm_plugins_dir()
    if not plugins_dir:
        return []
    ids = []
    try:
        for entry in plugins_dir.iterdir():
            if not entry.is_dir():
                continue
            pid = _extract_plugin_id(entry)
            if pid:
                ids.append(pid)
    except Exception:
        pass
    return ids


def _jetbrains_plugins_check():
    """Updates PyCharm plugins from the command line the same way
    topgrade does it: JetBrains IDEs have no dedicated 'update plugins'
    verb, but re-running 'installPlugins <id>' for an already-installed
    plugin always fetches the latest compatible version and overwrites
    the old one — so calling it for every detected plugin ID amounts to
    updating all of them. PyCharm must be closed for this to work (the
    launcher refuses a second instance against the same config).
    Falls back to just launching Toolbox/PyCharm if the CLI launcher or
    the installed plugin IDs can't be determined."""
    binary = _find_pycharm_binary()
    ids = _pycharm_installed_plugin_ids() if binary else []
    if binary and ids:
        quoted_ids = " ".join(shlex.quote(i) for i in ids)
        return {
            "id": "jetbrains_plugins", "name": "JetBrains PyCharm Plugins",
            "version": "", "detail": "\n".join(ids),
            "update_cmd": f"{shlex.quote(binary)} installPlugins {quoted_ids}",
            "launch_cmd": None,
            "note": "Re-installs every detected plugin at its latest compatible version "
                    "(the same trick topgrade uses) — close PyCharm first.",
        }

    try:
        config_dirs = list(Path.home().glob(".config/JetBrains/PyCharm*"))
    except Exception:
        config_dirs = []
    toolbox = shutil.which("jetbrains-toolbox")
    fallback_bin = binary or shutil.which("pycharm") or shutil.which("pycharm.sh")
    if not (config_dirs or toolbox or fallback_bin):
        return None
    return {
        "id": "jetbrains_plugins", "name": "JetBrains PyCharm Plugins",
        "version": "", "detail": "",
        "update_cmd": None,
        "launch_cmd": toolbox or fallback_bin,
        "note": "Couldn't determine the CLI launcher or installed plugin IDs automatically — "
                "this opens Toolbox/PyCharm so you can use Settings \u2192 Plugins \u2192 Update All instead.",
    }


def _nvm_check():
    """nvm installs as a shell function (nvm.sh), not a binary on PATH, so
    detection is by directory rather than shutil.which."""
    script = Path.home() / ".nvm" / "nvm.sh"
    if not script.exists():
        return None
    version, _ = run_command(
        f"bash -lc 'source {shlex.quote(str(script))}; nvm --version' 2>/dev/null", timeout=15)
    return {
        "id": "nvm", "name": "nvm (Node Version Manager)",
        "version": (version or "").strip(), "detail": "",
        "update_cmd": (f"bash -lc 'source {shlex.quote(str(script))}; "
                        "nvm install --lts; nvm alias default lts/*'"),
        "launch_cmd": None,
        "note": "Installs the latest Node.js LTS release and sets it as the default.",
    }


def _pyenv_check():
    if not shutil.which("pyenv"):
        return None
    version, _ = run_command("pyenv --version 2>/dev/null", timeout=10)
    pyenv_root = os.environ.get("PYENV_ROOT", str(Path.home() / ".pyenv"))
    return {
        "id": "pyenv", "name": "pyenv (Python Version Manager)",
        "version": (version or "").strip(), "detail": "",
        "update_cmd": f"pyenv update 2>/dev/null || (cd {shlex.quote(pyenv_root)} && git pull)",
        "launch_cmd": None,
        "note": "Updates pyenv itself — install new Python versions separately with 'pyenv install'.",
    }


def _sdkman_check():
    """SDKMAN's 'sdk' command is a shell function too, sourced from
    sdkman-init.sh rather than being a plain executable."""
    init_script = Path.home() / ".sdkman" / "bin" / "sdkman-init.sh"
    if not init_script.exists():
        return None
    return {
        "id": "sdkman", "name": "SDKMAN (Java/Kotlin/Gradle/Maven)",
        "version": "", "detail": "",
        "update_cmd": f"bash -lc 'source {shlex.quote(str(init_script))}; sdk selfupdate; sdk update'",
        "launch_cmd": None,
        "note": "Updates SDKMAN itself and its candidate index — not each installed SDK version.",
    }


def _conda_check():
    """Prefers mamba over conda when both are present (same base env, mamba
    is just the faster front end)."""
    binary = shutil.which("mamba") or shutil.which("conda")
    if not binary:
        return None
    cmd_name = os.path.basename(binary)
    version, _ = run_command(f"{shlex.quote(binary)} --version 2>/dev/null", timeout=10)
    if cmd_name == "mamba":
        update_cmd = "mamba update --all -y"
        name = "Mamba (base environment)"
    else:
        update_cmd = "conda update -n base -c defaults conda -y && conda update --all -y"
        name = "Conda (base environment)"
    return {
        "id": "conda", "name": name,
        "version": (version or "").strip(), "detail": "",
        "update_cmd": update_cmd,
        "launch_cmd": None,
        "note": "Updates the base environment only — other environments need updating separately.",
    }


def _texlive_check():
    """Skipped when TeX Live is a pacman/AUR package — the regular update
    list (check_updates) already covers that case."""
    if not shutil.which("tlmgr"):
        return None
    _, code = run_command("pacman -Qo $(command -v tlmgr) 2>/dev/null", timeout=10)
    if code == 0:
        return None
    version, _ = run_command("tlmgr --version 2>/dev/null | head -1", timeout=10)
    return {
        "id": "texlive", "name": "TeX Live (tlmgr)",
        "version": (version or "").strip(), "detail": "",
        "update_cmd": "tlmgr update --self --all",
        "launch_cmd": None,
        "note": "",
    }


def _vscode_extensions_check():
    binary = shutil.which("code") or shutil.which("codium")
    if not binary:
        return None
    out, code = run_command(f"{shlex.quote(binary)} --list-extensions 2>/dev/null", timeout=15)
    if code != 0 or not (out or "").strip():
        return None
    cmd_name = os.path.basename(binary)
    return {
        "id": "vscode_ext",
        "name": "VS Code Extensions" if cmd_name == "code" else "VSCodium Extensions",
        "version": "", "detail": out.strip(),
        "update_cmd": f"{cmd_name} --list-extensions | xargs -L 1 {cmd_name} --install-extension --force",
        "launch_cmd": None,
        "note": "Reinstalls every extension at its latest Marketplace version.",
    }


def _clamav_db_check():
    if not shutil.which("freshclam"):
        return None
    version, _ = run_command("freshclam --version 2>/dev/null | head -1", timeout=10)
    return {
        "id": "clamav_db", "name": "ClamAV Virus Definitions",
        "version": (version or "").strip(), "detail": "",
        "update_cmd": "sudo freshclam",
        "launch_cmd": None,
        "note": "Downloads the latest ClamAV signature database.",
    }


def _docker_images_check():
    if not shutil.which("docker"):
        return None
    out, code = run_command(
        "docker images --format '{{.Repository}}:{{.Tag}}' 2>/dev/null | grep -v '<none>'",
        timeout=15)
    if code != 0 or not (out or "").strip():
        return None
    return {
        "id": "docker_images", "name": "Docker Images",
        "version": "", "detail": out.strip(),
        "update_cmd": ("docker images --format '{{.Repository}}:{{.Tag}}' 2>/dev/null "
                        "| grep -v '<none>' | xargs -L1 docker pull"),
        "launch_cmd": None,
        "note": "Pulls the latest version of every locally tagged image.",
    }


def _podman_images_check():
    if not shutil.which("podman"):
        return None
    out, code = run_command(
        "podman images --format '{{.Repository}}:{{.Tag}}' 2>/dev/null | grep -v '<none>'",
        timeout=15)
    if code != 0 or not (out or "").strip():
        return None
    return {
        "id": "podman_images", "name": "Podman Images",
        "version": "", "detail": out.strip(),
        "update_cmd": ("podman images --format '{{.Repository}}:{{.Tag}}' 2>/dev/null "
                        "| grep -v '<none>' | xargs -L1 podman pull"),
        "launch_cmd": None,
        "note": "Pulls the latest version of every locally tagged image.",
    }


def _flatpak_unused_check():
    if not (get_setting("flatpak_enabled") and flatpak_available()):
        return None
    out, code = run_command(
        "flatpak list --columns=application --app=false 2>/dev/null", timeout=15)
    if code != 0 or not (out or "").strip():
        return None
    return {
        "id": "flatpak_unused", "name": "Flatpak: Unused Runtimes",
        "version": "", "detail": "",
        "update_cmd": "flatpak uninstall --unused -y",
        "launch_cmd": None,
        "note": "Removes runtimes and extensions no installed app depends on anymore.",
    }


def _vim_neovim_plugins_check():
    """Detects whichever plugin manager is present and picks the matching
    headless update invocation — lazy.nvim and packer.nvim take priority
    over vim-plug when more than one is found, matching how most users
    who have several actually only use the newest one."""
    data_home = Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share")))
    config_home = Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config")))

    if shutil.which("nvim"):
        lazy_dir = data_home / "nvim" / "lazy" / "lazy.nvim"
        packer_dir = data_home / "nvim" / "site" / "pack" / "packer" / "start" / "packer.nvim"
        plug_file = data_home / "nvim" / "site" / "autoload" / "plug.vim"
        if lazy_dir.is_dir():
            return {
                "id": "nvim_plugins", "name": "Neovim Plugins (lazy.nvim)",
                "version": "", "detail": "",
                "update_cmd": 'nvim --headless "+Lazy! sync" +qa',
                "launch_cmd": None, "note": "",
            }
        if packer_dir.is_dir():
            return {
                "id": "nvim_plugins", "name": "Neovim Plugins (packer.nvim)",
                "version": "", "detail": "",
                "update_cmd": ('nvim --headless -c "autocmd User PackerComplete quitall" '
                                '-c "PackerSync"'),
                "launch_cmd": None, "note": "",
            }
        if plug_file.exists():
            return {
                "id": "nvim_plugins", "name": "Neovim Plugins (vim-plug)",
                "version": "", "detail": "",
                "update_cmd": 'nvim --headless "+PlugUpdate" +qa',
                "launch_cmd": None, "note": "",
            }

    if shutil.which("vim"):
        plug_file = Path.home() / ".vim" / "autoload" / "plug.vim"
        if plug_file.exists():
            return {
                "id": "vim_plugins", "name": "Vim Plugins (vim-plug)",
                "version": "", "detail": "",
                "update_cmd": 'vim -Es -c "PlugUpdate" -c "qa"',
                "launch_cmd": None, "note": "",
            }
    return None


def _tmux_tpm_check():
    tpm_script = Path.home() / ".tmux" / "plugins" / "tpm" / "bin" / "update_plugins"
    if not tpm_script.exists():
        return None
    return {
        "id": "tmux_tpm", "name": "tmux Plugins (TPM)",
        "version": "", "detail": "",
        "update_cmd": f"{shlex.quote(str(tpm_script))} all",
        "launch_cmd": None, "note": "",
    }


def _zsh_frameworks_check():
    """Returns a list (0-2 entries) since more than one zsh/fish plugin
    framework can coexist, unlike the other checks here which are 1:1."""
    entries = []

    ohmyzsh_dir = Path(os.environ.get("ZSH", str(Path.home() / ".oh-my-zsh")))
    if ohmyzsh_dir.is_dir() and (ohmyzsh_dir / "tools" / "upgrade.sh").exists():
        entries.append({
            "id": "oh_my_zsh", "name": "Oh My Zsh",
            "version": "", "detail": "",
            "update_cmd": f'env ZSH={shlex.quote(str(ohmyzsh_dir))} sh {shlex.quote(str(ohmyzsh_dir / "tools" / "upgrade.sh"))}',
            "launch_cmd": None, "note": "",
        })

    zinit_dirs = [
        Path.home() / ".local" / "share" / "zinit" / "zinit.git",
        Path.home() / ".zinit" / "bin" / "zinit.zsh",
    ]
    if any(p.exists() for p in zinit_dirs) and shutil.which("zsh"):
        entries.append({
            "id": "zinit", "name": "Zinit (zsh plugin manager)",
            "version": "", "detail": "",
            "update_cmd": 'zsh -ic "zinit self-update; zinit update --all"',
            "launch_cmd": None, "note": "",
        })

    antigen_files = [Path.home() / ".antigen" / "antigen.zsh", Path.home() / ".antigen.zsh"]
    if any(p.exists() for p in antigen_files) and shutil.which("zsh"):
        entries.append({
            "id": "antigen", "name": "Antigen (zsh plugin manager)",
            "version": "", "detail": "",
            "update_cmd": 'zsh -ic "antigen update"',
            "launch_cmd": None, "note": "",
        })

    if shutil.which("sheldon"):
        entries.append({
            "id": "sheldon", "name": "Sheldon (shell plugin manager)",
            "version": "", "detail": "",
            "update_cmd": "sheldon lock --update",
            "launch_cmd": None, "note": "",
        })

    if shutil.which("fish") and shutil.which("fisher"):
        entries.append({
            "id": "fisher", "name": "Fisher (fish plugin manager)",
            "version": "", "detail": "",
            "update_cmd": 'fish -c "fisher update"',
            "launch_cmd": None, "note": "",
        })

    return entries


def _dotfiles_git_repos_check():
    """Auto-discovers common dotfiles/config repos and offers a 'git pull'
    for each — only ones that are an actual git repo AND have a remote
    configured (skipping local-only repos, same as topgrade does)."""
    candidates = [
        Path.home() / ".dotfiles",
        Path.home() / "dotfiles",
        Path.home() / ".config" / "nvim",
        Path.home() / ".vim",
        Path.home() / ".emacs.d",
    ]
    entries = []
    for repo in candidates:
        if not (repo / ".git").exists():
            continue
        _, code = run_command(f"git -C {shlex.quote(str(repo))} remote get-url origin 2>/dev/null", timeout=10)
        if code != 0:
            continue
        entries.append({
            "id": f"git_repo_{repo.name}", "name": f"Git Repo: {repo}",
            "version": "", "detail": "",
            "update_cmd": f"git -C {shlex.quote(str(repo))} pull --ff-only",
            "launch_cmd": None, "note": "",
        })
    return entries


def _getnf_check():
    if not shutil.which("getnf"):
        return None
    return {
        "id": "getnf", "name": "Nerd Fonts (getnf)",
        "version": "", "detail": "",
        "update_cmd": "getnf -U",
        "launch_cmd": None,
        "note": "Updates already-installed Nerd Fonts to their latest release.",
    }


def _tldr_check():
    if not shutil.which("tldr"):
        return None
    return {
        "id": "tldr", "name": "tldr Pages",
        "version": "", "detail": "",
        "update_cmd": "tldr --update",
        "launch_cmd": None, "note": "",
    }


def _nix_check():
    if not (shutil.which("nix-env") or shutil.which("nix")):
        return None
    return {
        "id": "nix", "name": "Nix Packages (nix-env)",
        "version": "", "detail": "",
        "update_cmd": "nix-channel --update && nix-env -u '*'",
        "launch_cmd": None,
        "note": "Classic nix-env profile only \u2014 flake-based setups update differently.",
    }


def _home_manager_check():
    if not shutil.which("home-manager"):
        return None
    return {
        "id": "home_manager", "name": "home-manager",
        "version": "", "detail": "",
        "update_cmd": "home-manager switch",
        "launch_cmd": None, "note": "",
    }


def get_tool_updates():
    """Detect installed external tools (rustup, cargo, pip, pipx, npm, fnm,
    nvm, pyenv, SDKMAN, Conda/Mamba, TeX Live, GitHub CLI extensions,
    Claude Code, VS Code/VSCodium extensions, Lensfun, uv, Ollama, ClamAV
    definitions, Docker/Podman images, Flatpak unused runtimes, JetBrains
    PyCharm plugins, Vim/Neovim/tmux plugin managers, zsh/fish frameworks,
    dotfiles git repos, Nerd Fonts, tldr, Nix/home-manager, firmware via
    fwupd, …) that aren't covered by check_updates(). Returns a list of
    dicts: id, name, version, detail, update_cmd (or None), launch_cmd
    (or None), note. A tool with update_cmd set can be run directly; one
    with only launch_cmd set (JetBrains plugins fallback) has no
    scriptable updater and just gets opened. Purely read-only: only each
    tool's own --version/list/check subcommand runs here, nothing is
    changed."""
    results = []
    for spec in TOOL_SPECS:
        found_bin = next((b for b in spec["binaries"] if shutil.which(b)), None)
        if not found_bin:
            continue
        version = ""
        if spec.get("version_cmd"):
            vout, vcode = run_command(spec["version_cmd"], timeout=10)
            if vcode == 0 and vout:
                version = vout.strip().splitlines()[0]
        detail = ""
        if spec.get("check_cmd"):
            cout, _ = run_command(spec["check_cmd"].format(bin=found_bin), timeout=30)
            detail = (cout or "").strip()
        update_cmd = spec.get("update_cmd")
        if update_cmd:
            update_cmd = update_cmd.format(bin=found_bin)
        # Only npm and pip have a check_cmd output format that's
        # guaranteed to list *only* genuinely outdated items (no
        # "up to date" rows mixed in) — rustup check, cargo install-update
        # -l, gh extension list, pipx list, etc. all show every installed
        # item regardless of status, so counting their lines would
        # overstate how much is actually pending. Left None there rather
        # than showing a misleading number.
        outdated_count = None
        if detail:
            if spec["id"] == "npm":
                # "npm outdated -g" output: one header line, then one row
                # per outdated package (it never lists up-to-date ones).
                outdated_count = max(0, len(detail.splitlines()) - 1)
            elif spec["id"] == "pip":
                # "--format=freeze" output: exactly one line per outdated
                # package, no header.
                outdated_count = len(detail.splitlines())
        results.append({
            "id": spec["id"], "name": spec["name"], "version": version,
            "detail": detail, "update_cmd": update_cmd, "launch_cmd": None,
            "note": spec.get("note", ""), "outdated_count": outdated_count,
        })

    for fn in (_cargo_update_check, _gh_extensions_check, _ollama_check,
               _jetbrains_plugins_check, _nvm_check, _pyenv_check, _sdkman_check,
               _conda_check, _texlive_check, _vscode_extensions_check,
               _clamav_db_check, _docker_images_check, _podman_images_check,
               _flatpak_unused_check, _vim_neovim_plugins_check, _tmux_tpm_check,
               _getnf_check, _tldr_check, _nix_check, _home_manager_check):
        entry = fn()
        if entry:
            results.append(entry)

    for fn in (_zsh_frameworks_check, _dotfiles_git_repos_check):
        results.extend(fn())

    return results


def get_enabled_auto_update_commands():
    """Re-scans get_tool_updates() and returns [(name, update_cmd), ...]
    for every tool the user has opted into auto-running alongside the
    normal system upgrade (via the 'More Update Sources' checkboxes).
    Re-scanning rather than trusting the saved list means a tool that was
    uninstalled since being enabled is silently skipped instead of
    failing the whole upgrade chain. Launch-only entries (no update_cmd,
    e.g. the JetBrains fallback) can't run headlessly and are excluded."""
    enabled_ids = set(get_setting("auto_update_tool_ids") or [])
    if not enabled_ids:
        return []
    commands = []
    for t in get_tool_updates():
        if t["id"] in enabled_ids and t.get("update_cmd"):
            commands.append((t["name"], t["update_cmd"]))
    return commands


# ─── IgnorePkg (hold) ─────────────────────────────────────────────────────────

PACMAN_CONF = Path("/etc/pacman.conf")


def get_ignored_packages():
    """Set of packages currently held back via IgnorePkg in pacman.conf."""
    ignored = set()
    try:
        for line in PACMAN_CONF.read_text(errors="replace").splitlines():
            s = line.strip()
            if s.startswith("#") or not s.startswith("IgnorePkg"):
                continue
            _, _, val = s.partition("=")
            ignored.update(val.split())
    except Exception:
        pass
    return ignored


def set_package_ignored(pkg_name, ignore):
    """Compute a pacman.conf with pkg_name added to / removed from IgnorePkg and
    write it to a temp file. Returns the temp path, or None if no change is needed.

    The editing happens here in Python (safe); the caller just needs to copy the
    temp file over /etc/pacman.conf with root privileges.
    """
    try:
        lines = PACMAN_CONF.read_text().splitlines()
    except Exception:
        return None

    idx, current = None, set()
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("#"):
            continue
        if s.startswith("IgnorePkg"):
            idx = i
            _, _, val = s.partition("=")
            current = set(val.split())
            break

    if ignore:
        if pkg_name in current:
            return None
        current.add(pkg_name)
        new_line = "IgnorePkg = " + " ".join(sorted(current))
        if idx is not None:
            lines[idx] = new_line
        else:
            for i, line in enumerate(lines):
                if line.strip() == "[options]":
                    lines.insert(i + 1, new_line)
                    break
            else:
                lines.append(new_line)
    else:
        if pkg_name not in current:
            return None
        current.discard(pkg_name)
        if idx is not None:
            if current:
                lines[idx] = "IgnorePkg = " + " ".join(sorted(current))
            else:
                del lines[idx]

    import tempfile
    fd, tmp = tempfile.mkstemp(prefix="pachul-pacman-conf-", suffix=".conf")
    with os.fdopen(fd, "w") as f:
        f.write("\n".join(lines) + "\n")
    return tmp


def set_packages_ignored(pkg_names, ignore):
    """Batch version of set_package_ignored: adds/removes several package
    names to/from IgnorePkg in a single pass, returning one temp file to
    install. Returns None if none of the requested names actually needed
    a change (all already in the requested state)."""
    try:
        lines = PACMAN_CONF.read_text().splitlines()
    except Exception:
        return None

    idx, current = None, set()
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("#"):
            continue
        if s.startswith("IgnorePkg"):
            idx = i
            _, _, val = s.partition("=")
            current = set(val.split())
            break

    names = set(pkg_names)
    if ignore:
        changed = bool(names - current)
        current |= names
    else:
        changed = bool(names & current)
        current -= names
    if not changed:
        return None

    if idx is not None:
        if current:
            lines[idx] = "IgnorePkg = " + " ".join(sorted(current))
        else:
            del lines[idx]
    elif current:
        new_line = "IgnorePkg = " + " ".join(sorted(current))
        for i, line in enumerate(lines):
            if line.strip() == "[options]":
                lines.insert(i + 1, new_line)
                break
        else:
            lines.append(new_line)

    import tempfile
    fd, tmp = tempfile.mkstemp(prefix="pachul-pacman-conf-", suffix=".conf")
    with os.fdopen(fd, "w") as f:
        f.write("\n".join(lines) + "\n")
    return tmp


def get_cached_versions(pkg_name):
    """Return [(version, filepath), …] of cached .pkg files for pkg_name, newest first."""
    cache_dir = Path("/var/cache/pacman/pkg")
    results = []
    try:
        for f in cache_dir.glob(f"{pkg_name}-*.pkg.tar.*"):
            if f.name.endswith(".sig"):
                continue
            base = re.sub(r"\.pkg\.tar\.\w+$", "", f.name)
            parts = base.rsplit("-", 3)   # name-ver-rel-arch (name may contain '-')
            if len(parts) == 4 and parts[0] == pkg_name:
                results.append((f"{parts[1]}-{parts[2]}", str(f)))
    except Exception:
        pass
    results.sort(
        key=lambda vf: os.path.getmtime(vf[1]) if os.path.exists(vf[1]) else 0,
        reverse=True)
    return results


# ─── Search ───────────────────────────────────────────────────────────────────

def search_packages_cmd(query):
    def parse_pacman_ss(out):
        pkgs = []
        lines = out.splitlines()
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if '/' in line and not line.startswith(' '):
                parts = line.split()
                if parts:
                    repo_pkg = parts[0]
                    version = parts[1] if len(parts) > 1 else "unknown"
                    repo, name = repo_pkg.split('/', 1) if '/' in repo_pkg else ('', repo_pkg)
                    desc = lines[i + 1].strip() if i + 1 < len(lines) else ""
                    pkgs.append({"name": name, "version": version, "repo": repo,
                                 "description": desc, "status": "available",
                                 "foreign": repo.lower() == "aur"})
                    i += 2
                    continue
            i += 1
        return pkgs

    packages = []
    seen = set()

    qq = shlex.quote(query)
    out, code = run_command(f"pacman -Ss {qq} 2>/dev/null")
    if out and code == 0:
        for p in parse_pacman_ss(out):
            if p["name"] not in seen:
                seen.add(p["name"])
                packages.append(p)

    aur_helper = _find_aur_helper()
    if aur_helper:
        aur_out, aur_code = run_command(f"{aur_helper} -Ss --aur {qq} 2>/dev/null", timeout=30)
        if aur_out and aur_code == 0:
            for p in parse_pacman_ss(aur_out):
                if p["name"] not in seen:
                    p["foreign"] = True
                    if p["repo"].lower() not in ("core", "extra", "multilib", "community"):
                        p["repo"] = "aur"
                    seen.add(p["name"])
                    packages.append(p)

    for p in search_flatpak(query):
        if p["name"] not in seen:
            seen.add(p["name"])
            packages.append(p)

    for p in search_snap(query):
        if p["name"] not in seen:
            seen.add(p["name"])
            packages.append(p)

    return packages


# ─── Self-installation & tray autostart ────────────────────────────────────
# Mirrors install.sh's own paths exactly, so the in-app installer and the
# standalone script are just two front-ends to the same result — running
# one after the other is always a safe no-op.

INSTALL_DESKTOP_DIR  = "/usr/share/applications"
INSTALL_ICON_ID      = "io.github.wergosam.pachul"
INSTALL_DESKTOP_FILE = f"{INSTALL_DESKTOP_DIR}/{INSTALL_ICON_ID}.desktop"

# Per-user autostart entry for the tray icon. Deliberately NOT the
# system-wide /etc/xdg/autostart install.sh used to write — a file here
# needs no root to create, remove, or toggle, and per the XDG autostart
# spec a user's own ~/.config/autostart always takes precedence anyway.
AUTOSTART_DIR  = Path.home() / ".config" / "autostart"
AUTOSTART_FILE = AUTOSTART_DIR / f"{INSTALL_ICON_ID}-tray.desktop"


def is_pachul_installed():
    """Whether Pachul is installed system-wide — via install.sh
    (launcher in /usr/local/bin) or the AUR package (launcher in
    /usr/bin). Checked through PATH rather than a single hardcoded
    directory, since the two installation methods disagree on where the
    launcher lives; a hardcoded /usr/local/bin check would silently
    treat a perfectly good AUR install as "not installed"."""
    return shutil.which("pachul") is not None and os.path.isfile(INSTALL_DESKTOP_FILE)


def find_install_script(app_dir):
    """install.sh sits next to app.py only in a source checkout — an
    already-installed copy under /usr/local/share/pachul never ships it,
    so this naturally returns None once there's nothing left to install."""
    path = os.path.join(app_dir, "install.sh")
    return path if os.path.isfile(path) else None


def build_install_command(app_dir):
    """sudo -S command that runs install.sh non-interactively, through the
    exact same terminal/password flow every other privileged action in the
    app already uses — there's only one installation code path to maintain."""
    script = find_install_script(app_dir)
    if not script:
        return None
    return f"sudo -S bash {shlex.quote(script)}"


def is_autostart_enabled():
    return AUTOSTART_FILE.is_file()


def _resolve_icon_path(app_dir=None):
    """Absolute path to the app icon — never a bare icon-theme name.
    Both install.sh and the AUR PKGBUILD install the icon to the same
    system-wide hicolor path, so that's checked first (works regardless
    of a dev checkout still being around); a source checkout next to
    app_dir is the fallback for a not-yet-installed run. Used for the
    autostart .desktop's Icon= key: AppIndicator/Ayatana auto-populates
    the tray's SNI "DesktopEntry" property from this file, and Plasma's
    system tray resolves ITS OWN icon from that file's Icon= key by name
    — via Plasma's own icon cache, independent of whatever tray.py sets
    via set_icon_full(). A bare name there raced against Plasma's cache
    and fell back to the generic "applications-other" icon a few seconds
    in; an absolute path bypasses that lookup entirely, the same fix
    already applied to tray.py's own icon and to
    backend.py's own _pachul_icon_path() for notify-send.
    """
    system_path = f"/usr/share/icons/hicolor/scalable/apps/{INSTALL_ICON_ID}.svg"
    if os.path.isfile(system_path):
        return system_path
    if app_dir:
        checkout_path = os.path.join(app_dir, f"{INSTALL_ICON_ID}.svg")
        if os.path.isfile(checkout_path):
            return checkout_path
    return INSTALL_ICON_ID  # last-resort fallback to the old by-name behaviour


def set_autostart_enabled(enabled, app_dir=None):
    """Create or remove the per-user tray-icon autostart entry. Never
    touches anything outside the user's own config directory, so this
    never needs a password."""
    try:
        if enabled:
            AUTOSTART_DIR.mkdir(parents=True, exist_ok=True)
            if is_pachul_installed():
                exec_cmd = "pachul-tray"
            elif app_dir:
                exec_cmd = (f"{shlex.quote(sys.executable or 'python3')} "
                            f"{shlex.quote(os.path.join(app_dir, 'tray.py'))}")
            else:
                exec_cmd = "pachul-tray"
            icon_path = _resolve_icon_path(app_dir)
            AUTOSTART_FILE.write_text(
                "[Desktop Entry]\n"
                "Type=Application\n"
                "Name=Pachul Update Tray\n"
                "Comment=Persistent tray icon showing pending Pacman/AUR updates\n"
                f"Exec={exec_cmd}\n"
                f"Icon={icon_path}\n"
                "Terminal=false\n"
                "NoDisplay=true\n"
                "X-GNOME-Autostart-enabled=true\n")
        else:
            AUTOSTART_FILE.unlink(missing_ok=True)
        return True
    except OSError:
        return False


def is_tray_running():
    """Whether a pachul-tray process is currently running for this user."""
    _, code = run_command("pgrep -f 'tray[.]py' >/dev/null 2>&1")
    return code == 0


def start_tray(app_dir=None):
    """Launch the tray icon right now, detached from this process — used
    so enabling autostart in Preferences shows the icon immediately
    instead of only at the next login. No-op if already running.

    Prefers a tray.py right next to app_dir (i.e. whatever code is
    actually running right now) over the installed `pachul-tray` command:
    otherwise, on a machine where install.sh was run at some point in the
    past, this would always launch that old installed copy even while
    actively testing a newer source checkout — silently running stale
    code with no indication that's what happened.
    """
    if is_tray_running():
        return True
    if app_dir and os.path.isfile(os.path.join(app_dir, "tray.py")):
        exec_args = [sys.executable or "python3", os.path.join(app_dir, "tray.py")]
    elif is_pachul_installed():
        exec_args = ["pachul-tray"]
    else:
        exec_args = ["pachul-tray"]
    try:
        subprocess.Popen(
            exec_args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL, start_new_session=True)
        return True
    except OSError:

        return False


def stop_tray():
    """Quit the running tray icon right now — the counterpart to
    start_tray(), used when autostart is turned off in Preferences."""
    run_command("pkill -f 'tray[.]py' 2>/dev/null")
    return True


# ─── Background update-check (systemd --user timer) ───────────────────────────

SYSTEMD_USER_DIR = Path.home() / ".config" / "systemd" / "user"
TIMER_UNIT       = "pachul-update-check"
_TIMER_INTERVALS = {"hourly": "1h", "6h": "6h", "daily": "1d"}


def _notifier_path():
    return str(Path(__file__).resolve().parent / "notifier.py")


def is_update_timer_enabled():
    out, code = run_command(f"systemctl --user is-enabled {TIMER_UNIT}.timer 2>/dev/null")
    return code == 0 and out.strip() == "enabled"


def enable_update_timer(interval="daily"):
    """Write & enable the systemd --user timer that runs the notifier periodically."""
    on_active = _TIMER_INTERVALS.get(interval, "1d")
    python = sys.executable or "python3"
    notifier = _notifier_path()
    service = (
        "[Unit]\n"
        "Description=Pachul background update check\n\n"
        "[Service]\n"
        "Type=oneshot\n"
        f"ExecStart={python} {notifier}\n")
    timer = (
        "[Unit]\n"
        "Description=Pachul periodic update check\n\n"
        "[Timer]\n"
        "OnBootSec=5min\n"
        f"OnUnitActiveSec={on_active}\n"
        "Persistent=true\n\n"
        "[Install]\n"
        "WantedBy=timers.target\n")
    try:
        SYSTEMD_USER_DIR.mkdir(parents=True, exist_ok=True)
        (SYSTEMD_USER_DIR / f"{TIMER_UNIT}.service").write_text(service)
        (SYSTEMD_USER_DIR / f"{TIMER_UNIT}.timer").write_text(timer)
    except Exception:
        return False
    run_command("systemctl --user daemon-reload")
    _, code = run_command(f"systemctl --user enable --now {TIMER_UNIT}.timer")
    return code == 0


def disable_update_timer():
    run_command(f"systemctl --user disable --now {TIMER_UNIT}.timer")
    return True


def _pachul_icon_path():
    """Absolute path to Pachul's own icon file, checked directly rather
    than resolved by name through an icon theme — works both in a source
    checkout (icon sits right next to this file) and once installed
    system-wide (install.sh's ICON_DIR). Falls back to the bare name only
    if the file genuinely can't be found anywhere."""
    name = "io.github.wergosam.pachul"
    local = os.path.join(os.path.dirname(os.path.abspath(__file__)), f"{name}.svg")
    if os.path.isfile(local):
        return local
    system_path = f"/usr/share/icons/hicolor/scalable/apps/{name}.svg"
    if os.path.isfile(system_path):
        return system_path
    return name


def send_update_notification(n, extra=0):
    """Send a desktop notification about n available package updates,
    plus (optionally) how many enabled "More Update Sources" tools are
    ready to run alongside the next system upgrade."""
    if run_command("which notify-send 2>/dev/null")[1] != 0:
        return
    from i18n import tr   # local import: avoids a circular import with i18n.py
    title = tr("Updates Available")
    parts = []
    if n > 0:
        line = tr("{n} package update can be installed.") if n == 1 \
            else tr("{n} package updates can be installed.")
        parts.append(line.format(n=n))
    if extra > 0:
        line = tr("1 additional update source is ready to run.") if extra == 1 \
            else tr("{n} additional update sources are ready to run.")
        parts.append(line.format(n=extra))
    body = " ".join(parts)
    icon = _pachul_icon_path()
    run_command(
        f"notify-send --app-name=Pachul --icon={shlex.quote(icon)} "
        f"{shlex.quote('Pachul: ' + title)} {shlex.quote(body)}")


def run_update_notification_check():
    """Entry point for the systemd timer: check for updates and notify if
    any — package updates, or enabled "More Update Sources" tools that
    are still actually detected right now (re-checked fresh each time, so
    an uninstalled tool never shows up here even if it was once enabled)."""
    if not get_setting("notify_updates"):
        return 0
    n = len(check_updates())
    extra = len(get_enabled_auto_update_commands())
    if n > 0 or extra > 0:
        send_update_notification(n, extra)
    return n
